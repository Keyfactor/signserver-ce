#install of signserver 3.2.4 with glassfish 2.1.1
#info glassfish : to connect to the admin interface, the default login is 'admin' and the password is 'adminadmin'
#@todo : after glassfish install, ask to the user to set the admin password
#@todo : check rights and owner of glassfish and signserver folders

if test $1 = "clean"
then

	echo "-----------------stop domain in glassfish---------------------------------"
	/opt/glassfish/bin/asadmin stop-domain domain1
	echo "-----------------delete glassfish folder---------------------------------------"
	rm -R /opt/glassfish
	echo "----------------------delete signserver folder---------------------------------"
	rm -R /opt/signserver
	echo "-----------------------delete database signserver------------------------"
	mysql -u root --password=XXXXXXX -e "drop database signserver;"

elif test $1 = "mysql"
then

	echo "------------------install mysql--------------------------"
	apt-get install mysql-server-5.1

elif test $1 = "finish"
then

	echo "-----------------start glassfish domain--------------------------------"
	/opt/glassfish/bin/asadmin start-domain domain1
	echo "-----------------compilation of signserver----------------------------------------"
	ant clean deploy -buildfile /opt/signserver/build.xml
	sleep 10
	echo "-----------------installation test of signserver-----------------------------"
	/opt/signserver/bin/signserver.sh getstatus brief all
	#we wait the end of the precedent command 
	sleep 120
	echo "------------------------------group and user for signserver------------------"
	addgroup signserver
	adduser --system signserver --ingroup signserver
	chown -R signserver:signserver /opt/signserver/
	echo "------------------------------add pdf worker--------------------"
	/opt/signserver/bin/signserver.sh setproperties install/qs_pdfsigner_configuration.properties
	sleep 120
	/opt/signserver/bin/signserver.sh reload 1
	sleep 60

elif test $1 = "test"
then
	
	/opt/signserver/bin/signserver.sh setproperties modules/SignServer-Test-SignServerWS/test-configuration.properties
	sleep 30
	/opt/signserver/bin/signserver.sh setproperties modules/SignServer-Test-ValidationWS/test-configuration.properties
	sleep 30
	/opt/signserver/bin/signserver.sh reload 7001
	sleep 15
	/opt/signserver/bin/signserver.sh reload 7101
	sleep 15
	ant test:run -buildfile /opt/signserver/build.xml

else

	echo "---------------update, upgrade------------------------"
	apt-get update
	apt-get upgrade

	signserverversion=signserver-3.2.4

	echo "------------------install openjdk6--------------------------"
	apt-get install openjdk-6-jdk
	echo "------------------install ant----------------------------"
	apt-get install ant
	echo "------------------install unzip--------------------------"
	apt-get install unzip


	echo "------------------environment variables---------------------"
	if test -z $APPSRV_HOME
	then
		more install/env.txt >> /etc/bash.bashrc
	fi

	if [ ! -e "/opt/glassfish" ]; then
		if [ ! -e "install/glassfish-installer-v2.1.1-b31g-linux-ml.jar" ]; then
			echo "------------------glassfish download--------------------"
			wget http://download.java.net/javaee5/v2.1.1_branch/promoted/Linux/glassfish-installer-v2.1.1-b31g-linux-ml.jar
			mv glassfish-installer-v2.1.1-b31g-linux-ml.jar install
		fi
		echo "------------------glassfish install--------------------"
		java -Xmx256m -jar install/glassfish-installer-v2.1.1-b31g-linux-ml.jar
		echo "------------------mv glassfish--------------------"
		mv glassfish /opt/glassfish
		if [ ! -e "install/mysql-connector-java-5.1.20-bin.jar" ]; then
			echo "------------------mysql connector download--------------------"
			wget http://mirrors.ibiblio.org/maven2/mysql/mysql-connector-java/5.1.21/mysql-connector-java-5.1.21.jar
			mv mysql-connector-java-5.1.21.jar install
		fi
		echo "------------------mysql connector install--------------------"
		cp install/mysql-connector-java-5.1.21.jar /opt/glassfish/lib/

		echo "------------------chmod lib/ant/bin----------------------------"
		chmod -R +x /opt/glassfish/lib/ant/bin
		echo "------------------activation of the right java version------------"
		echo "if the default version of java is not openjdk6, modify it !"
		update-alternatives --config java
		/opt/glassfish/lib/ant/bin/ant -f /opt/glassfish/setup.xml
		echo "------------------start glassfish domain-------------------------"
		/opt/glassfish/bin/asadmin start-domain domain1
		echo "------------------creation of the mysql pool-----------------------"
		/opt/glassfish/bin/asadmin create-jdbc-connection-pool --datasourceclassname com.mysql.jdbc.jdbc2.optional.MysqlDataSource --restype javax.sql.DataSource --property user=signserver:password=signserver:serverName=localhost:databaseName=signserver:portNumber=3306 mysql_pool
		echo "-------------creation of the jdbc ressource---------------------"
		/opt/glassfish/bin/asadmin create-jdbc-resource --connectionpoolid mysql_pool jdbc/SignServerDS
		echo "-------------ping on the pool----------------------------------"
		/opt/glassfish/bin/asadmin ping-connection-pool mysql_pool
		echo "-------------creation of the new listener--------------------"
		/opt/glassfish/bin/asadmin create-http-listener --listeneraddress 0.0.0.0 --listenerport 8443 --defaultvs server --securityenabled=true http-listener-3
		echo "-------------add client authentification to the new listener"
		/opt/glassfish/bin/asadmin create-ssl --type http-listener --certname s1as --clientauthenabled=true http-listener-3
		echo "-------------modification of the listener port for http-listener-2 : 8442 instead of 8181----------------------"
		/opt/glassfish/bin/asadmin set server.http-service.http-listener.http-listener-2.port=8442
		echo "-------------replacement of glassfish server certificate--------------------------------"
		echo "-------------we save the previous keystore, be carreful, do not overwrite it if you do not know what you do------------------------"
		mv -i /opt/glassfish/domains/domain1/config/keystore.jks /opt/glassfish/domains/domain1/config/keystore_old.jks
		echo "if it is a developpment machine, if we want to launch tests, we have to install a server certificate with a CN=localhost"
		if test $1 = "dev"
		then
			cp install/keystore.jks /opt/glassfish/domains/domain1/config/
			# we replace the server certificate created automatically during the installation of glassfish with our new server certificate
			keytool -delete -alias s1as -keystore /opt/glassfish/domains/domain1/config/cacerts.jks
			keytool -export -alias s1as -file mydomain.crt -keystore /opt/glassfish/domains/domain1/config/keystore.jks
			keytool -import -trustcacerts -alias s1as -file mydomain.crt -keystore /opt/glassfish/domains/domain1/config/cacerts.jks
			# we delete the certificate created
			rm mydomain.crt
		fi
	fi

	if [ ! -e "/opt/signserver" ]; then
		if [ ! -e "install/$signserverversion.zip" ]; then
			echo "------------------signserver download--------------------"
			wget http://sourceforge.net/projects/signserver/files/signserver/3.2/$signserverversion.zip
			mv $signserverversion.zip install
		fi
		unzip install/$signserverversion.zip -d install
		echo "------------------install signserver--------------------"
		cp -R install/$signserverversion /opt/signserver
		echo "-----------------create database-----------------"
		mysql -u root --password=XXXXXXX -e "create database signserver; grant all privileges on signserver.* to signserver@localhost identified by 'signserver' with grant option;"
		echo "-----------------copy of signserver_build.properties---------------------"
		cp install/signserver_build.properties /opt/signserver/
		echo "-----------------creation of tables----------------------------------------------"
		mysql signserver -u root --password=XXXXXXX < install/$signserverversion/doc/howtos/create-tables-signserver32-mysql.sql
		echo "-----------------copy of the truststore used in tests (password changeit)---------------------"
		mkdir /opt/signserver/p12
		cp install/truststore.jks /opt/signserver/p12/
		#copy of jks file used in the pdf worker in the tests
		mkdir /etc/certificates
		cp install/ysKeystore.jks /etc/certificates/
	fi

fi
