Author : Antoine Louiset, Yousign

Signserver linux automatic installation (tested with Debian 6 and signserver 3.2.3)

This script will install signserver on a linux system.
It includes :
 - mysql-server-5.1
 - glassfish-2.1.1
 - java 6
 - ant
 - unzip
 - set the environment variables
 - compilation of signserver
 - installation test
 - add a user and a group signserver
 - add a user signserver in mysql with a password signserver
 - add a pdf worker
 - manage keystore in glassfish
 - copy of a signserver configuration file
 - copy of policies
 - database creation with good rights for user

Prerequisites :
 - if the version of signserver is not 3.2.3, adapt the script.


Keystores :
 - keystore.jks is the new keystore of glassfish (for the moment, we replace it, the aim is to change this for more security)
 - truststore.jks is the truststore of signserver (for tests)
 - ysKeystores.jks is used in the configuration file for tests


Installation :
 - go to the signserver.sh directory
 - su root
 - chmod 777 install_signserver.sh
 - if you don't have mysql, launch : ./install_signserver.sh mysql 2> file.log
 Mysql will be installed, you will specify the admin password, note it, we need it !
 After the installation, check the file.log to see if there are errors.
 - edit the script install_signserver.sh and replace the admin password in the mysql commands (the actual value is XXXXXXXXX). Check that you change it everywhere.
 - if you are on a development computer or if you want to launch signserver's tests, launch : ./install_signserver.sh dev 2> file.log
   if not, launch : ./install_signserver.sh
 Reboot your computer manually. Execute these last commands :
 - su root
 - ./install_signserver.sh finish 2> file.log
 Once it's finished, check the file.log to see if there are errors.

Tests :
 - if you want to launch tests : ./install_signserver.sh test 2> file.log
