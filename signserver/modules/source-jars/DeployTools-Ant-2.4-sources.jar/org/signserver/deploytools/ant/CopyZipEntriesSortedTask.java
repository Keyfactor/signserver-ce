/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.ant;

import java.io.File;
import java.io.IOException;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.signserver.deploytools.common.ZipFileUtils;

/**
 * Copies Zip entries from one file to an other in a deterministic order.
 * 
 * @author Markus Kilås
 * @version $Id$
 */
public class CopyZipEntriesSortedTask extends Task {
    private String in;
    private String out;
    private boolean doRewrite = true;
    
    @Override
    public void execute() throws BuildException {
        log("File: " + in + "\n" + " to: " + out, Project.MSG_VERBOSE);
        if (in == null) {
            throw new BuildException("Attribute 'in' not specified");
        }
        if (in == null) {
            throw new BuildException("Attribute 'out' not specified");
        }
        
        if (doRewrite) {
            log("Copying Zip entries sorted", Project.MSG_INFO);
            try {
                File srcFile = new File(in);
                File destFile = new File(out);
                new ZipFileUtils(new TaskLogger(this)).copyJarWithSortedZipEntries(srcFile, destFile);
            } catch (IOException ex) {
                throw new BuildException(ex);
            }
        } else {
            log("Not copying Zip entries sorted", Project.MSG_INFO);
        }
    }

    public String getIn() {
        return in;
    }

    public void setIn(String in) {
        this.in = in;
    }

    public String getOut() {
        return out;
    }

    public void setOut(String out) {
        this.out = out;
    }

    public boolean isDoRewrite() {
        return doRewrite;
    }
    
    public void setDoRewrite(boolean doRewrite) {
        this.doRewrite = doRewrite;
    }
}
