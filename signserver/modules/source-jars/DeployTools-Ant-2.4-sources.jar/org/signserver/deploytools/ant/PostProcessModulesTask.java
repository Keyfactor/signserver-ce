/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.ant;

import java.io.IOException;
import java.util.*;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.signserver.deploytools.common.AbstractModulesPostProcessor;

/**
 * Task postprocessing the modules.
 *
 * @author Markus Kilås
 * @author $Id$
 */
public class PostProcessModulesTask extends Task {

    private final AntModulesPostProcessor processor = new AntModulesPostProcessor();


    @Override
    public void execute() throws BuildException {
        processor.process();
    }

    public String getModules() {
        return processor.getModules();
    }

    public void setModules(String modules) {
        processor.setModules(modules);
    }

    public String getDestDir() {
        return processor.getDestDir();
    }

    public void setDestDir(String destDir) {
        processor.setDestDir(destDir);
    }

    protected StringBuffer commentReplacement(final StringBuffer oldDocument, final Map properties) throws IOException {
        return processor.commentReplacement(oldDocument, properties);
    }

    private class AntModulesPostProcessor extends AbstractModulesPostProcessor {
        @Override
        protected void log(String msg, int msgLevel) {
            Project proj = getProject();
            if (proj != null) {
                proj.log("     [ppmt] " + msg, msgLevel);
            }
        }

        @Override
        protected String getProperty(String string) {
            return getProject().getProperty(string);
        }

        @Override
        protected void setProperty(String newName, String property) {
            getProject().setProperty(newName, property);
        }

        @Override
        protected Map getProperties() {
            return getProject().getProperties();
        }

        @Override
        protected StringBuffer commentReplacement(StringBuffer oldDocument, Map properties) throws IOException {
            return super.commentReplacement(oldDocument, properties); //To change body of generated methods, choose Tools | Templates.
        }

    }
}
