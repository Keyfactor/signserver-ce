/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.ant;

import java.io.*;
import java.util.*;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.signserver.deploytools.common.AbstractModuleDescriptorsProcessor;

/**
 * Ant Task for parsing all the modules descriptors and compile the list of all 
 * enabled modules and libraries that need to be copied to the EAR file etc.
 *
 * TODO: Document attributes.
 * TODO: Usage example.
 * 
 * @author Markus Kilås
 * @version $Id: ProcessModulesTask.java 3161 2013-01-07 15:37:59Z netmackan $
 */
public class ProcessModuleDescriptorsTask extends Task {

    private final AbstractModuleDescriptorsProcessor processor;

    public ProcessModuleDescriptorsTask() {
        processor = new AbstractModuleDescriptorsProcessor() {

            @Override
            protected void log(String msg, int msgLevel) {
                getProject().log("     [dmdt] " + msg, msgLevel);
            }

            @Override
            protected String getProperty(String string) {
                return getProject().getProperty(string);
            }

            @Override
            protected void setProperty(String newName, String property) {
                getProject().setProperty(newName, property);
            }
        };
    }

    @Override
    public void execute() throws BuildException {
        
        Map<String, String> map = processor.process();
        
        for (Map.Entry<String, String> entry : map.entrySet()) {
            getProject().setProperty(entry.getKey(), entry.getValue());
        }
        
//        getProject().setProperty(libSet, getAsString(libJars));
//        getProject().setProperty(rootSet, getAsString(rootJars));
//        if (configRootSet != null) {
//            getProject().setProperty(configRootSet, getAsString(configRootFiles));
//        }
//        if (configConfSet != null) {
//            getProject().setProperty(configConfSet, getAsString(configConfFiles));
//        }
//        getProject().setProperty(applicationXml, xmlBuff.toString());
//        getProject().setProperty(enabledModules, enabledModulesBuff.toString());
    }
    

    public String getLibSet() {
        return processor.getLibSet();
    }

    public void setLibSet(String libSet) {
        processor.setLibSet(libSet);
    }

    public String getRootSet() {
        return processor.getRootSet();
    }

    public void setRootSet(String rootSet) {
        processor.setRootSet(rootSet);
    }

    public String getConfigRootSet() {
        return processor.getConfigRootSet();
    }

    public void setConfigRootSet(String configSet) {
        processor.setConfigRootSet(configSet);
    }
    
    public String getConfigConfSet() {
        return processor.getConfigConfSet();
    }

    public void setConfigConfSet(String configSet) {
        processor.setConfigConfSet(configSet);
    }

    public File getModsDir() {
        return processor.getModsDir();
    }

    public void setModsDir(File modsDir) {
        processor.setModsDir(modsDir);
    }
    
    public String getApplicationXml() {
        return processor.getApplicationXml();
    }

    public void setApplicationXml(String applicationXml) {
        processor.setApplicationXml(applicationXml);
    }

    public String getEnabledModules() {
        return processor.getEnabledModules();
    }

    public void setEnabledModules(String enabledModules) {
        processor.setEnabledModules(enabledModules);
    }

    public boolean isAllEnabled() {
        return processor.isAllEnabled();
    }

    public void setAllEnabled(boolean allEnabled) {
        processor.setAllEnabled(allEnabled);
    }

}
