/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.ant;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import jakarta.xml.bind.DatatypeConverter;
import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.signserver.deploytools.common.ZipFileUtils;

/**
 * Rewrites the ZIP entries modified time-stamps.
 * 
 * @author Markus Kilås
 * @version $Id$
 */
public class RewriteZipEntriesTimestampTask extends Task {
    private String file;
    private String time;
    private boolean doRewrite = true;
    
    @Override
    public void execute() throws BuildException {
        log("File: " + file + "\n" + "time: " + time, Project.MSG_VERBOSE);
        if (file == null) {
            throw new BuildException("Attribute 'file' not specified");
        }
        if (time == null) {
            throw new BuildException("Attribute 'time' not specified");
        }
        
        if (doRewrite && !time.trim().isEmpty() && !time.trim().startsWith("$")) {
            log("Rewriting time-stamps with fixedTime: \"" + time + "\"", Project.MSG_INFO);
            try {
                File destFile = new File(file);
                new ZipFileUtils(new TaskLogger(this)).rewriteZipEntriesLastModifiedTimeAndPomProperties(destFile.getAbsolutePath(), DatatypeConverter.parseDateTime(time).getTime().getTime());
            } catch (IOException | URISyntaxException ex) {
                throw new BuildException(ex);
            }
        } else {
            log("Not using deterministic time-stamps as fixedTime not specified", Project.MSG_INFO);
        }
    }
    
    public String getFile() {
        return file;
    }
    
    public void setFile(String file) {
        this.file = file;
    }
    
    public String getTime() {
        return time;
    }
    
    public void setTime(String time) {
        this.time = time;
    }
    
    public boolean isDoRewrite() {
        return doRewrite;
    }
    
    public void setDoRewrite(boolean doRewrite) {
        this.doRewrite = doRewrite;
    }
}
