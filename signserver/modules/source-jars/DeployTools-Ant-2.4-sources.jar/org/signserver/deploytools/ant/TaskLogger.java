/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.ant;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.Task;
import org.signserver.deploytools.common.LoggerFacade;

/**
 * LoggerFacade implementation for Ant.
 *
 * @author Markus Kilås
 * @version $Id$
 */
public class TaskLogger implements LoggerFacade {
    private final Task task;
    
    public TaskLogger(Task task) {
        this.task = task;
    }

    @Override
    public void logError(CharSequence msg, Throwable tw) {
        task.log(msg.toString(), tw, Project.MSG_ERR);
    }

    @Override
    public void logWarning(CharSequence msg) {
        task.log(msg.toString(), Project.MSG_WARN);
    }

    @Override
    public void logInfo(CharSequence msg) {
        task.log(msg.toString(), Project.MSG_INFO);
    }

    @Override
    public void logDebug(CharSequence msg) {
        task.log(msg.toString(), Project.MSG_VERBOSE);
    }
}
