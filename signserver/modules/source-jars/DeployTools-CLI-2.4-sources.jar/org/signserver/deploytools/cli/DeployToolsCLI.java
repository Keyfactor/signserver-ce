/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.cli;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.signserver.deploytools.common.NonAntModulesPostProcessor;
import org.signserver.deploytools.common.NonAntModulesProcessor;

/**
 *
 * @author Markus Kilås
 * @version $Id$
 */
public class DeployToolsCLI {
    
    private final Properties properties = new Properties();
    private boolean noDB;
    private File basedir;
    
    private static final Map<String, String> HIBERNATE_DIALECTS = new HashMap<String, String>();
    
    static {
        HIBERNATE_DIALECTS.put("db2", "org.hibernate.dialect.DB2Dialect");
        HIBERNATE_DIALECTS.put("derby", "org.hibernate.dialect.DerbyDialect");
        HIBERNATE_DIALECTS.put("hsqldb", "org.hibernate.dialect.HSQLDialect");
        HIBERNATE_DIALECTS.put("informix", "org.hibernate.dialect.InformixDialect");
        HIBERNATE_DIALECTS.put("ingres", "org.hibernate.dialect.IngresDialect");
        HIBERNATE_DIALECTS.put("mssql", "org.hibernate.dialect.SQLServerDialect");
        HIBERNATE_DIALECTS.put("mysql", "org.hibernate.dialect.MySQLDialect");
        HIBERNATE_DIALECTS.put("oracle", "org.hibernate.dialect.Oracle10gDialect");
        HIBERNATE_DIALECTS.put("postgres", "org.hibernate.dialect.PostgreSQLDialect");
        HIBERNATE_DIALECTS.put("sybase", "org.hibernate.dialect.SybaseDialect");
        HIBERNATE_DIALECTS.put("nodb", "no-dialect");
    }

    public void actionConfigureEAR() throws IOException {

        String basedirProperty = System.getProperty("basedir", "");
        basedir = new File(basedirProperty);
        System.out.println("basedir: " + basedir.getAbsolutePath());
        setProperty("basedir", basedir.getAbsolutePath());

        loadPropertiesFile(new File(basedir, "res/deploytools/app.properties"), true);
        printProperties();

        loadPropertiesFile(new File(basedir, "conf/" + properties.getProperty("app.name") + "_deploy.properties"), true);
        printProperties();
        
        // APPSRV_HOME / appserver.home
        String appserverHome = properties.getProperty("appserver.home");
        if (appserverHome == null) {
            appserverHome = System.getenv("APPSRV_HOME");
            properties.setProperty("appserver.home", appserverHome);
        }
        
        // appserver.type
        String appserverType = properties.getProperty("appserver.type");
        if (appserverType == null) {
            if (appserverHome == null) {
                System.err.println("Must specify the environment variable APPSRV_HOME or appserver.home or appserver.type in the configuration file");
                System.exit(2);
            }
            appserverType = detectAppserverType(appserverHome);
            properties.setProperty("appserver.type", appserverType);
        }
        
        // appserver.subtype
        String appserverSubtype = properties.getProperty("appserver.subtype");
        if (appserverSubtype == null) {
            appserverSubtype = detectAppserverSubtype(appserverHome, appserverType);
            properties.setProperty("appserver.subtype", appserverSubtype);
        }
        
        // init application server
        if ("jboss".equals(appserverType)) { // TODO: Refactor
            j2eeInit_jboss();
        } else {
            System.err.println("Unsupported application server type: " + appserverType);
            System.exit(2);
        }
        
        System.out.println("Configuring Enterprise Application Archive (EAR)...");
        String databaseName = properties.getProperty("database.name");
        noDB = "nodb".equals(databaseName);
        String hibernateDialect = HIBERNATE_DIALECTS.get(databaseName);
        if (hibernateDialect == null) {
            fail("Unsupported database type '" + databaseName + "'.");
        }
        properties.setProperty("hibernate.dialect", hibernateDialect);
        if (properties.getProperty("datasource.jndi-name") == null) {
            fail("Bug in project setup: Must specify a default value for datasource.jndi-name");
            return;
        }
        
        System.out.println("Database type:      " + properties.getProperty("database.name"));
        System.out.println("DataSource mapping: " + properties.getProperty("datasource.jndi-name-prefix}") + properties.getProperty("datasource.jndi-name"));
        
        
        // -set-ejbjarheader-nodb
        if (noDB) {
            setProperty("ejbjarheader", "			<![CDATA[\n" +
            "    			<!--\n" +
            "    		]]>\n" +
            "    	");
            setProperty("ejbjarfooter", "\n" +
            "    		<![CDATA[\n" +
            "    			-->\n" +
            "    		]]>\n" +
            "    	");
            setProperty("persistenceheader", "\n" +
            "    		<![CDATA[\n" +
            "    			<!--\n" +
            "    		]]>\n" +
            "    	");
            setProperty("persistencefooter", "\n" +
            "    		<![CDATA[\n" +
            "    			-->\n" +
            "    		]]>\n" +
            "		");
        }
        
        final boolean allEnabled = Boolean.parseBoolean(properties.getProperty("includemodulesinbuild"));
        
        // <mods modsDir="mods-available" libSet="toLibs" rootSet="toRoot" configRootSet="toConfigRoot" configConfSet="toConfigConf" applicationXml="appXml" enabledModules="enabledModules" allEnabled="${allEnabled}"/>
        NonAntModulesProcessor mods = new NonAntModulesProcessor(properties);
        mods.setModsDir(new File(basedir, "mods-available"));
        mods.setLibSet("toLibs");
        mods.setRootSet("toRoot");
        mods.setConfigRootSet("toConfigRoot");
        mods.setConfigConfSet("toConfigConf");
        mods.setApplicationXml("appXml");
        mods.setEnabledModules("enabledModules");
        mods.setAllEnabled(allEnabled);
        Map<String, String> modsResult = mods.process();
        System.out.println("modsResult: " + modsResult);

        for (Map.Entry<String, String> entry : modsResult.entrySet()) {
            if (entry.getValue() == null) {
                System.err.println("Null value: " + entry.getKey());
            } else {
                properties.setProperty(entry.getKey(), entry.getValue());
            }
        }
        
        File earDir = new File(basedir, "tmp/target.ear");
        setProperty("signserver.ear.dir", earDir.getAbsolutePath());
        if (earDir.exists()) {
            FileUtils.deleteDirectory(earDir);
        }
        earDir.mkdir();
        new File(earDir, "META-INF").mkdir();
        FileUtils.copyDirectory(new File(basedir, "res/deploytools/ear"), earDir);
        
        File earLibDir = new File(earDir, "lib");
        earLibDir.mkdir();
        copyToDirFlatten(earLibDir, basedir, properties.getProperty("toLibs"), properties.getProperty("appserver.lib.excludes"));
//        <copy todir="${signserver.ear.dir}/lib" flatten="true" verbose="true">
//            <fileset dir="." includes="${toLibs}" excludes="${appserver.lib.excludes}"/>
//        </copy>
//        

        //<!-- Write application.xml -->
        //<echo level="verbose">
        //    Additions to application.xml: 
        //    ${appXml}
        //</echo>
        System.out.println("Additions to application.xml:\n" + properties.getProperty("appXml") + "\n");
        
        //<replace file="${app.ear.dir}/META-INF/application.xml" value="${appXml}">
        //    <replacetoken><![CDATA[<!--@MODULES@-->]]></replacetoken>
        //</replace>
        File appXmlFile = new File(earDir, "META-INF/application.xml");
        String appXmlContent = FileUtils.readFileToString(appXmlFile);
        appXmlContent = appXmlContent.replace("<!--@MODULES@-->", properties.getProperty("appXml"));
        FileUtils.writeStringToFile(appXmlFile, appXmlContent);

        //<!-- Copy all enterprise modules to EAR root folder -->
        //<echo level="verbose">Enterprise modules to include:
        //    ${toRoot}</echo>
        System.out.println("Enterprise modules to include:\n" + properties.getProperty("toRoot") + "\n");
        
        //<copy todir="${app.ear.dir}" flatten="true">
        //    <fileset dir="." includes="${toRoot}"/>
        //</copy>
        copyToDirFlatten(earDir, basedir, properties.getProperty("toRoot"), null);
        
        
        System.out.println();
        System.out.println("Post processing files...");
        
        
        // <postprocess modules="${enabledModules}" destDir="${app.ear.dir}"/>
        NonAntModulesPostProcessor postProcess = new NonAntModulesPostProcessor(properties);
        postProcess.setModules(properties.getProperty("enabledModules"));
        postProcess.setDestDir(earDir.getAbsolutePath());
        
        postProcess.process();
        
        // Include all configurations
        System.out.println();
        System.out.println("Configurations to include:");
        System.out.println("/");
        System.out.println(properties.getProperty("toConfigRoot"));
        System.out.println("/conf/");
        System.out.println(properties.getProperty("toConfigConf"));
        
        //<property name="config.tmp.dir" location="${tmp}/config.jar"/>
        //<delete dir="${config.tmp.dir}"/>
        //<mkdir dir="${config.tmp.dir}"/>
        //<mkdir dir="${config.tmp.dir}/conf"/>
        File confDir = new File(basedir, "tmp/config.jar");
        setProperty("config.tmp.dir", confDir.getAbsolutePath());
        if (confDir.exists()) {
            FileUtils.deleteDirectory(confDir);
        }
        confDir.mkdir();
        File confConfDir = new File(confDir, "conf");
        confConfDir.mkdir();
        
        //<copy todir="${config.tmp.dir}" flatten="true">
        //    <fileset dir="." includes="-non-existing-,${toConfigRoot}"/>
        //</copy>
        copyToDirFlatten(confDir, basedir, properties.getProperty("toConfigRoot"), null);
        
        //<copy todir="${config.tmp.dir}/conf" flatten="true">
        //    <fileset dir="." includes="-non-existing-,${toConfigConf}"/>
        //</copy>
        copyToDirFlatten(confConfDir, basedir, properties.getProperty("toConfigConf"), null);
                    
        //<jar destfile="${app.ear.dir}/lib/config.jar">
        //    <zipfileset dir="${config.tmp.dir}" />
        //</jar>
        new File(confDir, "META-INF").mkdir();
        FileUtils.writeStringToFile(new File(confDir, "META-INF/MANIFEST.MF"), "Manifest-Version: 1.0");
        jarDirectory(confDir, new File(earLibDir, "config.jar"));
        

        //<!-- Build the ear file from the application.ear-dir folder -->
        //<ear destfile="${ear.dist.file}" appxml="${app.ear.dir}/META-INF/application.xml" duplicate="fail">
        //    <fileset dir="${app.ear.dir}">
        //        <exclude name="META-INF/application.xml" />
        //    </fileset>
        //    <zipfileset refid="appserver.extralibs"/>
        //</ear>
        File earDistFile = new File(basedir, "tmp/" + properties.getProperty("app.name") + ".ear");
        properties.setProperty("ear.dist.file", earDistFile.getAbsolutePath());
        FileUtils.writeStringToFile(new File(earDir, "META-INF/MANIFEST.MF"), "Manifest-Version: 1.0");
        copyToDirFlatten(earLibDir, basedir, properties.getProperty("appserver.extralibs"), null);
        jarDirectory(earDir, earDistFile);
        
        /*<echo/>
        <echo message="Configured EAR file available at: ${ear.dist.file}"/>
        <echo/>
        */
        System.out.println();
        System.out.println("Configured EAR file available at: " + earDistFile);
        System.out.println();
    }
    
    public void actionDeployEAR() throws IOException {
        File configuredEarFile = new File(basedir, "tmp/" + properties.getProperty("app.name") + ".ear");
        if (!configuredEarFile.exists()) {
            throw new IOException("No such file " + configuredEarFile.getAbsolutePath());
        }
        
        
        final String appserverType = properties.getProperty("appserver.type");
        if ("jboss".equals(appserverType)) { // TODO: Refactor
            j2eeDeploy_jboss();
        } else {
            System.err.println("Unsupported application server type: " + appserverType);
            System.exit(2);
        }
        j2eeDeploy_jboss();
    }
    
    private void j2eeInit_jboss() {
        //<property name="datasource.jndi-name-prefix" value="java:/"/>
        String prefix = properties.getProperty("datasource.jndi-name-prefix");
        if (prefix == null) {
            properties.setProperty("datasource.jndi-name-prefix", "java:/");
        }
    }
    
    private void j2eeDeploy_jboss() throws IOException {
        
        //<fail message="Please set the property 'appserver.home' or environment variable APPSRV_HOME" unless="appserver.home"/>    
        final String appserverHomeString = properties.getProperty("appserver.home");
        if (appserverHomeString == null) {
            fail("Please set the property 'appserver.home' or environment variable APPSRV_HOME");
            return;
        }
        
        //<!-- Declare the JAR files needed to run EJB CLI/system tests using this appserver. -->
        //<property name="appserver.client.jars" value="${appserver.home}/client/jbossall-client.jar:${appserver.home}/bin/client/jboss-client.jar"/>
        final File appserverHome = new File(appserverHomeString);
        final String appserverClientJars = new File(appserverHome, "client/jbossall-client.jar").getAbsolutePath() + ":" + new File(appserverHome, "bin/client/jboss-client.jar").getAbsolutePath();
        
        //<property name="jboss.config" value="default"/>
        final String jbossConfig = properties.getProperty("jboss.config", "default");
        //<property name="jboss.deploy" value="deploy"/>    
        final String jbossDeploy = properties.getProperty("jboss.deploy", "deploy");
        
        
        //<condition property="supported.appserver">
        //    <or>
        //        <equals arg1="${appserver.subtype}" arg2="jboss5" />
        //        <equals arg1="${appserver.subtype}" arg2="jboss7" />
        //        <equals arg1="${appserver.subtype}" arg2="jbosseap6" />
        //    </or>
        //</condition>
        //<fail message="Unsupported JBoss version detected. Only 5.1.x and 7.1.1.Final are supported." unless="supported.appserver"/>
        final String appserverSubtype = properties.getProperty("appserver.subtype");
        if (!"jboss7".equals(appserverSubtype) && !"jbosseap6".equals(appserverSubtype)) {
            fail("Unsupported JBoss version detected. Only 7.1.1.Final and EAP 6 are supported.");
            return;
        }
        
        
        //<condition property="jboss7">
        //    <or>
        //        <equals arg1="${appserver.subtype}" arg2="jboss7" />
        //        <equals arg1="${appserver.subtype}" arg2="jbosseap6" />
        //    </or>
        //</condition>
        //
        //<!-- Exclude dom4j on JBoss AS 7 as it does not work (and on EAP 6 only conistency) -->
        //<condition property="appserver.lib.excludes" value="lib/ext/hibernate/dom4j-*.jar">
        //    <or>
        //        <equals arg1="${appserver.subtype}" arg2="jboss7" />
        //        <equals arg1="${appserver.subtype}" arg2="jbosseap6" />
        //    </or>
        //</condition>
        if (properties.getProperty("appserver.lib.excludes") == null) {
            properties.setProperty("appserver.lib.excludes", "lib/ext/hibernate/dom4j-*.jar");
        }
        
        
        //<target name="-set-deploy-dir-jboss5" depends="j2ee:check" unless="jboss7">
        //    <property name="jboss.deploy.dir" location="${appserver.home}/server/${jboss.config}/${jboss.deploy}"/>
        //</target>
        //
        //<target name="-set-deploy-dir-jboss7" depends="j2ee:check" if="jboss7">
        //    <property name="jboss.deploy.dir" location="${appserver.home}/standalone/deployments"/>
        //</target>
        File jbossDeployDir = new File(appserverHome, "standalone/deployments");
        final File earDistFile = new File(properties.getProperty("ear.dist.file"));
        
        //<echo message="Deploying ${ear.dist.file} to ${jboss.deploy.dir}"/>
        //<copy file="${ear.dist.file}" todir="${jboss.deploy.dir}" failonerror="true"/>
        //<echo/>
        System.out.println("Deploying " + earDistFile + " to " + jbossDeployDir.getAbsolutePath());
        FileUtils.copyFileToDirectory(earDistFile, jbossDeployDir);
        System.out.println();
    }
    
    public static void copyToDirFlatten(File toDir, File dir, String includes, String excludes) throws IOException {
        if (includes != null) {
            final List<String> includeFiles = new LinkedList<String>(Arrays.asList(trim(includes.split(","))));

            for (String s : includeFiles) {
                File f = new File(dir, s);
                //if (matches(f, dir, includes, excludes)) {
                try {
                    FileUtils.copyFileToDirectory(f, toDir);
                    System.out.println("Copying " + f + " to directory " + toDir);
                } catch (IOException ex) {
                    System.out.println("   " + ex.getMessage());
                }
                //} else {
                //    System.out.println("Not copying " + f);
                //}
            }
        } else {
            System.out.println("Not copying anything as includes is null");
        }
    }
    
    public static boolean matches(File file, File dir, String includes, String excludes) throws IOException {
        final Set<String> includeFiles = new HashSet<String>(Arrays.asList(trim(includes.split(","))));
        final Set<String> excludeFiles = excludes == null ? Collections.<String>emptySet() : new HashSet<String>(Arrays.asList(trim(excludes.split(","))));
        return includeFiles.contains(file.getPath()) && !excludeFiles.contains(file.getPath());
    }
    
    private static String[] trim(String[] array) {
        for (int i = 0; i < array.length; i++) {
            array[i] = array[i].trim();
        }
        return array;
    }
    
    private void loadPropertiesFileIfExists(File file) throws IOException {
        loadPropertiesFile(file, false);
    }

    private void loadPropertiesFile(File file, boolean failOnNotFound) throws IOException {
        Properties props = new Properties();
        InputStream in = null;
        try {
            in = new BufferedInputStream(new FileInputStream(file));
            props.load(in);

            // Add all new properties not already available
            for (String prop : props.stringPropertyNames()) {
                if (!properties.contains(prop)) {
                    properties.put(prop, props.getProperty(prop));
                }
            }
        } catch (FileNotFoundException ex) {
            System.err.println("Failed to load properties file: " + file.getAbsolutePath());
            if (failOnNotFound) {
                throw ex;
            }
        } finally {
            IOUtils.closeQuietly(in);
        }
    }
    
    private void printProperties() {
//        for (String prop : properties.stringPropertyNames()) {
//            System.out.println(prop + " = " + properties.getProperty(prop));
//        }
        System.out.println(properties);
        System.out.println();
    }
    
    private void setProperty(String prop, String value) {
        if (!properties.contains(prop)) {
            properties.setProperty(prop, value);
        }
    }

   private void fail(String message) throws IOException {
       throw new IOException(message);
   }

    private void jarDirectory(File dir, File destFile) throws IOException {
        ZipOutputStream out = null;
        try {
            out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(destFile)));
            addFiles(dir.listFiles(), "", out);
        } finally {
            IOUtils.closeQuietly(out);
        }
    }

    private void addFiles(File[] files, String prefix, ZipOutputStream out) throws IOException {
        for (File f : files) {
            if (f.isDirectory()) {
                addFiles(f.listFiles(), prefix + f.getName() + "/", out);
            } else {
                System.out.println("Adding " + f);
                ZipEntry entry = new ZipEntry(prefix + f.getName());
                out.putNextEntry(entry);
                BufferedInputStream in = null;
                try {
                    in = new BufferedInputStream(new FileInputStream(f));
                    IOUtils.copy(in, out);
                } finally {
                    IOUtils.closeQuietly(in);
                }
                
            }
        }
    }

    private String detectAppserverType(String appserverHome) { // TODO: Move to properties file
        final String result;
        if (new File(appserverHome, "client/jboss-appclient.jar").exists()
                || new File(appserverHome, "modules/org/jboss/as/standalone/main/module.xml").exists()
                || new File(appserverHome, "modules/system/layers/base/org/jboss/as/standalone/main/module.xml").exists()) {
            result = "jboss";
        } else if (new File(appserverHome, "lib/javaee.jar").exists()) {
            result = "glassfish";
        } else if (new File(appserverHome, "wlserver_10.3/server/lib/wlclient.jar").exists()) {
            result = "weblogic";
        } else if (new File(appserverHome, "lib/commandlineutils.jar").exists()) {
            result = "websphere";
        } else {
            result = null;
        }
        return result;
    }

    private String detectAppserverSubtype(String appserverHome, String appserverType) {
        final String result;
        if (new File(appserverHome, "client/cxf-api.jar").exists()) {
            result = "jboss6";
        } else if (new File(appserverHome, "common/lib/jboss-javaee.jar").exists()
                || new File(appserverHome, "common/lib/jboss-ejb3-common.jar").exists()) {
            result = "jboss5";
        } else if (new File(appserverHome, "modules/org/jboss/as/standalone/main/module.xml").exists()) {
            result = "jboss7";
        } else if (new File(appserverHome, "modules/system/layers/base/org/jboss/as/standalone/main/module.xml").exists()) {
            result = "jbosseap6";
        } else if (new File(appserverHome, "lib/appserv-ext.jar").exists()) {
            result = "glassfish2";
        } else if (new File(appserverHome, "modules/bean-validator.jar").exists()) {
            result = "glassfish3";
        } else {
            result = null;
        }
        return result;
    }
}
