/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.cli;

import java.io.IOException;

/**
 *
 * @author Markus Kilås
 * @version $Id$
 */
public class Main {

    private static final String USAGE = "deploytools [action]\n"
            + "Actions:\n"
            + " configure-ear      Only configure the application.\n"
            + " deploy-ear         Configure and deploy to application server";
    
    public static void main(String[] args) throws IOException {
        
        if (args.length < 1) {
            System.err.println("Usage: " + USAGE);
            System.exit(1);
        } else {
            final String action = args[0];
            final DeployToolsCLI cli = new DeployToolsCLI();
            if ("configure-ear".equalsIgnoreCase(action)) {
                cli.actionConfigureEAR();
            } else if ("deploy-ear".equalsIgnoreCase(action)) {
                cli.actionConfigureEAR();
                cli.actionDeployEAR();
            } else {
                System.err.println("Usage: " + USAGE);
                System.exit(1);
            }
        }
    }
    
}
