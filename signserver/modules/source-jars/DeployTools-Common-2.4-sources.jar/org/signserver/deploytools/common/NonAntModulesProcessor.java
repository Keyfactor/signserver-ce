/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.signserver.deploytools.common;

import static java.lang.System.out;
import java.util.Properties;

/**
 *
 * @author markus
 */
public class NonAntModulesProcessor extends AbstractModuleDescriptorsProcessor {
    
    private final Properties projectProperties;

    public NonAntModulesProcessor(Properties projectProperties) {
        this.projectProperties = projectProperties;
    }
    
    @Override
    protected void log(String msg, int msgLevel) {
        out.println("MSG " + msgLevel + ": " + msg);
    }

    @Override
    protected String getProperty(String string) {
        return projectProperties.getProperty(string);
    }

    @Override
    protected void setProperty(String newName, String property) {
        projectProperties.setProperty(newName, property);
    }

}
