/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.maven;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import jakarta.xml.bind.DatatypeConverter;
import static org.apache.commons.io.FileUtils.copyFile;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Component;
import static org.apache.maven.plugins.annotations.LifecyclePhase.INSTALL;
import org.apache.maven.plugins.annotations.Mojo;
import static org.apache.maven.plugins.annotations.ResolutionScope.TEST;
import org.apache.maven.project.MavenProject;
import org.signserver.deploytools.common.ZipFileUtils;
import static org.signserver.deploytools.maven.ProjectUtils.findProjectHome;

/**
 * Mojo for copying the target artifact to the projects (top-level) lib folder.
 *
 * @author Markus Kilås
 * @version $Id$
 */
@Mojo(name = "dist-module", requiresDependencyResolution = TEST,
        defaultPhase = INSTALL, threadSafe = true)
public class DistModuleMojo extends AbstractMojo {

    private String distJar;
    private String destDistJar;

    @Component
    protected MavenProject project;

    @Override
    public void execute() throws MojoExecutionException, MojoFailureException {
        distJar = project.getProperties().getProperty("dist.jar");
        destDistJar = project.getProperties().getProperty("dest.dist.jar", distJar);

        if (distJar != null) {
            File projectHome = findProjectHome(project);
            File destFile = new File(projectHome, "lib/" + destDistJar);
            final String fixedTime = project.getProperties().getProperty("dist.fixedTime");
            if (fixedTime == null || fixedTime.isEmpty()) {
                getLog().info("No fixedTime specified so not building with deterministic JAR file time-stamps");
                try {
                    copyFile(new File(project.getBasedir() + "/target/" + distJar), destFile);
                    getLog().info("Copied to " + destFile.getAbsolutePath());
                } catch (IOException ex) {
                    throw new MojoExecutionException("Could not copy " + distJar + " to lib folder", ex);
                }
            } else {
                getLog().info("Using deterministic JAR filetime-stamps: \"" + fixedTime + "\"");
                final ZipFileUtils zipUtils = new ZipFileUtils(new MojoLogger(this));
                try {
                    zipUtils.copyJarWithSortedZipEntries(new File(project.getBasedir() + "/target/" + distJar), destFile);
                    getLog().info("Copied to " + destFile.getAbsolutePath());
                } catch (IOException ex) {
                    throw new MojoExecutionException("Could not copy " + distJar + " to lib folder", ex);
                }
                try {
                    zipUtils.rewriteZipEntriesLastModifiedTimeAndPomProperties(destFile.getAbsolutePath(), DatatypeConverter.parseDateTime(fixedTime).getTime().getTime());
                } catch (IOException | URISyntaxException ex) {
                    throw new MojoExecutionException("Filed to rewrite zip entries time-stamps", ex);
                }
            }
        } else {
            getLog().info("No dist.jar defined so not copying anything to lib");
        }
    }

}
