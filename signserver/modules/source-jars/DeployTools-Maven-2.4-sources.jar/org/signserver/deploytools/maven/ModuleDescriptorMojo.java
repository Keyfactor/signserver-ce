/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.maven;

import java.io.File;
import static java.io.File.separator;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import jakarta.xml.bind.DatatypeConverter;
import org.apache.commons.io.FileUtils;
import org.apache.maven.artifact.Artifact;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.dependency.fromDependencies.BuildClasspathMojo;
import static org.apache.maven.plugin.dependency.utils.DependencyUtil.getFormattedFileName;
import static org.apache.maven.plugins.annotations.LifecyclePhase.GENERATE_RESOURCES;
import org.apache.maven.plugins.annotations.Mojo;
import static org.apache.maven.plugins.annotations.ResolutionScope.TEST;
import org.apache.maven.shared.artifact.filter.collection.ArtifactsFilter;
import static org.codehaus.plexus.util.IOUtil.close;
import static org.signserver.deploytools.maven.ProjectUtils.findProjectHome;

/**
 * Mojo for creating the module descriptor based on information from Maven.
 *
 * @author Markus Kilås
 * @version $Id$
 */
@Mojo(name = "create-module-descriptor", requiresDependencyResolution = TEST,
        defaultPhase = GENERATE_RESOURCES, threadSafe = true)
public class ModuleDescriptorMojo extends BuildClasspathMojo {

    private static final String LOCAL_PREFIX = "lib/";
    private static final String EXTERNAL_PREFIX = "lib/ext/";

    private boolean stripVersion;
    private final boolean stripClassifier = false;

    private String distJar;
    private String destDistJar;

    @Override
    protected ArtifactsFilter getMarkedArtifactFilter() {
        return null;
    }

    @Override
    protected void doExecute() throws MojoExecutionException {

        this.includeScope = "runtime";
        this.excludeScope = "compile";
//        stripVersion = Boolean.parseBoolean(project.getProperties().getProperty("stripVersion", "false"));

        final String modName = project.getProperties().getProperty("module.name", project.getName());

        distJar = project.getProperties().getProperty("dist.jar");
        destDistJar = project.getProperties().getProperty("dest.dist.jar", distJar);

        String toLib = getDependencies(true, false, LOCAL_PREFIX, EXTERNAL_PREFIX, true, ",");
        String toRoot = getDependencies(false, true, LOCAL_PREFIX, EXTERNAL_PREFIX, true, ",");

        // Get depencies for root and for lib with prefix in lib and not including self
        String classpath = getDependencies(true, true, "", "ext/", false, " ");

        final String modulePriority = project.getProperties().getProperty("module.priority");
        final String staticDescriptor = project.getProperties().getProperty("staticDescriptor");

        if (modulePriority != null) {
            Properties properties = new Properties();
            properties.setProperty("module.name", modName);
            properties.setProperty("module.type", moduleTypeFromPackaging(project.getPackaging()));
            properties.setProperty("to.lib", toLib);
            properties.setProperty("to.root", toRoot);

            final String toConfig = project.getProperties().getProperty("to.config");
            if (toConfig != null) {
                properties.setProperty("to.config", toConfig);
            }

            final String type = project.getArtifact().getType();
            if (type.equals("ejb") || type.equals("war") || type.equals("rar")) {
                properties.setProperty("module." + type, project.getProperties().getProperty("dist.jar"));
            }

            for (String propertyName : project.getProperties().stringPropertyNames()) {
                if (propertyName.startsWith("postprocess.") || propertyName.startsWith("module.web.")) {
                    properties.setProperty(propertyName, project.getProperties().getProperty(propertyName));
                }
            }

            File projectHome = findProjectHome(project);

            File descriptorDir = new File(projectHome, "/mods-available/");
            if (!descriptorDir.exists()) {
                descriptorDir.mkdir();
            }

            File file = new File(descriptorDir, modulePriority + "_" + modName + ".properties");
            OutputStream out = null;
            try {
                out = new FileOutputStream(file);
                properties.store(out, "DeployTools Module Descriptor");
                getLog().info("Wrote module descriptor '" + file.getAbsolutePath());
            } catch (IOException ex) {
                throw new MojoExecutionException("Unable to write descriptor file: " + file, ex);
            } finally {
                close(out);
            }
            
            final String fixedTime = project.getProperties().getProperty("dist.fixedTime");
            if (fixedTime == null || fixedTime.isEmpty()) {
                getLog().info("No fixedTime specified so not building with deterministic descriptors");
            } else {
                getLog().info("Using deterministic descriptor time-stamps: \"" + fixedTime + "\"");
                
                // Format the time-stamp
                final SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.ENGLISH);
                sdf.setTimeZone(TimeZone.getTimeZone("GMT"));
                final String timeStamp = sdf.format(new Date(DatatypeConverter.parseDateTime(fixedTime).getTime().getTime()));
                
                try {
                    Path path = file.toPath();
                    Charset latin1 = Charset.forName("latin1");
                    List<String> propFileLines = Files.readAllLines(path, latin1);
                    propFileLines.set(1, "#" + timeStamp);
                    Files.write(path, propFileLines, latin1, StandardOpenOption.TRUNCATE_EXISTING);
                    getLog().debug("Rewrote time in module descriptor");
                } catch (IOException ex) {
                    throw new MojoExecutionException("Failed to set deterministic time in " + file, ex);
                }
            }
            
        } else if (staticDescriptor != null) {
            File descriptorDir = new File(project.getBasedir(), "../../mods-available/");
            if (!descriptorDir.exists()) {
                descriptorDir.mkdir();
            }

            File inFile = new File(project.getBasedir(), "src/main/resources/" + staticDescriptor);
            File inFileAlt2 = new File(project.getBasedir(), "src/" + staticDescriptor);
            if (!inFile.exists() && inFileAlt2.exists()) { // Backwards compatibility for SignServer
                inFile = inFileAlt2;
            }

            File file = new File(descriptorDir, staticDescriptor);
            try {
                FileUtils.copyFile(inFile, file);
                getLog().info("Copied module descriptor '" + file.getAbsolutePath());
            } catch (IOException ex) {
                throw new MojoExecutionException("Unable to copy static descriptor file: " + staticDescriptor, ex);
            }
        } else {
            getLog().info("No module.priority defined so not a module");
        }

        // classpath.properties
        File targetDir = new File(project.getBasedir(), "target");
        if (!targetDir.exists()) {
            targetDir.mkdir();
        }
        File classpathFile = new File(targetDir, "classpath.properties");

        Properties properties = new Properties();
        properties.setProperty("jar.classpath", createManifestEntryValue("Class-path: ".length(), classpath));

        OutputStream out = null;
        try {
            out = new FileOutputStream(classpathFile);
            properties.store(out, null);
            getLog().debug("Wrote classpath file: " + classpathFile.getAbsolutePath());
        } catch (IOException ex) {
            throw new MojoExecutionException("Could not output classpath.properties: " + ex.getMessage(), ex);
        } finally {
            close(out);
        }

    }

    private String moduleTypeFromPackaging(final String packaging) {
        final String result;
        if ("jar".equals(packaging)) {
            result = "lib";
        } else if ("war".equals(packaging)) {
            result = "war";
        } else if ("ejb".equals(packaging)) {
            result = "ejb";
        } else if ("rar".equals(packaging)) {
            result = "connector";
        } else {
            throw new IllegalArgumentException("Unsupported packaging type: " + packaging);
        }
        return result;
    }

    protected void appendArtifactPath(Artifact art, StringBuilder sb, String prefix) {
        sb.append(prefix);
        sb.append(separator);
        sb.append(getFormattedFileName(art, this.stripVersion, this.prependGroupId, this.useBaseVersion, this.stripClassifier));
    }

    private String getDependencies(final boolean includeLib, final boolean includeRoot, final String localPrefix, final String externalPrefix, final boolean self, final String separator) {
        final StringBuilder result = new StringBuilder();

        Set<Artifact> artifacts = project.getArtifacts();
        boolean first = true;
        for (Artifact a : artifacts) {
            if (!a.getScope().equals("provided") && !a.getScope().equals("test")) {
                if ((includeRoot && !isTypeForLib(a.getType())) || (includeLib && isTypeForLib(a.getType()))) {
                    if (!first) {
                        result.append(separator);
                    }
                    first = false;
                    if (project.getGroupId().equals(a.getGroupId())) {
                        result.append(localPrefix);
                    } else {
                        result.append(externalPrefix);
                    }

                    // Use the expected file name (Note that Artifact.getFile() has been shown to be unreliable in some environments, i.e. 
                    // Docker as it then simply returns "classes". Therefor we use this method instead.
                    result.append(getFormattedFileName(a, this.stripVersion, this.prependGroupId, this.useBaseVersion, this.stripClassifier));
                }
            }
        }

        if (self) {
            if (distJar != null) {
                if ((includeRoot && !isTypeForLib(project.getArtifact().getType())) || (includeLib && isTypeForLib(project.getArtifact().getType()))) {
                    if (!first) {
                        result.append(separator);
                    }
                    if (project.getGroupId().equals(project.getArtifact().getGroupId())) {
                        result.append(localPrefix);
                    } else {
                        result.append(externalPrefix);
                    }
                    result.append(destDistJar);
                }
            }
        }

        return result.toString();
    }

    private boolean isTypeForLib(String type) {
        return type.equals("jar");
    }

    private String createManifestEntryValue(int nameLength, String value) {
        final StringBuilder result = new StringBuilder();
        int row = nameLength;
        for (int i = 0; i < value.length(); i++) {
            if (row < 100) {
                row++;
            } else {
                result.append("\n ");
                row = 0;
            }
            result.append(value.charAt(i));
        }
        return result.toString();
    }

}
