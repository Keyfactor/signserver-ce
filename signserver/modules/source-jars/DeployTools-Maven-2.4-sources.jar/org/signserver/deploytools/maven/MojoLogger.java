/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.maven;

import org.apache.maven.plugin.Mojo;
import org.signserver.deploytools.common.LoggerFacade;

/**
 * LoggerFacade implementation for Maven.
 *
 * @author Markus Kilås
 * @version $Id$
 */
public class MojoLogger implements LoggerFacade {
    private final Mojo mojo;
    
    public MojoLogger(Mojo mojo) {
        this.mojo = mojo;
    }

    @Override
    public void logError(CharSequence msg, Throwable tw) {
        mojo.getLog().error(msg, tw);
    }

    @Override
    public void logWarning(CharSequence msg) {
        mojo.getLog().warn(msg);
    }

    @Override
    public void logInfo(CharSequence msg) {
        mojo.getLog().info(msg);
    }

    @Override
    public void logDebug(CharSequence msg) {
        mojo.getLog().debug(msg);
    }
}
