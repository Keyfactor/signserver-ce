/*************************************************************************
 *                                                                       *
 *  SignServer: The OpenSource Automated Signing Server                  *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.signserver.deploytools.maven;

import java.io.File;
import org.apache.maven.project.MavenProject;

/**
 * Utility methods that can be of use to multiple Mojos.
 *
 * @author Markus Kilås
 * @version $Id$
 */
public class ProjectUtils {

    /**
     * Given the current project finds and returns the first folder of a parent
     * project which contains a folder name "lib".
     * If no such folder exists the top-most parent folder is returned.
     * @param project to start searching above
     * @return The first parent folder with a "lib" folder or the top-most
     * project folder if no one with a lib folder can be found.
     */
    public static File findProjectHome(MavenProject project) { // TODO: Should add a property so a project can override this
        final File result;
        // Find project home as the first folder above this project with a "lib" folder
        MavenProject proj = project;
        while (!new File(proj.getBasedir(), "../lib").exists() && proj.hasParent()) {
            proj = proj.getParent();
        }
        result = new File(proj.getBasedir(), "..");
        return result;
    }
}
