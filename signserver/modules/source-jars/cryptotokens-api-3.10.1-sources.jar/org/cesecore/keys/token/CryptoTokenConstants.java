/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.cesecore.keys.token;

/**
 */
public final class CryptoTokenConstants {
    public static final String SIGNKEYALGORITHM  = "SIGNKEYALGORITHM";
    public static final String ENCKEYALGORITHM   = "ENCKEYALGORITHM";
    public static final String KEYSTORE          = "KEYSTORE";

    /** Property for storing the AWS KMS region name in the crypto token properties.
     * KMS specific, this is a string that will be part of the REST call URI
     * https://kms." + region + ".amazonaws.com, i.e. https://kms.us-east-1.amazonaws.com
     */
    public static final String AWSKMS_REGION = "kmsRegion";

    public static final String AWSKMS_AUTHENTICATION_TYPE = "kmsAuthenticationType";

    /** Property for storing the accessKeyID used to access the AWS KMS, in the crypto token properties.
     */
    public static final String AWSKMS_ACCESSKEYID = "kmsSignInAccessKeyID";

    /**
     * Property for storing the base URL for the Fortanix DRM REST API ("https://apps.smartkey.io" is the default)
     */
    public static final String FORTANIX_BASE_ADDRESS = "fortanixBaseAddress";
    public static final String FORTANIX_BASE_ADDRESS_DEFAULT = "https://apps.smartkey.io";

    /**
     * Constant used to represent that a key attestation has been created by Fortanix.
     */
    public static final String FORTANIX_KEY_ATTESTATION_VENDOR = "Fortanix";

    /** Property for storing the Securosys HSM REST-API name in the crypto token properties.
     * Securosys TSB name, this is the string that will be part of the REST call URI
     * For example "primusdev", "sbx" etc.
     */
    public static final String SECUROSYS_REST_API = "securosysRestApi";
    /**
     * Determines how we will authenticate to Securosys HSM.
     */
    public static final String SECUROSYS_AUTHENTICATION_TYPE = "securosysAuthenticationType";
    /**
     * If AuthType set to CERT.
     */
    public static final String SECUROSYS_AUTH_CERT = "securosysAuthCert";
    /**
     * Authentication Management key Securosys HSM.
     */
    public static final String SECUROSYS_MANAGEMENT_KEY = "securosysManagementKey";
    /**
     * Authentication Operation key Securosys HSM.
     */
    public static final String SECUROSYS_OPERATION_KEY = "securosysOperationKey";
    /**
     * Authentication Service key Securosys HSM.
     */
    public static final String SECUROSYS_SERVICE_KEY = "securosysServiceKey";
    /**
     * Timeout for approval, only for keys with specific policy.
     */
    public static final String SECUROSYS_APPROVAL_TIMEOUT = "securosysApprovalTimeout";

}