/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.cesecore.keys.token;

import java.util.Optional;

import com.keyfactor.util.keys.token.CryptoTokenOfflineException;

/** Represents a generic way to find a certificate and key given an ID. */
public interface KeyAndCertFinder {

    Optional<KeyAndCertificateInfo> find(int id) throws CryptoTokenOfflineException;

}
