/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package org.cesecore.keys.token;

import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.List;

/**
 * Transport DTO which represents a private key reference, an X509 certificate and its chain.
 */

public class KeyAndCertificateInfo {

	private final PrivateKey privateKey;
    private final X509Certificate x509Certificate;
    private final List<X509Certificate> chain;
    
    public KeyAndCertificateInfo(final PrivateKey privateKey, final X509Certificate x509Certificate, final List<X509Certificate> chain) {
        this.privateKey = privateKey;
        this.x509Certificate = x509Certificate;
        this.chain = chain;
    }

    public PrivateKey getPrivateKey() {
        return privateKey;
    }

    public X509Certificate getX509Certificate() {
        return x509Certificate;
    }

    public List<X509Certificate> getChain() {
        return chain;
    }
}
