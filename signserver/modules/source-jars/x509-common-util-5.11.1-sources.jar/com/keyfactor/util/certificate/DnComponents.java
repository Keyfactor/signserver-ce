/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/

package com.keyfactor.util.certificate;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.cert.Certificate;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.regex.Pattern;

import com.keyfactor.util.CeSecoreNameStyle;
import com.keyfactor.util.CertTools;
import com.keyfactor.util.RFC4683Tools;
import com.keyfactor.util.StringTools;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1EncodableVector;
import org.bouncycastle.asn1.ASN1GeneralString;
import org.bouncycastle.asn1.ASN1IA5String;
import org.bouncycastle.asn1.ASN1Integer;
import org.bouncycastle.asn1.ASN1Object;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.ASN1UTF8String;
import org.bouncycastle.asn1.DERGeneralString;
import org.bouncycastle.asn1.DERIA5String;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.DERSequence;
import org.bouncycastle.asn1.DERTaggedObject;
import org.bouncycastle.asn1.DERUTF8String;
import org.bouncycastle.asn1.x500.AttributeTypeAndValue;
import org.bouncycastle.asn1.x500.RDN;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.X500NameStyle;
import org.bouncycastle.asn1.x500.style.IETFUtils;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.util.encoders.Hex;

/** Class holding information and utilities for handling different DN components, CN, O etc
 *
 * This is a very complex class with lots of maps and stuff. It is because it is a first step of refactoring the DN/AltName/DirAttr handling.
 * This previously consisted of lots of different arrays spread out all over the place, now it's gathered here in order to be able to get a view of it.
 * The underlying implementations have not changed much though, in order to still have things working, therefore there are lots of different maps and arrays, with
 * seemingly similar contents.
 *
 * Adding new DN attributes:
 * - dncomponents.properties.sample
 * - profilemappings.properties
 * - DnComponents.java (this file)
 * - CeSecoreNameStyle.java
 * - DNFieldExtractor.java
 * - DNFIeldExtractorTest
 * - DnComponentsTest
 * - CertToolsUnitTest
 * - UserFulFillEndEntityProfileTest
 * - (other tests)
 */
public class DnComponents {
    private static Logger log = Logger.getLogger(DnComponents.class);

    /** This class should be instantiated immediately */
    private static DnComponents obj = new DnComponents();


    private static final Pattern UNESCAPE_FIELD_REGEX = Pattern.compile("\\\\([,+\"\\\\<>; ])");


    /** BC X500Name contains some lookup tables that could maybe be used here.
     *
     * This map is used in CertTools so sort and order DN strings so they all look the same in the database.
     * */
    private static HashMap<String, ASN1ObjectIdentifier> oids = new HashMap<>();
    // Default values
    static {
        oids.put("c", CeSecoreNameStyle.C);
        oids.put("dc", CeSecoreNameStyle.DC);
        oids.put("st", CeSecoreNameStyle.ST);
        oids.put("l", CeSecoreNameStyle.L);
        oids.put("o", CeSecoreNameStyle.O);
        oids.put("ou", CeSecoreNameStyle.OU);
        oids.put("t", CeSecoreNameStyle.T);
        oids.put("surname", CeSecoreNameStyle.SURNAME);
        oids.put("initials", CeSecoreNameStyle.INITIALS);
        oids.put("givenname", CeSecoreNameStyle.GIVENNAME);
        oids.put("gn", CeSecoreNameStyle.GIVENNAME);
        oids.put("sn", CeSecoreNameStyle.SERIALNUMBER);
        oids.put("serialnumber", CeSecoreNameStyle.SERIALNUMBER);
        oids.put("cn", CeSecoreNameStyle.CN);
        oids.put("uid", CeSecoreNameStyle.UID);
        oids.put("dn", CeSecoreNameStyle.DN_QUALIFIER);
        oids.put("emailaddress", CeSecoreNameStyle.EmailAddress);
        oids.put("e", CeSecoreNameStyle.EmailAddress);
        oids.put("email", CeSecoreNameStyle.EmailAddress);
        oids.put("unstructuredname", CeSecoreNameStyle.UnstructuredName); //unstructuredName
        oids.put("unstructuredaddress", CeSecoreNameStyle.UnstructuredAddress); //unstructuredAddress
        oids.put("postalcode", CeSecoreNameStyle.POSTAL_CODE);
        oids.put("businesscategory", CeSecoreNameStyle.BUSINESS_CATEGORY);
        oids.put("postaladdress", CeSecoreNameStyle.POSTAL_ADDRESS);
        oids.put("telephonenumber", CeSecoreNameStyle.TELEPHONE_NUMBER);
        oids.put("pseudonym", CeSecoreNameStyle.PSEUDONYM);
        oids.put("street", CeSecoreNameStyle.STREET);
        oids.put("name", CeSecoreNameStyle.NAME);
        oids.put("role", CeSecoreNameStyle.ROLE);
        oids.put("description", CeSecoreNameStyle.DESCRIPTION);
        oids.put("jurisdictionlocality", CeSecoreNameStyle.JURISDICTION_LOCALITY);
        oids.put("jurisdictionstate", CeSecoreNameStyle.JURISDICTION_STATE);
        oids.put("jurisdictioncountry", CeSecoreNameStyle.JURISDICTION_COUNTRY);
        oids.put("organizationidentifier", CeSecoreNameStyle.ORGANIZATION_IDENTIFIER);
        oids.put("vid", CeSecoreNameStyle.VID);
        oids.put("pid", CeSecoreNameStyle.PID);
        oids.put("rcacid", CeSecoreNameStyle.RCACID);
        oids.put("icacid", CeSecoreNameStyle.ICACID);
        oids.put("nodeid", CeSecoreNameStyle.NODEID);
        oids.put("fabricid", CeSecoreNameStyle.FABRICID);
        oids.put("noccat", CeSecoreNameStyle.NOCCAT);
        oids.put("fwsigningid", CeSecoreNameStyle.FWSIGNINGID);
        oids.put("uniqueidentifier", CeSecoreNameStyle.UNIQUE_IDENTIFIER);
        oids.put("certificationid", CeSecoreNameStyle.CERTIFICATIONID);
        oids.put("legalentityidentifier", CeSecoreNameStyle.LEGALENTITYIDENTIFIER);
        oids.put("marktype", CeSecoreNameStyle.MARKTYPE);
        oids.put("trademarkcountryorregionname", CeSecoreNameStyle.TRADEMARKCOUNTRYORREGIONNAME);
        oids.put("trademarkofficename", CeSecoreNameStyle.TRADEMARKOFFICENAME);
        oids.put("trademarkidentifier", CeSecoreNameStyle.TRADEMARKIDENTIFIER);
        oids.put("wordmark", CeSecoreNameStyle.WORDMARK);
        oids.put("statutelocalityname", CeSecoreNameStyle.STATUTELOCALITYNAME);
        oids.put("statutestateorprovincename", CeSecoreNameStyle.STATUTESTATEORPROVINCENAME);
        oids.put("statutecountryname", CeSecoreNameStyle.STATUTECOUNTRYNAME);
        oids.put("statutecitation", CeSecoreNameStyle.STATUTECITATION);
        oids.put("statuteurl", CeSecoreNameStyle.STATUTEURL);
        oids.put("priorusemarksourceurl", CeSecoreNameStyle.PRIORUSEMARKSOURCEURL);

    }
    /** Default values used when constructing DN strings that are put in the database
     *
     */
    private static String[] dNObjectsForward = { "certificationid", "description", "jurisdictioncountry", "jurisdictionstate", "jurisdictionlocality", "role", "street", "pseudonym",
            "telephonenumber", "postaladdress", "businesscategory", "postalcode", "unstructuredaddress", "unstructuredname",
            "wordmark", "priorusemarksourceurl", "trademarkidentifier", "legalentityidentifier", "statuteurl", "statutecitation", "trademarkofficename",
            "statutelocalityname", "statutestateorprovincename", "trademarkcountryorregionname", "statutecountryname", "marktype",
            "emailaddress", "e", "email", "dn", "uniqueidentifier", "uid", "pid", "vid", "rcacid", "icacid", "nodeid", "fabricid", "noccat", "fwsigningid",
            "cn", "name", "sn", "serialnumber", "gn", "givenname", "initials", "surname", "t", "ou", "organizationidentifier", "o", "l", "st", "dc", "c" };
    // Default values
    private static String[] dNObjectsReverse = null;

    /**
     * These maps and constants are used in the admin-GUI and in End Entity profiles
     */

    /** These constants can be used when referring to standard, build in components
     *
     */
    // DN components
    public static final String DNEMAILADDRESS = "EMAILADDRESS";
    public static final String DNQUALIFIER = "DNQUALIFIER";
    public static final String UNIQUEIDENTIFIER = "UNIQUEIDENTIFIER";
    public static final String UID = "UID";
    public static final String COMMONNAME = "COMMONNAME";
    public static final String DNSERIALNUMBER = "SERIALNUMBER";
    public static final String GIVENNAME = "GIVENNAME";
    public static final String INITIALS = "INITIALS";
    public static final String SURNAME = "SURNAME";
    public static final String TITLE = "TITLE";
    public static final String ORGANIZATIONALUNIT = "ORGANIZATIONALUNIT";
    public static final String ORGANIZATION = "ORGANIZATION";
    public static final String LOCALITY = "LOCALITY";
    public static final String STATEORPROVINCE = "STATEORPROVINCE";
    public static final String DOMAINCOMPONENT = "DOMAINCOMPONENT";
    public static final String COUNTRY = "COUNTRY";
    public static final String UNSTRUCTUREDADDRESS = "UNSTRUCTUREDADDRESS";
    public static final String UNSTRUCTUREDNAME = "UNSTRUCTUREDNAME";
    public static final String POSTALCODE = "POSTALCODE";
    public static final String BUSINESSCATEGORY = "BUSINESSCATEGORY";
    public static final String POSTALADDRESS = "POSTALADDRESS";
    public static final String TELEPHONENUMBER = "TELEPHONENUMBER";
    public static final String PSEUDONYM = "PSEUDONYM";
    public static final String STREETADDRESS = "STREETADDRESS";
    public static final String NAME = "NAME";
    public static final String ROLE = "ROLE";
    public static final String DESCRIPTION = "DESCRIPTION";
    public static final String JURISDICTIONLOCALITY = "JURISDICTIONLOCALITY"; // CAB Forum
    public static final String JURISDICTIONSTATE = "JURISDICTIONSTATE"; // CAB Forum
    public static final String JURISDICTIONCOUNTRY = "JURISDICTIONCOUNTRY"; // CAB Forum
    public static final String ORGANIZATIONIDENTIFIER = "ORGANIZATIONIDENTIFIER"; // CAB Forum
    public static final String VID = "VID"; // Matter IoT core spec
    public static final String PID = "PID"; // Matter IoT core spec
    public static final String RCACID = "RCACID"; // Matter IoT core spec
    public static final String ICACID = "ICACID"; // Matter IoT core spec
    public static final String NODEID = "NODEID"; // Matter IoT core spec
    public static final String FABRICID = "FABRICID"; // Matter IoT core spec
    public static final String NOCCAT = "NOCCAT"; // Matter IoT core spec
    public static final String FWSIGNINGID = "FWSIGNINGID"; // Matter IoT core spec
    public static final String CERTIFICATIONID = "CERTIFICATIONID"; // BSI TR03145-5
    public static final String LEGALENTITYIDENTIFIER = "LEGALENTITYIDENTIFIER"; // Mark Certificates
    public static final String MARKTYPE = "MARKTYPE"; // Mark Certificates
    public static final String TRADEMARKCOUNTRYORREGIONNAME = "TRADEMARKCOUNTRYORREGIONNAME"; // Mark Certificates
    public static final String TRADEMARKOFFICENAME = "TRADEMARKOFFICENAME"; // Mark Certificates
    public static final String TRADEMARKIDENTIFIER = "TRADEMARKIDENTIFIER"; // Mark Certificates
    public static final String WORDMARK = "WORDMARK"; // Mark Certificates
    public static final String STATUTELOCALITYNAME = "STATUTELOCALITYNAME"; // Mark Certificates
    public static final String STATUTESTATEORPROVINCENAME = "STATUTESTATEORPROVINCENAME"; // Mark Certificates
    public static final String STATUTECOUNTRYNAME = "STATUTECOUNTRYNAME"; // Mark Certificates
    public static final String STATUTECITATION = "STATUTECITATION"; // Mark Certificates
    public static final String STATUTEURL = "STATUTEURL"; // Mark Certificates
    public static final String PRIORUSEMARKSOURCEURL = "PRIORUSEMARKSOURCEURL"; // Mark Certificates

    public static final String EMAIL = "rfc822name";
    public static final String EMAIL1 = "email";
    public static final String EMAIL2 = "EmailAddress";
    public static final String EMAIL3 = "E";

    public static final String DNS = "dNSName";
    public static final String IPADDR = "iPAddress";


    public static final String PERMANENTIDENTIFIER_SEP = "/";
    public static final String HARDWAREMODULENAME_SEP = "/";
    // AltNames
    public static final String RFC822NAME = "RFC822NAME";
    public static final String DNSNAME = "DNSNAME";
    public static final String IPADDRESS = "IPADDRESS";
    public static final String URI = "UNIFORMRESOURCEIDENTIFIER";
    public static final String URI1 = "URI";
    public static final String URI2 = "uniformResourceId";
    public static final String UNIFORMRESOURCEID = "UNIFORMRESOURCEID";
    public static final String DIRECTORYNAME = "DIRECTORYNAME";
    public static final String UPN = "UPN";
    public static final String XMPPADDR = "XMPPADDR";
    public static final String SRVNAME = "SRVNAME";
    public static final String FASCN = "FASCN";
    public static final String GUID = "GUID";
    public static final String KRB5PRINCIPAL = "KRB5PRINCIPAL";
    public static final String PERMANENTIDENTIFIER = "PERMANENTIDENTIFIER";
    public static final String HARDWAREMODULENAME = "HARDWAREMODULENAME";
    public static final String SUBJECTIDENTIFICATIONMETHOD = "SUBJECTIDENTIFICATIONMETHOD";
    // Below are altNames that are not implemented yet
    public static final String OTHERNAME = "OTHERNAME";
    public static final String X400ADDRESS = "X400ADDRESS";
    public static final String EDIPARTYNAME = "EDIPARTYNAME";
    /// RegisteredID is a standard (rfc5280 otherName that we implement)
    public static final String REGISTEREDID = "REGISTEREDID";

    // Subject directory attributes
    public static final String DATEOFBIRTH = "DATEOFBIRTH";
    public static final String PLACEOFBIRTH = "PLACEOFBIRTH";
    public static final String GENDER = "GENDER";
    public static final String COUNTRYOFCITIZENSHIP = "COUNTRYOFCITIZENSHIP";
    public static final String COUNTRYOFRESIDENCE = "COUNTRYOFRESIDENCE";

    /** ObjectID for upn altName for windows smart card logon */
    public static final String UPN_OBJECTID = "1.3.6.1.4.1.311.20.2.3";
    /** ObjectID for XmppAddr, rfc6120#section-13.7.1.4 */
    public static final String XMPPADDR_OBJECTID = "1.3.6.1.5.5.7.8.5";
    /** ObjectID for srvName, rfc4985 */
    public static final String SRVNAME_OBJECTID =  "1.3.6.1.5.5.7.8.7";
    public static final String FASCN_OBJECTID =  "2.16.840.1.101.3.6.6";
    public static final String PERMANENTIDENTIFIER_OBJECTID = "1.3.6.1.5.5.7.8.3";
    public static final String HARDWAREMODULENAME_OBJECTID = "1.3.6.1.5.5.7.8.4";
    /** ObjectID for upn altName for windows domain controller guid */
    public static final String GUID_OBJECTID = "1.3.6.1.4.1.311.25.1";
    /** OID for Kerberos altName for smart card logon */
    public static final String KRB5PRINCIPAL_OBJECTID = "1.3.6.1.5.2.2";

    private static final String[] EMAILIDS = { EMAIL, EMAIL1, EMAIL2, EMAIL3 };

    private static Map<String, Integer> dnNameToIdMap = new HashMap<>();
    private static Map<String, Integer> altNameToIdMap = new HashMap<>();
    private static Map<String, Integer> dirAttrToIdMap = new HashMap<>();
    private static Map<String, Integer> profileNameIdMap = new HashMap<>();
    private static Map<Integer, String> dnIdToProfileNameMap = new HashMap<>();
    private static Map<Integer, Integer> dnIdToProfileIdMap = new HashMap<>();
    private static Map<Integer, Integer> profileIdToDnIdMap = new HashMap<>();
    private static Map<Integer, String> dnErrorTextMap = new HashMap<>();
    private static Map<String, String> profileNameLanguageMap = new HashMap<>();
    private static Map<Integer, String> profileIdLanguageMap = new HashMap<>();
    private static Map<Integer, String> dnIdErrorMap = new HashMap<>();
    private static Map<Integer, String> dnIdToExtractorFieldMap = new HashMap<>();
    private static Map<Integer, String> altNameIdToExtractorFieldMap = new HashMap<>();
    private static Map<Integer, String> dirAttrIdToExtractorFieldMap = new HashMap<>();
    private static List<String> dnProfileFields = new ArrayList<>();
    private static final Set<String> dnProfileFieldsHashSet = new TreeSet<>();
    private static List<String> dnLanguageTexts = new ArrayList<>();
    private static List<Integer> dnDnIds = new ArrayList<>();
    private static List<String> altNameFields = new ArrayList<>();
    private static final Set<String> altNameFieldsHashSet = new TreeSet<>();
    private static List<String> altNameLanguageTexts = new ArrayList<>();
    private static List<Integer> altNameDnIds = new ArrayList<>();
    private static List<String> dirAttrFields = new ArrayList<>();
    private static final Set<String> dirAttrFieldsHashSet = new TreeSet<>();
    private static List<String> dirAttrLanguageTexts = new ArrayList<>();
    private static List<Integer> dirAttrDnIds = new ArrayList<>();
    private static List<String> dnExtractorFields = new ArrayList<>();
    private static List<String> altNameExtractorFields = new ArrayList<>();
    private static List<String> dirAttrExtractorFields = new ArrayList<>();




    // Load values from a properties file, if it exists
    static {
        DnComponents.load();
    }

    public static Integer getDnIdFromDnName(final String dnName) {
        return dnNameToIdMap.get(dnName.toUpperCase(Locale.ROOT));
    }

    public static Integer getDnIdFromAltName(final String altName) {
        return altNameToIdMap.get(altName.toUpperCase(Locale.ROOT));
    }

    public static Integer getDnIdFromDirAttr(final String dirAttr) {
        return dirAttrToIdMap.get(dirAttr.toUpperCase(Locale.ROOT));
    }

    public static ASN1ObjectIdentifier getOid(String o) {
        return oids.get(o.toLowerCase(Locale.ROOT));
    }

    public static List<String> getDnProfileFields() {
        return dnProfileFields;
    }

    public static boolean isDnProfileField(String field) {
        return dnProfileFieldsHashSet.contains(field);
    }

    public static List<String> getDnLanguageTexts() {
        return dnLanguageTexts;
    }

    public static List<String> getAltNameFields() {
        return altNameFields;
    }

    public static boolean isAltNameField(String field) {
        return altNameFieldsHashSet.contains(field);
    }

    public static List<String> getAltNameLanguageTexts() {
        return altNameLanguageTexts;
    }

    public static List<String> getDirAttrFields() {
        return dirAttrFields;
    }

    public static boolean isDirAttrField(String field) {
        return dirAttrFieldsHashSet.contains(field);
    }

    // Used by DNFieldExtractor and EntityProfile, don't USE
    public static List<Integer> getDirAttrDnIds() {
        return dirAttrDnIds;
    }

    // Used by DNFieldExtractor and EntityProfile, don't USE
    public static List<Integer> getAltNameDnIds() {
        return altNameDnIds;
    }

    // Used by DNFieldExtractor and EntityProfile, don't USE
    public static List<Integer> getDnDnIds() {
        return dnDnIds;
    }

    // Used only by DNFieldExtractor, don't USE
    protected static List<String> getDnExtractorFields() {
        return dnExtractorFields;
    }

    public static String getDnExtractorFieldFromDnId(int field) {
        return dnIdToExtractorFieldMap.get(field);
    }

    // Used only by DNFieldExtractor, don't USE
    public static List<String> getAltNameExtractorFields() {
        return altNameExtractorFields;
    }

    public static String getAltNameExtractorFieldFromDnId(int field) {
        return altNameIdToExtractorFieldMap.get(field);
    }

    // Used only by DNFieldExtractor, don't USE
    protected static List<String> getDirAttrExtractorFields() {
        return dirAttrExtractorFields;
    }

    public static String getDirAttrExtractorFieldFromDnId(int field) {
        return dirAttrIdToExtractorFieldMap.get(field);
    }

    public static String dnIdToProfileName(int dnid) {
        return dnIdToProfileNameMap.get(dnid);
    }

    public static int dnIdToProfileId(int dnid) {
        return dnIdToProfileIdMap.get(dnid);
    }

    /**
     * Method to get a language error constant for the admin-GUI from a profile name
     */
    public static String getLanguageConstantFromProfileName(String name) {
        return profileNameLanguageMap.get(name);
    }

    /**
     * Method to get a language error constant for the admin-GUI from a profile id
     */
    public static String getLanguageConstantFromProfileId(int id) {
        return profileIdLanguageMap.get(id);
    }

    /**
     * Method to get a clear text error msg for the admin-GUI from a dn id
     */
    public static String getErrTextFromDnId(int id) {
        return dnIdErrorMap.get(id);
    }

    /** This method is only used to initialize EndEntityProfile, because of legacy baggage.
     * Should be refactored sometime! Please don't use this whatever you do!
     */
    public static Map<String, Integer> getProfilenameIdMap() {
        return profileNameIdMap;

    }

    /** A function that takes an fieldId pointing to a corresponding id in UserView and DnFieldExctractor.
     *  For example : profileFieldIdToUserFieldIdMapper(EndEntityProfile.COMMONNAME) returns DnFieldExctractor.COMMONNAME.
     *
     *  Should only be used with subjectDN, Subject Alternative Names and subject directory attribute fields.
     *
     *  @throws IllegalArgumentException on unknown attributes
     */
    public static int profileIdToDnId(int profileId) {
        final Integer val = profileIdToDnIdMap.get(profileId);
        if (val == null) {
            final String msg = "No DN ID mapping from Profile ID " + profileId;
            log.error(msg);
            throw new IllegalArgumentException(msg);
        }
        return val;
    }

    /**
     * Returns the dnObjects (forward or reverse).
     * ldaporder = true is the default order in EJBCA.
     */
    public static String[] getDnObjects(boolean ldaporder) {
        if (ldaporder) {
            return dNObjectsForward;
        }
        return getDnObjectsReverse();
    }

    /**
     * Returns the reversed dnObjects.
     * Protected to allow testing
     */
    protected static String[] getDnObjectsReverse() {
        // Create and reverse the order if it has not been initialized already
        if (dNObjectsReverse == null) {
            dNObjectsReverse = dNObjectsForward.clone();
            ArrayUtils.reverse(dNObjectsReverse);
        }
        return dNObjectsReverse;
    }

    private static void load() {
        loadOrdering();
        loadMappings();
    }

    /**
     * Load DN ordering used in CertTools.stringToBCDNString etc.
     * Loads from file placed in src/dncomponents.properties
     *
     * A line is:
     * DNName;DNid;ProfileName;ProfileId,ErrorString,LanguageConstant
     *
     */
    private static void loadMappings() {
        loadProfileMappingsFromFile("/profilemappings.properties");
        loadProfileMappingsFromFile("/profilemappings_enterprise.properties");
    }

    public static boolean enterpriseMappingsExist() {
        return obj.getClass().getResourceAsStream("/profilemappings_enterprise.properties") != null;
    }


    /**
     * Checks if a DN has at least two components. Then the DN can be in either LDAP or X500 order.
     * Otherwise it's not possible to determine the order.
     */
    public static boolean dnHasMultipleComponents(String dn) {
        final X509NameTokenizer xt = new X509NameTokenizer(dn);
        if (xt.hasMoreTokens()) {
            xt.nextToken();
            return xt.hasMoreTokens();
        }
        return false;
    }

    /**
     * Get first commonName value from subjectDn. If none is present, return null
     * @param subjectDn subjectDn value
     * @return First commonName, or null
     */
    public static String getCommonNameFromSubjectDn(String subjectDn) {
        String commonName = null;
        if(subjectDn != null) {
            List<String> commonNames = getPartsFromDN(subjectDn, "CN");
            if (!commonNames.isEmpty() && StringUtils.isNotEmpty(commonNames.get(0))) {
                commonName = commonNames.get(0);
            }
        }
        return commonName;
    }

    /**
     * Gets a list of all custom OIDs defined in the string. A custom OID is defined as an OID, simply as that. Otherwise, if it is not a custom oid,
     * the DNpart is defined by a name such as CN och rfc822Name. This method only returns a oid once, so if the input string has multiple of the same
     * oid, only one value is returned.
     *
     * @param dn String containing DN, The DN string has the format "C=SE, O=xx, OU=yy, CN=zz", or "rfc822Name=foo@bar.com", etc.
     * @param dn String specifying which part of the DN to get, should be "CN" or "OU" etc.
     *
     * @return ArrayList containing unique oids or empty list if no custom OIDs are present
     */
    public static List<String> getCustomOids(String dn) {
        if (log.isTraceEnabled()) {
            log.trace(">getCustomOids: dn:'" + dn);
        }
        List<String> parts = new ArrayList<>();
        if (dn != null) {
            String o;
            X509NameTokenizer xt = new X509NameTokenizer(dn);
            while (xt.hasMoreTokens()) {
                o = xt.nextToken().trim();
                // Try to see if it is a valid OID
                try {
                    int i = o.indexOf('=');
                    // An oid is never shorter than 3 chars and must start with 1.
                    if ((i > 2) && (o.charAt(1) == '.')) {
                        String oid = o.substring(0, i);
                        // If we have multiple of the same custom oid, don't claim that we have more
                        // This method will only return "unique" custom oids.
                        if (!parts.contains(oid)) {
                            // Check if it is a real oid, if it is not we will ignore it (IllegalArgumentException will be thrown)
                            new ASN1ObjectIdentifier(oid);
                            parts.add(oid);
                        }
                    }
                } catch (IllegalArgumentException e) {
                    // Not a valid oid
                }
            }
        }
        if (log.isTraceEnabled()) {
            log.trace("<getCustomOids: resulting DN part=" + parts.toString());
        }
        return parts;
    }

    /**
     * Convenience method for getting an email addresses from a DN. Uses {@link #getPartsFromDN(String,String)} internally, and searches for
     * {@link #EMAIL}, {@link #EMAIL1}, {@link #EMAIL2}, {@link #EMAIL3} and returns the first one found.
     *
     * @param dn the DN
     *
     * @return ArrayList containing email or empty list if email is not present
     */
    public static List<String> getEmailFromDN(String dn) {
        if (log.isTraceEnabled()) {
            log.trace(">getEmailFromDN(" + dn + ")");
        }
        ArrayList<String> ret = new ArrayList<>();
        for (int i = 0; i < EMAILIDS.length; i++) {
            List<String> emails = getPartsFromDN(dn, EMAILIDS[i]);
            if (!emails.isEmpty()) {
                ret.addAll(emails);
            }

        }
        if (log.isTraceEnabled()) {
            log.trace("<getEmailFromDN(" + dn + "): " + ret.size());
        }
        return ret;
    }

    /**
     * Returns the parent DN of a DN string, e.g. if the input is
     * "cn=User,dc=example,dc=com" then it would return "dc=example,dc=com".
     * @return an empty string if there is no parent DN.
     */
    public static String getParentDN(String dn) {
        final X509NameTokenizer tokenizer = new X509NameTokenizer(dn);
        tokenizer.nextToken();
        return tokenizer.getRemainingString();
    }

    /**
     * Gets a specified part of a DN. Specifically the first occurrence it the DN contains several instances of a part (i.e. cn=x, cn=y returns x).
     *
     * @param dn String containing DN, The DN string has the format "C=SE, O=xx, OU=yy, CN=zz".
     * @param dnpart String specifying which part of the DN to get, should be "CN" or "OU" etc.
     *
     * @return String containing dnpart or null if dnpart is not present
     */
    public static String getPartFromDN(String dn, String dnpart) {
        String part = null;
        final List<String> dnParts = getPartsFromDNInternal(dn, dnpart, true);
        if (!dnParts.isEmpty()) {
            part = dnParts.get(0);
        }
        return part;
    }

    /**
     * Gets a specified parts of a DN. Returns all occurrences as an ArrayList, also works if DN contains several
     * instances of a part (i.e. cn=x, cn=y returns {x, y, null}).
     *
     * @param dn String containing DN, The DN string has the format "C=SE, O=xx, OU=yy, CN=zz".
     * @param dnpart String specifying which part of the DN to get, should be "CN" or "OU" etc.
     *
     * @return ArrayList containing dnparts or empty list if dnpart is not present
     */
    public static List<String> getPartsFromDN(String dn, String dnpart) {
        return getPartsFromDNInternal(dn, dnpart, false);
    }

    /*
    * @param value String to enescape
    * @return value in unescaped RDN format
    */
   public static String getUnescapedRdnValue(final String value){
       if (StringUtils.isNotEmpty(value)) {
           return unescapeRDN(value);
       } else {
           return value;
       }
   }

   /**
    * Splits a DN into components.
    * @see X509NameTokenizer
    */
   public static List<String> getX500NameComponents(String dn) {
       List<String> ret = new ArrayList<>();
       if (StringUtils.isNotBlank(dn)) {
           X509NameTokenizer tokenizer = new X509NameTokenizer(dn);
           while (tokenizer.hasMoreTokens()) {
               ret.add(tokenizer.nextToken());
           }
       }
       return ret;
   }

   /**
    * Tries to determine if a DN is in reversed form. It does this by taking the last attribute and the first attribute. If the last attribute comes
    * before the first in the dNObjects array the DN is assumed to be in reversed order.
    *
    * The default ordering is: "CN=Tomas, O=PrimeKey, C=SE" (dNObjectsForward ordering in EJBCA) a dn or form "C=SE, O=PrimeKey, CN=Tomas" is
    * reversed.
    *
    * If the string has only one component (e.g. "CN=example.com") then this method returns false.
    * If the string does not contain any real DN components, it returns false.
    *
    * @param dn String containing DN to be checked, The DN string has the format "C=SE, O=xx, OU=yy, CN=zz".
    * @return true if the DN is believed to be in reversed order, false otherwise
    */
   public static boolean isDNReversed(String dn) {
       boolean ret = false;
       if (dn != null) {
           String first = null;
           String last = null;
           X509NameTokenizer xt = new X509NameTokenizer(dn);
           if (xt.hasMoreTokens()) {
               first = xt.nextToken().trim();
           }
           while (xt.hasMoreTokens()) {
               last = xt.nextToken().trim();
           }
           String[] dNObjects = DnComponents.getDnObjects(true);
           if ((first != null) && (last != null)) {
               // Be careful for bad input, that may not have any = sign in it
               final int fi = first.indexOf('=');
               first = first.substring(0, (fi != -1 ? fi : (first.length()-1)));
               final int li = last.indexOf('=');
               last = last.substring(0, (li != -1 ? li : (last.length()-1)));
               int firsti = 0, lasti = 0;
               for (int i = 0; i < dNObjects.length; i++) {
                   if (first.equalsIgnoreCase(dNObjects[i])) {
                       firsti = i;
                   }
                   if (last.equalsIgnoreCase(dNObjects[i])) {
                       lasti = i;
                   }
               }
               if (lasti < firsti) {
                   ret = true;
               }

           }
       }
       return ret;
   }

   /**
    * Obtains a List with the ASN1ObjectIdentifiers for dNObjects names, in the specified pre-defined order
    *
    * @param ldaporder if true the returned order are as defined in LDAP RFC (CN=foo,O=bar,C=SE), otherwise the order is a defined in X.500
    *            (C=SE,O=bar,CN=foo).
    * @return a List with ASN1ObjectIdentifiers defining the known order we require
    * @see getDnObjects(boolean)
    */
   public static List<ASN1ObjectIdentifier> getX509FieldOrder(boolean ldaporder) {
       return getX509FieldOrder(DnComponents.getDnObjects(ldaporder));
   }

   /**
    * Takes a DN and reverses it completely so the first attribute ends up last. C=SE,O=Foo,CN=Bar becomes CN=Bar,O=Foo,C=SE.
    *
    * @param dn String containing DN to be reversed, The DN string has the format "C=SE, O=xx, OU=yy, CN=zz".
    *
    * @return String containing reversed DN
    */
   public static String reverseDN(String dn) {
       if (log.isTraceEnabled()) {
           log.trace(">reverseDN: dn: " + dn);
       }
       String ret = null;
       if (dn != null) {
           String o;
           final BasicX509NameTokenizer xt = new BasicX509NameTokenizer(dn);
           StringBuilder buf = new StringBuilder();
           boolean first = true;
           while (xt.hasMoreTokens()) {
               o = xt.nextToken();
               // log.debug("token: "+o);
               if (!first) {
                   buf.insert(0, ",");
               } else {
                   first = false;
               }
               buf.insert(0, o);
           }
           if (buf.length() > 0) {
               ret = buf.toString();
           }
       }
       if (log.isTraceEnabled()) {
           log.trace("<reverseDN: resulting dn: " + ret);
       }
       return ret;
   }

   public static X500Name stringToBcX500Name(String dn, final X500NameStyle nameStyle, final boolean ldaporder, final String[] order, final boolean applyLdapToCustomOrder) {
       final X500Name x500Name = stringToUnorderedX500Name(dn, nameStyle);
       if (x500Name==null) {
           return null;
       }
       // -- Reorder fields
       final X500Name orderedX500Name = getOrderedX500Name(x500Name, ldaporder, order, applyLdapToCustomOrder, nameStyle);
       if (log.isTraceEnabled()) {
           log.trace(">stringToBcX500Name: x500Name=" + x500Name.toString() + " orderedX500Name=" + orderedX500Name.toString());
       }
       return orderedX500Name;
   }

   public static X500Name stringToUnorderedX500Name(String dn, final X500NameStyle nameStyle) {
       if (log.isTraceEnabled()) {
           log.trace(">stringToUnorderedX500Name: " + dn);
       }
       if (dn == null) {
           return null;
       }
       // If the entire DN is quoted (which is strange but legacy), we just remove these quotes and carry on
       if (dn.length() > 2 && dn.charAt(0) == '"' && dn.charAt(dn.length() - 1) == '"') {
           dn = dn.substring(1, dn.length() - 1);
       }
       final X500NameBuilder nameBuilder = new X500NameBuilder(nameStyle);
       // split DN string into RDNs, but if it is empty, don't try to split it
       // this means an empty X500Name will be returned, as according to the javadoc
       if (dn.length() > 0) {
           RDN[] rdns;
           // Will throw an IllegalArgumentException if the DN is badly formatted
           rdns = IETFUtils.rDNsFromString(dn, nameStyle);

           for (RDN rdn: rdns) {
               if (rdn.isMultiValued()) {
                   AttributeTypeAndValue avas[] = rdn.getTypesAndValues();
                   nameBuilder.addMultiValuedRDN(avas);
               } else {
                   AttributeTypeAndValue ava = rdn.getFirst();
                   nameBuilder.addRDN(ava);
               }
           }
       }

       // finally builds X500 name
       final X500Name x500Name = nameBuilder.build();
       if (log.isTraceEnabled()) {
           log.trace("<stringToUnorderedX500Name: x500Name=" + x500Name.toString());
       }
       return x500Name;
   }

   /**
    * Every DN-string should look the same. Creates a name string ordered and looking like we want it...
    *
    * @param dn String containing DN
    *
    * @return String containing DN, or empty string if dn does not contain any real DN components, or null if input is null
    */
   public static String stringToBCDNString(String dn) {
       // BC now seem to handle multi-valued RDNs, but we keep escaping this for now to keep the behavior until support is required
       //dn = handleUnescapedPlus(dn); // Log warning if dn contains unescaped '+'
       if (isDNReversed(dn)) {
           dn = reverseDN(dn);
       }
       String ret = null;
       final X500Name name = stringToBcX500Name(dn);
       if (name != null) {
           ret = name.toString();
       }
       /*
        * For some databases (MySQL for instance) the database column holding subjectDN is only 250 chars long. There have been strange error
        * reported (clipping DN naturally) that is hard to debug if DN is more than 250 chars and we don't have a good message
        */
       if ((ret != null) && (ret.length() > 250)) {
           log.info("Warning! DN is more than 250 characters long. Some databases have only 250 characters in the database for SubjectDN. Clipping may occur! DN ("
                   + ret.length() + " chars) ");
       }
       return ret;
   }

   /**
    * See stringToBcX500Name(String, X500NameStyle, boolean), this method uses the default name style (CeSecoreNameStyle) and ldap
    * order
    *
    * @see #stringToBcX500Name(String, X500NameStyle, boolean)
    * @param dn String containing DN that will be transformed into X500Name, The DN string has the format "CN=zz,OU=yy,O=foo,C=SE". Unknown OIDs in
    *            the string will be added to the end positions of OID array.
    *
    * @return X500Name, which can be empty if dn does not contain any real DN components, or null if input is null
    */
   public static X500Name stringToBcX500Name(final String dn) {
       final X500NameStyle nameStyle = CeSecoreNameStyle.INSTANCE;
       return stringToBcX500Name(dn, nameStyle, true);
   }

   /**
    * See stringToBcX500Name(String, X500NameStyle, boolean), this method uses the default name style (CeSecoreNameStyle) and ldap
    * order
    *
    * @see #stringToBcX500Name(String, X500NameStyle, boolean)
    * @param dn String containing DN that will be transformed into X500Name, The DN string has the format "CN=zz,OU=yy,O=foo,C=SE". Unknown OIDs in
    *            the string will be added to the end positions of OID array.
    * @param ldapOrder true if X500Name should be in Ldap Order
    * @return X500Name, which can be empty if dn does not contain any real DN components, or null if input is null
    */
   public static X500Name stringToBcX500Name(final String dn, boolean ldapOrder) {
       final X500NameStyle nameStyle = CeSecoreNameStyle.INSTANCE;
       return stringToBcX500Name(dn, nameStyle, ldapOrder);
   }

   /**
    * Creates a (Bouncycastle) X500Name object from a string with a DN. Known OID (with order) are:
    * <code> EmailAddress, UID, CN, SN (SerialNumber), GivenName, Initials, SurName, T, OU,
    * O, L, ST, DC, C </code> To change order edit 'dnObjects' in this source file. Important NOT to mess with the ordering within this class, since
    * cert vierification on some clients (IE :-() might depend on order.
    *
    * @param dn String containing DN that will be transformed into X500Name, The DN string has the format "CN=zz,OU=yy,O=foo,C=SE". Unknown OIDs in
    *            the string will be added to the end positions of OID array.
    * @param nameStyle Controls how the name is encoded. Usually it should be a CeSecoreNameStyle.
    * @param ldaporder true if LDAP ordering of DN should be used (default in EJBCA), false for X.500 order, ldap order is CN=A,OU=B,O=C,C=SE, x.500
    *            order is the reverse
    * @return X500Name, which can be empty if dn does not contain any real DN components, or null if input is null
    * @throws IllegalArgumentException if DN is not valid
    */
   public static X500Name stringToBcX500Name(String dn, final X500NameStyle nameStyle, final boolean ldaporder) {
       return stringToBcX500Name(dn, nameStyle, ldaporder, null);
   }

   /** Same as @see {@link DnComponents#stringToBcX500Name(String, X500NameStyle, boolean)} but with the possibility of
    * specifying a custom order.
    * ONLY to be used when creating names that are transient, never for storing in the database.
    *
    * @param dn String containing DN that will be transformed into X500Name, The DN string has the format "CN=zz,OU=yy,O=foo,C=SE". Unknown OIDs in
    *            the string will be added to the end positions of OID array.
    * @param nameStyle Controls how the name is encoded. Usually it should be a CeSecoreNameStyle.
    * @param ldaporder true if LDAP ordering of DN should be used (default in EJBCA), false for X.500 order, ldap order is CN=A,OU=B,O=C,C=SE, x.500
    *            order is the reverse
    * @param order specified order, which overrides 'ldaporder', care must be taken constructing this String array, ignored if null or empty
    * @return X500Name, which can be empty if dn does not contain any real DN components, or null if input is null
    * @throws IllegalArgumentException if the DN is badly formatted
    */
   public static X500Name stringToBcX500Name(String dn, final X500NameStyle nameStyle, final boolean ldaporder, final String[] order) {
       return stringToBcX500Name(dn, nameStyle, ldaporder, order, true);
   }


   // Remove extra '+' character escaping
   public static String getUnescapedPlus(final String value) {
       StringBuilder buf = new StringBuilder(value);
       int index = 0;
       int end = buf.length();
       while (index < end) {
           if (buf.charAt(index) == '\\' && index + 1 != end) {
               char c = buf.charAt(index + 1);
               if (c == '+') {
                   buf.deleteCharAt(index);
                   end--;
               }
           }
           index++;
       }
       return buf.toString();
   }

   /**
    * From an altName string as defined in getSubjectAlternativeName
    * There is no specific order now in the final alts produced in the cert,
    * whatever order is specified in profilemappings.properties or from CSR will be applied.
    *
    * @param altName
    * @return ASN.1 GeneralNames
    * @see #getSubjectAlternativeName
    */
   public static GeneralNames getGeneralNamesFromAltName(final String altName) {
       if (log.isTraceEnabled()) {
           log.trace(">getGeneralNamesFromAltName: " + altName);
       }

       if(StringUtils.isNotBlank(altName)) {
           return getGeneralNamesFromAltNameInternal(altName);
       } else {
           return null;
       }
   }

   /**
    * Gets the Microsoft specific UPN altName (altName, OtherName).
    *
    * UPN is an OtherName Subject Alternative Name:
    *
    * OtherName ::= SEQUENCE { type-id OBJECT IDENTIFIER, value [0] EXPLICIT ANY DEFINED BY type-id }
    *
    * UPN ::= UTF8String
    *
    * @param cert certificate containing the extension
    * @return String with the UPN name or null if the altName does not exist
    */
   public static String getUPNAltName(Certificate cert) throws CertificateParsingException {
       return getUTF8AltNameOtherName(cert, UPN_OBJECTID);
   }

   /**
    * Gets a UTF8 OtherName altName (altName, OtherName).
    *
    * Like UPN and XmpAddr
    *
    * An OtherName Subject Alternative Name:
    *
    * OtherName ::= SEQUENCE { type-id OBJECT IDENTIFIER, value [0] EXPLICIT ANY DEFINED BY type-id }
    *
    * UPN ::= UTF8String
    * (subjectAltName=otherName:1.3.6.1.4.1.311.20.2.3;UTF8:username@some.domain)
    * XmppAddr ::= UTF8String
    * (subjectAltName=otherName:1.3.6.1.5.5.7.8.5;UTF8:username@some.domain)
    *
    * CertTools.UPN_OBJECTID = "1.3.6.1.4.1.311.20.2.3";
    * CertTools.XMPPADDR_OBJECTID = "1.3.6.1.5.5.7.8.5";
    * CertTools.SRVNAME_OBJECTID = "1.3.6.1.5.5.7.8.7";
    *
    * @param cert certificate containing the extension
    * @param oid the OID of the OtherName
    * @return String with the UTF8 name or null if the altName does not exist
    */
   public static String getUTF8AltNameOtherName(final Certificate cert, final String oid) throws CertificateParsingException {
       String ret = null;
       if (cert instanceof X509Certificate) {
           X509Certificate x509cert = (X509Certificate) cert;
           Collection<List<?>> altNames = x509cert.getSubjectAlternativeNames();
           if (altNames != null) {
               for (final List<?> next : altNames) {
                   ret = getUTF8StringFromSequence(getAltnameSequence(next), oid);
                   if (ret != null) {
                       break;
                   }
               }
           }
       }
       return ret;
   }

   /**
    * Gets the Permanent Identifier (altName, OtherName).
    *
    * permanentIdentifier is an OtherName Subject Alternative Name:
    *
    * OtherName ::= SEQUENCE { type-id OBJECT IDENTIFIER, value [0] EXPLICIT ANY DEFINED BY type-id }
    *
    * -- Permanent Identifier
    *
    *   permanentIdentifier OTHER-NAME ::=
    * { PermanentIdentifier IDENTIFIED BY id-on-permanentIdentifier }
    *
    * PermanentIdentifier ::= SEQUENCE {
    *  identifierValue    UTF8String             OPTIONAL,
    *                  -- if absent, use the serialNumber attribute
    *                  -- if there is a single such attribute present
    *                  -- in the subject DN
    *  assigner           OBJECT IDENTIFIER      OPTIONAL
    *                  -- if absent, the assigner is
    *                  -- the certificate issuer
    * }
    *
    * @param cert certificate containing the extension
    * @return String with the permanentIdentifier name or null if the altName does not exist
    */
   public static String getPermanentIdentifierAltName(Certificate cert) throws CertificateParsingException {
       String ret = null;
       if (cert instanceof X509Certificate) {
           X509Certificate x509cert = (X509Certificate) cert;
           Collection<List<?>> altNames = x509cert.getSubjectAlternativeNames();
           if (altNames != null) {
               Iterator<List<?>> i = altNames.iterator();
               while (i.hasNext()) {
                   ASN1Sequence seq = getAltnameSequence(i.next());
                   ret = getPermanentIdentifierStringFromSequence(seq);
                   if (ret != null) {
                       break;
                   }
               }
           }
       }
       return ret;
   }

   /**
    * Gets the Hardware Module Name (altName, OtherName). See RFC4108 ch. 5.
    *
    * hardwareModuleName is an OtherName Subject Alternative Name:
    *
    * OtherName ::= SEQUENCE { type-id OBJECT IDENTIFIER, value [0] EXPLICIT ANY DEFINED BY type-id }
    *
    * -- Hardware Module Name
    *
    *   hardwareModuleName OTHER-NAME ::=
    * { HardwareModuleName IDENTIFIED BY id-on-hardwareModuleName }
    *
    * HardwareModuleName ::= SEQUENCE {
    *  hwType 			OBJECT IDENTIFIER,
    *                  -- type of hardware module
    *                  -- names hardware model and revision
    *  hwSerialNum      OCTET STRING,
    *                  -- no particular structure
    *                  -- hwType and hwSerialNum uniquely identifies the hardware module
    * }
    *
    * @param cert certificate containing the extension
    * @return String with the hardwareModuleName or null if the altName does not exist
    */
   public static String getHardwareModuleNameAltName(Certificate cert) throws CertificateParsingException {
       String ret = null;
       if (cert instanceof X509Certificate) {
           X509Certificate x509cert = (X509Certificate) cert;
           Collection<List<?>> altNames = x509cert.getSubjectAlternativeNames();
           if (altNames != null) {
               Iterator<List<?>> i = altNames.iterator();
               while (i.hasNext()) {
                   ASN1Sequence seq = getAltnameSequence(i.next());
                   ret = getHardwareModuleNameStringFromSequence(seq);
                   if (ret != null) {
                       break;
                   }
               }
           }
       }
       return ret;
   }

   /**
    * Gets the Microsoft specific GUID altName, that is encoded as an octet string.
    *
    * @param cert certificate containing the extension
    * @return String with the hex-encoded GUID byte array or null if the altName does not exist
    */
   public static String getGuidAltName(Certificate cert) throws CertificateParsingException {
       if (cert instanceof X509Certificate) {
           X509Certificate x509cert = (X509Certificate) cert;
           Collection<List<?>> altNames = x509cert.getSubjectAlternativeNames();
           if (altNames != null) {
               Iterator<List<?>> i = altNames.iterator();
               while (i.hasNext()) {
                   ASN1Sequence seq = getAltnameSequence(i.next());
                   if (seq != null) {
                       String guid = getGUIDStringFromSequence(seq);
                       if (guid != null) {
                           return guid;
                       }
                   }
               }
           }
       }
       return null;
   }

   /**
    * SubjectAltName ::= GeneralNames
    *
    * GeneralNames :: = SEQUENCE SIZE (1..MAX) OF GeneralName
    *
    * GeneralName ::= CHOICE { otherName [0] OtherName, rfc822Name [1] IA5String, dNSName [2] IA5String, x400Address [3] ORAddress, directoryName [4]
    * Name, ediPartyName [5] EDIPartyName, uniformResourceIdentifier [6] IA5String, iPAddress [7] OCTET STRING, registeredID [8] OBJECT IDENTIFIER}
    *
    * SubjectAltName is of form \"rfc822Name=<email>, dNSName=<host name>, uniformResourceIdentifier=<http://host.com/>, iPAddress=<address>,
    * guid=<globally unique id>, directoryName=<LDAP escaped DN>, permanentIdentifier=<identifierValue/assigner|identifierValue|/assigner|/>,
    * subjectIdentificationMethod=<Subject Identification Method values or parameters>, registeredID=<object identifier>,
    * xmppAddr=<RFC6120 XmppAddr>, srvName=<RFC4985 SRVName>, fascN=<FIPS 201-2 PIV FASC-N>
    *
    * Supported altNames are upn, krb5principal, rfc822Name, uniformResourceIdentifier, dNSName, iPAddress, directoryName, permanentIdentifier
    *
    * @author Marco Ferrante, (c) 2005 CSITA - University of Genoa (Italy)
    * @author Tomas Gustavsson
    * @param certificate containing alt names
    * @return String containing altNames of form
    *         "rfc822Name=email, dNSName=hostname, uniformResourceIdentifier=uri, iPAddress=ip, upn=upn, directoryName=CN=testDirName|dir|name", permanentIdentifier=identifierValue/assigner or
    *         empty string if no altNames exist. Values in returned String is from CertTools constants. AltNames not supported are simply not shown
    *         in the resulting string.
    */
   public static String getSubjectAlternativeName(Certificate certificate) {
       if (log.isTraceEnabled()) {
           log.trace(">getSubjectAlternativeName");
       }
       String result = "";
       if (certificate instanceof X509Certificate) {
           X509Certificate x509cert = (X509Certificate) certificate;

           Collection<List<?>> altNames = null;

           try {
               altNames = x509cert.getSubjectAlternativeNames();
           } catch (CertificateParsingException e) {
               throw new RuntimeException("Could not parse certificate", e);
           }

           if (altNames == null) {
               return null;
           }
           final Iterator<List<?>> iter = altNames.iterator();
           String append = new String();
           List<?> item = null;
           Integer type = null;
           Object value = null;
           while (iter.hasNext()) {
               item = iter.next();
               type = (Integer) item.get(0);
               value = item.get(1);
               if (!StringUtils.isEmpty(result)) {
                   // Result already contains one altname, so we have to add comma if there are more altNames
                   append = ", ";
               }
               String rdn = null;
               switch (type.intValue()) {
               case 0:
                   // OtherName, can be a lot of different things
                   final ASN1Sequence sequence = getAltnameSequence(item);
                   final ASN1ObjectIdentifier oid = ASN1ObjectIdentifier.getInstance(sequence.getObjectAt(0));
                   switch(oid.getId()) {
                       case UPN_OBJECTID:
                           rdn = UPN + "=" + getUTF8StringFromSequence(sequence, UPN_OBJECTID);
                           break;
                       case PERMANENTIDENTIFIER_OBJECTID:
                           rdn = PERMANENTIDENTIFIER + "=" + getPermanentIdentifierStringFromSequence(sequence);
                           break;
                       case HARDWAREMODULENAME_OBJECTID:
                    	   rdn = HARDWAREMODULENAME + "=" + getHardwareModuleNameStringFromSequence(sequence);
                    	   break;
                       case KRB5PRINCIPAL_OBJECTID:
                           rdn = KRB5PRINCIPAL + "=" + getKrb5PrincipalNameFromSequence(sequence);
                           break;
                       case RFC4683Tools.SUBJECTIDENTIFICATIONMETHOD_OBJECTID:
                           final String sim = RFC4683Tools.getSimStringSequence(sequence);
                           rdn = RFC4683Tools.SUBJECTIDENTIFICATIONMETHOD + "=" + sim;
                           break;
                       case GUID_OBJECTID:
                           rdn = CertTools.GUID + "=" + getGUIDStringFromSequence(sequence);
                           break;
                       case XMPPADDR_OBJECTID:
                           rdn = XMPPADDR + "=" + getUTF8StringFromSequence(sequence, XMPPADDR_OBJECTID);
                           break;
                       case SRVNAME_OBJECTID:
                           rdn = SRVNAME + "=" + getIA5StringFromSequence(sequence, SRVNAME_OBJECTID);
                           break;
                       case FASCN_OBJECTID:
                           // PIV FASC-N (FIPS 201-2) is an OCTET STRING, we'll return if as a hex encoded String
                           rdn = FASCN + "=" + new String(Hex.encode(getOctetStringFromSequence(sequence, FASCN_OBJECTID)));
                           break;
                   };
                   break;
               case 1:
                   rdn = EMAIL + "=" + (String) value;
                   break;
               case 2:
                   rdn = DNS + "=" + (String) value;
                   break;
               case 3: // SubjectAltName of type x400Address not supported
                   break;
               case 4:
                   rdn = DIRECTORYNAME + "=" + (String) value;
                   break;
               case 5: // SubjectAltName of type ediPartyName not supported
                   break;
               case 6:
                   rdn = URI + "=" + (String) value;
                   break;
               case 7:
                   rdn = IPADDR + "=" + (String) value;
                   break;
               case 8:
                   // OID names are returned as Strings according to the JDK X509Certificate javadoc
                   rdn = DnComponents.REGISTEREDID + "=" + (String) value;
                   break;
               default: // SubjectAltName of unknown type
                   break;
               }
               if (rdn != null) {
                   // The rdn might contain commas, so escape it.
                   result += append + escapeFieldValue(rdn);
               }
           }
           if (log.isTraceEnabled()) {
               log.trace("<getSubjectAlternativeName: " + result);
           }
           if (StringUtils.isEmpty(result)) {
               return null;
           }
       }
       return result;
   }

   /**
    * Search for e-mail address, first in SubjectAltName (as in PKIX recommendation) then in subject DN. Original author: Marco Ferrante, (c) 2005
    * CSITA - University of Genoa (Italy)
    *
    * @param certificate
    * @return subject email or null if not present in certificate
    */
   public static String getEMailAddress(Certificate certificate) {
       log.debug("Searching for EMail Address in SubjectAltName");
       if (certificate == null) {
           return null;
       }
       if (certificate instanceof X509Certificate) {
           X509Certificate x509cert = (X509Certificate) certificate;
           try {
               if (x509cert.getSubjectAlternativeNames() != null) {
                   for (List<?> item : x509cert.getSubjectAlternativeNames()) {
                       Integer type = (Integer) item.get(0);
                       if (type == 1) {
                           return (String) item.get(1);
                       }
                   }
               }
           } catch (CertificateParsingException e) {
               log.error("Error parsing certificate: ", e);
           }
           log.debug("Searching for EMail Address in Subject DN");
           List<String> emails = getEmailFromDN(CertTools.getSubjectDN(certificate));
           if (!emails.isEmpty()) {
               return emails.get(0);
           }
       }
       return null;
   }


   /**
    * Gets an altName string from an X509Extension
    *
    * @param ext X509Extension with AlternativeNames
    * @return String as defined in method getSubjectAlternativeName
    */
   public static String getAltNameStringFromExtension(Extension ext) {
       String altName = null;
       // GeneralNames, the actual encoded name
       GeneralNames names = getGeneralNamesFromExtension(ext);
       if (names != null) {
           try {
               GeneralName[] gns = names.getNames();
               for (GeneralName gn : gns) {
                   int tag = gn.getTagNo();
                   ASN1Encodable name = gn.getName();
                   String str = getGeneralNameString(tag, name);
                   if (str == null) {
                       continue;
                   }
                   if (altName == null) {
                       altName = escapeFieldValue(str);
                   } else {
                       altName += ", " + escapeFieldValue(str);
                   }
               }
           } catch (IOException e) {
               log.error("IOException parsing altNames: ", e);
               return null;
           }
       }
       return altName;
   }

   /**
    * Gets GeneralNames from an X509Extension
    *
    * @param ext X509Extension with AlternativeNames
    * @return GeneralNames with all Alternative Names
    */
   public static GeneralNames getGeneralNamesFromExtension(Extension ext) {
       ASN1Encodable gnames = ext.getParsedValue();
       if (gnames != null) {
               GeneralNames names = GeneralNames.getInstance(gnames);
               return names;
       }
       return null;
   }

   /**
    * GeneralName ::= CHOICE { otherName [0] OtherName, rfc822Name [1] IA5String, dNSName [2] IA5String, x400Address [3] ORAddress, directoryName [4]
    * Name, ediPartyName [5] EDIPartyName, uniformResourceIdentifier [6] IA5String, iPAddress [7] OCTET STRING, registeredID [8] OBJECT IDENTIFIER}
    *
    * @param tag the no tag 0-8
    * @param value the ASN1Encodable value as returned by GeneralName.getName()
    * @return String in form rfc822Name=<email> or uri=<uri> etc
    * @throws IOException
    * @see #getSubjectAlternativeName
    */
   public static String getGeneralNameString(int tag, ASN1Encodable value) throws IOException {
       String ret = null;
       switch (tag) {
       case 0:
       {
           final ASN1Sequence sequence = getAltnameSequence(value.toASN1Primitive().getEncoded());
           final ASN1ObjectIdentifier oid = ASN1ObjectIdentifier.getInstance(sequence.getObjectAt(0));
           switch(oid.getId()) {
               case UPN_OBJECTID:
                   ret = UPN + "=" + getUTF8StringFromSequence(sequence, UPN_OBJECTID);
                   break;
               case PERMANENTIDENTIFIER_OBJECTID:
                   ret = PERMANENTIDENTIFIER + "=" + getPermanentIdentifierStringFromSequence(sequence);
                   break;
               case HARDWAREMODULENAME_OBJECTID:
            	   ret = HARDWAREMODULENAME + "=" + getHardwareModuleNameStringFromSequence(sequence);
            	   break;
               case KRB5PRINCIPAL_OBJECTID:
                   ret = KRB5PRINCIPAL + "=" + getKrb5PrincipalNameFromSequence(sequence);
                   break;
               case RFC4683Tools.SUBJECTIDENTIFICATIONMETHOD_OBJECTID:
                   ret = RFC4683Tools.SUBJECTIDENTIFICATIONMETHOD + "=" + RFC4683Tools.getSimStringSequence(sequence);
                   break;
               case XMPPADDR_OBJECTID:
                   ret = XMPPADDR + "=" + getUTF8StringFromSequence(sequence, XMPPADDR_OBJECTID);
                   break;
               case SRVNAME_OBJECTID:
                   ret = SRVNAME + "=" + getIA5StringFromSequence(sequence, SRVNAME_OBJECTID);
                   break;
               case FASCN_OBJECTID:
                   ret = FASCN + "=" + new String(Hex.encode(getOctetStringFromSequence(sequence, FASCN_OBJECTID)));
                   break;
               case GUID_OBJECTID:
                   ret = GUID + "=" + getGUIDStringFromSequence(sequence);
                   break;
           };
           break;
       }
       case 1:
           ret = EMAIL + "=" + ASN1IA5String.getInstance(value).getString();
           break;
       case 2:
           ret = DNS + "=" + ASN1IA5String.getInstance(value).getString();
           break;
       case 3: // SubjectAltName of type x400Address not supported
           break;
       case 4:
           final X500Name name = X500Name.getInstance(value);
           ret = DIRECTORYNAME + "=" + name.toString();
           break;
       case 5: // SubjectAltName of type ediPartyName not supported
           break;
       case 6:
           ret = URI + "=" + ASN1IA5String.getInstance(value).getString();
           break;
       case 7:
           ASN1OctetString oct = ASN1OctetString.getInstance(value);

           // First try for IPv4
           String parsedIP = StringTools.ipOctetsToString(oct.getOctets());

           if (parsedIP == null) {
               // Also try handling IPv6 case
               parsedIP = StringTools.isIpV6Address(StringTools.convertToIpv6(value.toString())) ? StringTools.convertToIpv6(value.toString()) : null;
           }

           ret = IPADDR + "=" + parsedIP;

           break;
       case 8:
           // BC GeneralName stores the actual object value, which is an OID
           ASN1ObjectIdentifier oid = ASN1ObjectIdentifier.getInstance(value);
           ret = CertTools.REGISTEREDID+ "=" + oid.getId();
           break;
       default: // SubjectAltName of unknown type
           break;
       }
       return ret;
   }

   /**
    * Helper method.
    *
    * @param seq the OtherName sequence
    * @return bytes which is the decoded ASN.1 Octet String of the (simple) OtherName
    */
   private static byte[] getOctetStringFromSequence(final ASN1Sequence seq, final String oid) {
       if (seq != null) {
           // First in sequence is the object identifier, that we must check
           ASN1ObjectIdentifier id = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
           if (id.getId().equals(oid)) {
               ASN1TaggedObject oobj = ASN1TaggedObject.getInstance(seq.getObjectAt(1));
               // Due to bug in java cert.getSubjectAltName regarding OtherName, it can be tagged an extra time...
               ASN1Primitive obj = oobj.getBaseObject().toASN1Primitive();
               if (obj instanceof ASN1TaggedObject) {
                   obj = ASN1TaggedObject.getInstance(obj).getBaseObject().toASN1Primitive();
               }
               ASN1OctetString str = ASN1OctetString.getInstance(obj);
               return str.getOctets();
           }
       }
       return null;
   }

   /**
    * Helper method.
    *
    * @param seq the OtherName sequence
    * @return String which is the decoded ASN.1 IA5String of the (simple) OtherName
    */
   private static String getIA5StringFromSequence(final ASN1Sequence seq, final String oid) {
       if (seq != null) {
           // First in sequence is the object identifier, that we must check
           ASN1ObjectIdentifier id = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
           if (id.getId().equals(oid)) {
               ASN1TaggedObject oobj = ASN1TaggedObject.getInstance(seq.getObjectAt(1));
               // Due to bug in java cert.getSubjectAltName regarding OtherName, it can be tagged an extra time...
               ASN1Primitive obj = oobj.getBaseObject().toASN1Primitive();
               if (obj instanceof ASN1TaggedObject) {
                   obj = ASN1TaggedObject.getInstance(obj).getBaseObject().toASN1Primitive();
               }
               ASN1IA5String str = ASN1IA5String.getInstance(obj);
               return str.getString();
           }
       }
       return null;
   }

   /**
    * Unescapes a value of a field in a DN, SAN or directory attributes.
    * Unlike LDAPDN.unescapeRDN, this method handles value without the field name (e.g. example.com) and empty values (e.g. DNSNAME=)
    * @param value Value to unescape
    * @return Unescaped string
    */
   private static String unescapeFieldValue(final String value) {
       if (value == null) {
           return null;
       } else {
           return UNESCAPE_FIELD_REGEX.matcher(value).replaceAll("$1");
       }
   }

   /**
    * Escapes a value of a field in a DN, SAN or directory attributes.
    * Unlike LDAPDN.escapeRDN, this method allows empty values (e.g. DNSNAME=)
    * @param value Value to escape, with or without the XX=
    * @return Escaped string
    */
   private static String escapeFieldValue(final String value) {
       if (value == null) {
           return null;
       } else if (value.indexOf('=') == value.length()-1) {
           return value;
       } else {
           return escapeRDN(value);
       }
   }

   /**
    * Returns the RDN after escaping the characters requiring escaping.
    *
    * <p>For example, for the rdn "cn=Acme, Inc", the escapeRDN method
    * returns "cn=Acme\, Inc".</p>
    *
    * <p>escapeRDN escapes the AttributeValue by inserting '\' before the
    * following chars: * ',' '+' '"' '\' '<' '>' ';' <BR>
    * '#' if it comes at the beginning of the string, and <BR>
    * ' ' (space) if it comes at the beginning or the end of a string.
    * Note that single-valued attributes can be used because of ambiguity. See
    * RFC 2253 </p>
    *
    *  @param rdn            The RDN to escape.
    *
    *@return The RDN with escaping characters.
    */
   private static String escapeRDN(String rdn) {
       StringBuffer escapedS = new StringBuffer(rdn);
       int i = 0;

       while (i < escapedS.length() && escapedS.charAt(i) != '=') {
           i++; //advance until we find the separator =
       }
       if (i == escapedS.length()) {
           throw new IllegalArgumentException("Could not parse RDN: Attribute " + "type and name must be separated by an equal symbol, '='");
       }

       i++;
       //check for a space or # at the beginning of a string.
       if ((escapedS.charAt(i) == ' ') || (escapedS.charAt(i) == '#')) {
           escapedS.insert(i++, '\\');
       }

       //loop from second char to the second to last
       for (; i < escapedS.length(); i++) {
           if ((escapedS.charAt(i) == ',') || (escapedS.charAt(i) == '+') || (escapedS.charAt(i) == '"') || (escapedS.charAt(i) == '\\')
                   || (escapedS.charAt(i) == '<') || (escapedS.charAt(i) == '>') || (escapedS.charAt(i) == ';')) {
               escapedS.insert(i++, '\\');
           }
       }

       //check last char for a space
       if (escapedS.charAt(escapedS.length() - 1) == ' ') {
           escapedS.insert(escapedS.length() - 1, '\\');
       }
       return escapedS.toString();
   }

   /**
    * Helper method for getting kerberos 5 principal name (altName, OtherName)
    *
    * Krb5PrincipalName is an OtherName Subject Alternative Name
    *
    * String representation is in form "principalname1/principalname2@realm"
    *
    * KRB5PrincipalName ::= SEQUENCE { realm [0] Realm, principalName [1] PrincipalName }
    *
    * Realm ::= KerberosString
    *
    * PrincipalName ::= SEQUENCE { name-type [0] Int32, name-string [1] SEQUENCE OF KerberosString }
    *
    * The new (post-RFC 1510) type KerberosString, defined below, is a GeneralString that is constrained to contain only characters in IA5String.
    *
    * KerberosString ::= GeneralString (IA5String)
    *
    * Int32 ::= INTEGER (-2147483648..2147483647) -- signed values representable in 32 bits
    *
    * @param seq the OtherName sequence
    * @return String with the krb5 name in the form of "principal1/principal2@realm" or null if the altName does not exist
    */
   private static String getKrb5PrincipalNameFromSequence(ASN1Sequence seq) {
       String ret = null;
       if (seq != null) {
           // First in sequence is the object identifier, that we must check
           ASN1ObjectIdentifier id = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
           if (id.getId().equals(KRB5PRINCIPAL_OBJECTID)) {
               // Get the KRB5PrincipalName sequence
               ASN1TaggedObject oobj = ASN1TaggedObject.getInstance(seq.getObjectAt(1));
               // Due to bug in java cert.getSubjectAltName regarding OtherName, it can be tagged an extra time...
               ASN1Primitive obj = oobj.getBaseObject().toASN1Primitive();
               if (obj instanceof ASN1TaggedObject) {
                   obj = ASN1TaggedObject.getInstance(obj).getBaseObject().toASN1Primitive();
               }
               ASN1Sequence krb5Seq = ASN1Sequence.getInstance(obj);
               // Get the Realm tagged as 0
               ASN1TaggedObject robj = ASN1TaggedObject.getInstance(krb5Seq.getObjectAt(0));
               ASN1GeneralString realmObj = ASN1GeneralString.getInstance(robj.getBaseObject().toASN1Primitive());
               String realm = realmObj.getString();
               // Get the PrincipalName tagged as 1
               ASN1TaggedObject pobj = ASN1TaggedObject.getInstance(krb5Seq.getObjectAt(1));
               // This is another sequence of type and name
               ASN1Sequence nseq = ASN1Sequence.getInstance(pobj.getBaseObject().toASN1Primitive());
               // Get the name tagged as 1
               ASN1TaggedObject nobj = ASN1TaggedObject.getInstance(nseq.getObjectAt(1));
               // The name is yet another sequence of GeneralString
               ASN1Sequence sseq = ASN1Sequence.getInstance(nobj.getBaseObject().toASN1Primitive());
               @SuppressWarnings("unchecked")
               Enumeration<ASN1Object> en = sseq.getObjects();
               while (en.hasMoreElements()) {
                   ASN1GeneralString str = ASN1GeneralString.getInstance(en.nextElement());
                   if (ret != null) {
                       ret += "/" + str.getString();
                   } else {
                       ret = str.getString();
                   }
               }
               // Add the realm in the end so we have "principal@realm"
               ret += "@" + realm;
           }
       }
       return ret;
   }

   /**
    * Helper method to get MS GUID from GeneralName otherName sequence
    *
    * @param seq the OtherName sequence
    */
   private static String getGUIDStringFromSequence(ASN1Sequence seq) {
       String ret = null;
       if (seq != null) {
           // First in sequence is the object identifier, that we must check
           ASN1ObjectIdentifier id = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
           if (id.getId().equals(GUID_OBJECTID)) {
               ASN1TaggedObject oobj = ASN1TaggedObject.getInstance(seq.getObjectAt(1));
               // Due to bug in java cert.getSubjectAltName regarding OtherName, it can be tagged an extra time...
               ASN1Primitive obj = oobj.getBaseObject().toASN1Primitive();
               if (obj instanceof ASN1TaggedObject) {
                   obj = ASN1TaggedObject.getInstance(obj).getBaseObject().toASN1Primitive();
               }
               ASN1OctetString str = ASN1OctetString.getInstance(obj);
               ret = new String(Hex.encode(str.getOctets()));
           }
       }
       return ret;
   }

   /**
    * Helper method for the above method.
    *
    * @param seq the OtherName sequence
    * @return String which is the decoded ASN.1 UTF8 String of the (simple) OtherName
    */
   private static String getUTF8StringFromSequence(final ASN1Sequence seq, final String oid) {
       if (seq != null) {
           // First in sequence is the object identifier, that we must check
           ASN1ObjectIdentifier id = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
           if (id.getId().equals(oid)) {
               ASN1TaggedObject oobj = ASN1TaggedObject.getInstance(seq.getObjectAt(1));
               // Due to bug in java cert.getSubjectAltName regarding OtherName, it can be tagged an extra time...
               ASN1Primitive obj = oobj.getBaseObject().toASN1Primitive();
               if (obj instanceof ASN1TaggedObject) {
                   obj = ASN1TaggedObject.getInstance(obj).getBaseObject().toASN1Primitive();
               }
               ASN1UTF8String str = ASN1UTF8String.getInstance(obj);
               return str.getString();
           }
       }
       return null;
   }

   /**
    * (This method intentionally has package level visibility to be able to be invoked from JUnit tests.)
    * @param seq
    * @return The extension values encoded as an permanentIdentifierString
    */
   private static String getPermanentIdentifierStringFromSequence(ASN1Sequence seq) {
       if (seq != null) {
           // First in sequence is the object identifier, that we must check
           ASN1ObjectIdentifier id = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
           if (id.getId().equals(PERMANENTIDENTIFIER_OBJECTID)) {
               String identifierValue = null;
               String assigner = null;

               // Get the PermanentIdentifier sequence
               ASN1TaggedObject oobj = ASN1TaggedObject.getInstance(seq.getObjectAt(1));
               // Due to bug in java cert.getSubjectAltName regarding OtherName, it can be tagged an extra time...
               ASN1Primitive obj = oobj.getBaseObject().toASN1Primitive();
               if (obj instanceof ASN1TaggedObject) {
                   obj = ASN1TaggedObject.getInstance(obj).getBaseObject().toASN1Primitive();
               }
               ASN1Sequence piSeq = ASN1Sequence.getInstance(obj);

               Enumeration<?> e = piSeq.getObjects();
               if (e.hasMoreElements()) {
                   Object element = e.nextElement();
                   if (element instanceof DERUTF8String) {
                       identifierValue = ((DERUTF8String) element).getString();
                       if (e.hasMoreElements()) {
                           element = e.nextElement();
                       }
                   }
                   if (element instanceof ASN1ObjectIdentifier) {
                       assigner = ((ASN1ObjectIdentifier) element).getId();
                   }
               }

               StringBuilder buff = new StringBuilder();
               if (identifierValue != null) {
                   buff.append(escapePermanentIdentifierValue(identifierValue));
               }
               buff.append(PERMANENTIDENTIFIER_SEP);
               if (assigner != null) {
                   buff.append(assigner);
               }
               return buff.toString();
           }
       }
       return null;
   }
   public static String getHardwareModuleNameStringFromSequence(ASN1Sequence seq) {
       if (seq != null) {
           // First in sequence is the object identifier, that we must check
           final ASN1ObjectIdentifier id = ASN1ObjectIdentifier.getInstance(seq.getObjectAt(0));
           if (id.getId().equals(HARDWAREMODULENAME_OBJECTID)) {
               String hwType = null;
               String hwSerialNum = null;

               // Get the HardwareModuleName sequence
               final ASN1TaggedObject oobj = ASN1TaggedObject.getInstance(seq.getObjectAt(1));
               // Due to bug in java cert.getSubjectAltName regarding OtherName, it can be tagged an extra time...
               ASN1Primitive obj = oobj.getBaseObject().toASN1Primitive();
               if (obj instanceof ASN1TaggedObject) {
                   obj = ASN1TaggedObject.getInstance(obj).getBaseObject().toASN1Primitive();
               }
               // HardwareModuleName ::= SEQUENCE { hwType OBJECT IDENTIFIER, hwSerialNum OCTET STRING }
               final ASN1Sequence hwName = ASN1Sequence.getInstance(obj);
               final Enumeration<?> e = hwName.getObjects();
               if (e.hasMoreElements()) {
            	   Object element = e.nextElement();
            	   if (element instanceof ASN1ObjectIdentifier) {
                       hwType = ((ASN1ObjectIdentifier) element).getId();
                   }
               }
               if (e.hasMoreElements()) {
            	   Object element = e.nextElement();
            	   if (element instanceof DEROctetString) {
            		   hwSerialNum = new String(((DEROctetString) element).getOctets(), StandardCharsets.US_ASCII);
                   }
               }

               final StringBuilder buff = new StringBuilder();
               buff.append(hwType);
               if (hwSerialNum != null) {
            	   buff.append(HARDWAREMODULENAME_SEP);
                   buff.append(hwSerialNum);
               }
               return buff.toString();
           }
       }
       return null;
   }

   private static String escapePermanentIdentifierValue(String realValue) {
       return realValue.replace(PERMANENTIDENTIFIER_SEP, "\\" + PERMANENTIDENTIFIER_SEP);
   }


   private static ASN1Sequence getAltnameSequence(List<?> listitem) {
       Integer no = (Integer) listitem.get(0);
       if (no == 0) {
           byte[] altName = (byte[]) listitem.get(1);
           return getAltnameSequence(altName);
       }
       return null;
   }

   private static ASN1Sequence getAltnameSequence(byte[] value) {
       ASN1Primitive oct = null;
       try {
           oct = ASN1Primitive.fromByteArray(value);
       } catch (IOException e) {
           throw new IllegalArgumentException("Could not read ASN1InputStream", e);
       }
       if (oct instanceof ASN1TaggedObject) {
           oct = ((ASN1TaggedObject) oct).getBaseObject().toASN1Primitive();
       }
       ASN1Sequence seq = ASN1Sequence.getInstance(oct);
       return seq;
   }

   private static GeneralNames getGeneralNamesFromAltNameInternal(String altName) {

       final ASN1EncodableVector vec = new ASN1EncodableVector();



       String[] result = altName.split("(?<!\\\\),");

       for (final String str : result) {

           String[] subResult = str.trim().split("=");

           switch (subResult[0].trim().toUpperCase()) {

           case DnComponents.DNEMAILADDRESS:
           case DnComponents.RFC822NAME:
               for (final String email : getEmailFromDN(str)) {
                   vec.add(new GeneralName(1, email));
               }
               break;

           case DnComponents.IPADDRESS:
               for (final String addr : getPartsFromDN(str, IPADDR)) {
                   final byte[] ipoctets = StringTools.ipStringToOctets(addr);
                   if (ipoctets.length > 0) {
                       final GeneralName gn = new GeneralName(7, new DEROctetString(ipoctets));
                       vec.add(gn);
                   } else {
                       log.error("Cannot parse/encode ip address, ignoring: " + addr);
                   }
               }
               break;

           case DnComponents.DNSNAME:
               for (final String dns : getPartsFromDN(str, DNS)) {
                   vec.add(new GeneralName(2, new DERIA5String(dns)));
               }
               break;

           case DnComponents.DIRECTORYNAME:
               final String directoryName = getDirectoryStringFromAltName(str);
               if (directoryName != null) {
                   final X500Name x500DirectoryName = new X500Name(CeSecoreNameStyle.INSTANCE, directoryName);
                   final GeneralName gn = new GeneralName(4, x500DirectoryName);
                   vec.add(gn);
               }
               break;

           case DnComponents.URI:
               for (final String uri : getPartsFromDN(str, URI)) {
                   vec.add(new GeneralName(6, new DERIA5String(uri)));
               }
               break;

           case DnComponents.URI1:
               for (final String uri : getPartsFromDN(str, URI1)) {
                   vec.add(new GeneralName(6, new DERIA5String(uri)));
               }
               break;

           case DnComponents.UNIFORMRESOURCEID:
               for (final String uri : getPartsFromDN(str, URI2)) {
                   vec.add(new GeneralName(6, new DERIA5String(uri)));
               }
               break;

           case DnComponents.REGISTEREDID:
               for (final String oid : getPartsFromDN(str, REGISTEREDID)) {
                   vec.add(new GeneralName(GeneralName.registeredID, oid));
               }
               break;

           case DnComponents.UPN:
               // UPN is an OtherName see method getUpn... for asn.1 definition
               for (final String upn : getPartsFromDN(str, UPN)) {
                   final ASN1EncodableVector v = new ASN1EncodableVector();
                   v.add(new ASN1ObjectIdentifier(UPN_OBJECTID));
                   v.add(new DERTaggedObject(true, 0, new DERUTF8String(upn)));
                   vec.add(GeneralName.getInstance(new DERTaggedObject(false, 0, new DERSequence(v))));
               }
               break;

           case DnComponents.XMPPADDR:
               // XmpAddr is an OtherName see method getUTF8String...... for asn.1 definition
               for (final String xmppAddr : getPartsFromDN(str, XMPPADDR)) {
                   final ASN1EncodableVector v = new ASN1EncodableVector();
                   v.add(new ASN1ObjectIdentifier(XMPPADDR_OBJECTID));
                   v.add(new DERTaggedObject(true, 0, new DERUTF8String(xmppAddr)));
                   vec.add(GeneralName.getInstance(new DERTaggedObject(false, 0, new DERSequence(v))));
               }
               break;

           case DnComponents.SRVNAME:
               // srvName is an OtherName see method getIA5String...... for asn.1 definition
               for (final String srvName : getPartsFromDN(str, SRVNAME)) {
                   final ASN1EncodableVector v = new ASN1EncodableVector();
                   v.add(new ASN1ObjectIdentifier(SRVNAME_OBJECTID));
                   v.add(new DERTaggedObject(true, 0, new DERIA5String(srvName)));
                   vec.add(GeneralName.getInstance(new DERTaggedObject(false, 0, new DERSequence(v))));
               }
               break;

           case DnComponents.FASCN:
               // FASC-N is an OtherName see method getOctetString...... for asn.1 definition (PIV FIPS 201-2)
               // We take the input as being a hex encoded octet string
               for (final String fascN : getPartsFromDN(str, FASCN)) {
                   final ASN1EncodableVector v = new ASN1EncodableVector();
                   v.add(new ASN1ObjectIdentifier(FASCN_OBJECTID));
                   v.add(new DERTaggedObject(true, 0, new DEROctetString(Hex.decode(fascN))));
                   vec.add(GeneralName.getInstance(new DERTaggedObject(false, 0, new DERSequence(v))));
               }
               break;

           case DnComponents.PERMANENTIDENTIFIER:
               // PermanentIdentifier is an OtherName see method getPermananentIdentifier... for asn.1 definition
               for (final String permanentIdentifier : getPartsFromDN(str, PERMANENTIDENTIFIER)) {
                   final String[] values = getPermanentIdentifierValues(permanentIdentifier);
                   final ASN1EncodableVector v = new ASN1EncodableVector(); // this is the OtherName
                   v.add(new ASN1ObjectIdentifier(PERMANENTIDENTIFIER_OBJECTID));
                   // First the PermanentIdentifier sequence
                   final ASN1EncodableVector piSeq = new ASN1EncodableVector();
                   if (values[0] != null) {
                       piSeq.add(new DERUTF8String(values[0]));
                   }
                   if (values[1] != null) {
                       piSeq.add(new ASN1ObjectIdentifier(values[1]));
                   }
                   v.add(new DERTaggedObject(true, 0, new DERSequence(piSeq)));
                   // GeneralName gn = new GeneralName(new DERSequence(v), 0);
                   final ASN1Primitive gn = new DERTaggedObject(false, 0, new DERSequence(v));
                   vec.add(gn);
               }
               break;
           case DnComponents.HARDWAREMODULENAME:
        	   for (final String hwn : getPartsFromDN(str, HARDWAREMODULENAME)) {
                   	final String type = hwn.substring(0, hwn.indexOf('/'));
               		final String serial = hwn.substring(hwn.indexOf('/') + 1, hwn.length());
               		final ASN1Primitive gn = new DERTaggedObject(false, 0, hardwareModuleName(type, serial));
               		vec.add(gn);
               }
        	   break;
           case DnComponents.GUID:
               for (final String guid : getPartsFromDN(str, GUID)) {
                   final ASN1EncodableVector v = new ASN1EncodableVector();
                   final String dashRemovedGuid = guid.replace("-", "");
                   byte[] guidbytes = Hex.decode(dashRemovedGuid);
                   if (guidbytes != null) {
                       v.add(new ASN1ObjectIdentifier(GUID_OBJECTID));
                       v.add(new DERTaggedObject(true, 0, new DEROctetString(guidbytes)));
                       final ASN1Primitive gn = new DERTaggedObject(false, 0, new DERSequence(v));
                       vec.add(gn);
                   } else {
                       log.error("Cannot decode hexadecimal guid, ignoring: " + guid);
                   }
               }
               break;

           case DnComponents.KRB5PRINCIPAL:
               // Krb5PrincipalName is an OtherName, see method getKrb5Principal...for ASN.1 definition
               for (final String principalString : getPartsFromDN(str, KRB5PRINCIPAL)) {
                   // Start by parsing the input string to separate it in different parts
                   if (log.isDebugEnabled()) {
                       log.debug("principalString: " + principalString);
                   }
                   // The realm is the last part moving back until an @
                   final int index = principalString.lastIndexOf('@');
                   String realm = "";
                   if (index > 0) {
                       realm = principalString.substring(index + 1);
                   }
                   if (log.isDebugEnabled()) {
                       log.debug("realm: " + realm);
                   }
                   // Now we can have several principals separated by /
                   final ArrayList<String> principalarr = new ArrayList<>();
                   int jndex = 0;
                   int bindex = 0;
                   while (jndex < index) {
                       // Loop and add all strings separated by /
                       jndex = principalString.indexOf('/', bindex);
                       if (jndex == -1) {
                           jndex = index;
                       }
                       String s = principalString.substring(bindex, jndex);
                       if (log.isDebugEnabled()) {
                           log.debug("adding principal name: " + s);
                       }
                       principalarr.add(s);
                       bindex = jndex + 1;
                   }

                   // Now we must construct the rather complex asn.1...
                   final ASN1EncodableVector v = new ASN1EncodableVector(); // this is the OtherName
                   v.add(new ASN1ObjectIdentifier(KRB5PRINCIPAL_OBJECTID));

                   // First the Krb5PrincipalName sequence
                   final ASN1EncodableVector krb5p = new ASN1EncodableVector();
                   // The realm is the first tagged GeneralString
                   krb5p.add(new DERTaggedObject(true, 0, new DERGeneralString(realm)));
                   // Second is the sequence of principal names, which is at tagged position 1 in the krb5p
                   final ASN1EncodableVector principals = new ASN1EncodableVector();
                   // According to rfc4210 the type NT-UNKNOWN is 0, and according to some other rfc this type should be used...
                   principals.add(new DERTaggedObject(true, 0, new ASN1Integer(0)));
                   // The names themselves are yet another sequence
                   final ASN1EncodableVector names = new ASN1EncodableVector();
                   for (final String principalName : principalarr) {
                       names.add(new DERGeneralString(principalName));
                   }
                   principals.add(new DERTaggedObject(true, 1, new DERSequence(names)));
                   krb5p.add(new DERTaggedObject(true, 1, new DERSequence(principals)));

                   v.add(new DERTaggedObject(true, 0, new DERSequence(krb5p)));
                   final ASN1Primitive gn = new DERTaggedObject(false, 0, new DERSequence(v));
                   vec.add(gn);
               }
               break;

           case DnComponents.SUBJECTIDENTIFICATIONMETHOD:
           case RFC4683Tools.SUBJECTIDENTIFICATIONMETHOD:
               // SIM is an OtherName. See RFC-4683
               for (final String internalSimString : getPartsFromDN(str, RFC4683Tools.SUBJECTIDENTIFICATIONMETHOD)) {
                   if (StringUtils.isNotBlank(internalSimString)) {
                       final String[] tokens = internalSimString.split(RFC4683Tools.LIST_SEPARATOR);
                       if (tokens.length == 3) {
                           ASN1Primitive gn = RFC4683Tools.createSimGeneralName(tokens[0], tokens[1], tokens[2]);
                           vec.add(gn);
                           if (log.isDebugEnabled()) {
                               log.debug("SIM GeneralName added: " + gn.toString());
                           }
                       }
                   }
               }
               break;

           default:
               log.info("Unknown SAN tag encountered!" + subResult[0]);
               break;
           }
       }



       // To support custom OIDs in altNames, they must be added as an OtherName of plain type UTF8String
       for (final String oid : getCustomOids(altName)) {
           for (final String oidValue : getPartsFromDN(altName, oid)) {
               final ASN1EncodableVector v = new ASN1EncodableVector();
               v.add(new ASN1ObjectIdentifier(oid));
               v.add(new DERTaggedObject(true, 0, new DERUTF8String(oidValue)));
               final ASN1Primitive gn = new DERTaggedObject(false, 0, new DERSequence(v));
               vec.add(gn);
           }
       }

       if (vec.size() > 0) {
           return GeneralNames.getInstance(new DERSequence(vec));
       }
       return null;
   }

   /* See https://datatracker.ietf.org/doc/html/rfc4108#section-5 */
   public static DERSequence hardwareModuleName(String hwType, String hwSerialNum) {
       final ASN1EncodableVector otherName = new ASN1EncodableVector();
       otherName.add(new ASN1ObjectIdentifier(HARDWAREMODULENAME_OBJECTID));

       // HardwareModuleName ::= SEQUENCE { hwType OBJECT IDENTIFIER, hwSerialNum OCTET STRING }
       final ASN1EncodableVector hwName = new ASN1EncodableVector();
       if (hwType != null) {
           hwName.add(new ASN1ObjectIdentifier(hwType));
       }
       if (hwSerialNum != null) {
           hwName.add(new DEROctetString(hwSerialNum.getBytes(StandardCharsets.US_ASCII)));
       }
       otherName.add(new DERTaggedObject(true, 0, new DERSequence(hwName)));
       return new DERSequence(otherName);
   }

   private static String unescapePermanentIdentifierValue(String escapedValue) {
       return escapedValue.replace("\\" + PERMANENTIDENTIFIER, PERMANENTIDENTIFIER);
   }

   /**
    * (This method intentionally has package level visibility to be able to be invoked from JUnit tests.)
    * @param permanentIdentifierString
    * @return A two elements String array with the extension values
    */
   private static String[] getPermanentIdentifierValues(String permanentIdentifierString) {
       String[] result = new String[2];
       int sepPos = permanentIdentifierString.lastIndexOf(PERMANENTIDENTIFIER_SEP);
       if (sepPos == -1) {
           if (!permanentIdentifierString.isEmpty()) {
               result[0] = unescapePermanentIdentifierValue(permanentIdentifierString);
           }
       } else if (sepPos == 0) {
           if (permanentIdentifierString.length() > 1) {
               result[1] = permanentIdentifierString.substring(1);
           }
       } else if (permanentIdentifierString.charAt(sepPos - PERMANENTIDENTIFIER_SEP.length()) != '\\') {
           result[0] = unescapePermanentIdentifierValue(permanentIdentifierString.substring(0, sepPos));
           if (permanentIdentifierString.length() > sepPos + PERMANENTIDENTIFIER_SEP.length()) {
               result[1] = permanentIdentifierString.substring(sepPos + 1);
           }
       }
       return result;
   }

   /**
    * Obtain the directory string for the directoryName generation form the Subject Alternative Name String.
    *
    * @param altName
    * @return
    */
   private static String getDirectoryStringFromAltName(String altName) {
       String directoryName = DnComponents.getPartFromDN(altName, DIRECTORYNAME);
       /** TODO: Validate or restrict the directoryName Fields? */
       return ("".equals(directoryName) ? null : directoryName);
   }

   /**
    * Obtain a X500Name reordered, if some fields from original X500Name doesn't appear in "ordering" parameter, they will be added at end in the
    * original order.
    *
    * @param x500Name the X500Name that is unordered
    * @param ldaporder true if LDAP ordering of DN should be used (default in EJBCA), false for X.500 order, ldap order is CN=A,OU=B,O=C,C=SE, x.500
    *            order is the reverse
    * @param order specified order, which overrides 'ldaporder', care must be taken constructing this String array, ignored if null or empty
    * @param applyLdapToCustomOrder specifies if the ldaporder setting should apply to an order (custom order) if this is not empty
    * @param nameStyle Controls how the name is encoded. Usually it should be a CeSecoreNameStyle.
    * @return X500Name with ordered components according to the ordering vector
    */
   private static X500Name getOrderedX500Name(final X500Name x500Name, boolean ldaporder, String[] order, final boolean applyLdapToCustomOrder, final X500NameStyle nameStyle) {
       // Guess order of the input name
       final boolean isLdapOrder = !isDNReversed(x500Name.toString());
       // If we think the DN is in LDAP order, first order it as a LDAP DN, if we don't think it's LDAP order
       // order it as a X.500 DN. If we haven't specified our own ordering
       final List<ASN1ObjectIdentifier> ordering;
       final boolean useCustomOrder = (order != null) && (order.length > 0);
       if (useCustomOrder) {
           log.debug("Using custom DN order");
           ordering = getX509FieldOrder(order);
       } else {
           ordering = getX509FieldOrder(isLdapOrder);
       }

       // -- New order for the X509 Fields
       final List<ASN1ObjectIdentifier> newOrdering = new ArrayList<>();
       final List<RDN> newValues = new ArrayList<>();
       // -- Add ordered fields
       final RDN[] allRdns= x500Name.getRDNs();

       final HashSet<ASN1ObjectIdentifier> hs = new HashSet<>(allRdns.length + ordering.size());
       for (final ASN1ObjectIdentifier oid : ordering) {
           if (!hs.contains(oid)) {
               hs.add(oid);
               // We can't use x500Name.getRDNs(oid) because it will also hunt inside multi valued RNDs
               //final RDN[] valueList = x500Name.getRDNs(oid);
               // -- Only add the OID if has not null value
               for (final RDN value : allRdns) {
                   if (oid.equals(value.getFirst().getType())) {
                       newOrdering.add(oid);
                       newValues.add(value);
                   }
               }
           }
       }
       // -- Add unexpected fields to the end
       for (final RDN rdn : allRdns) {
           final ASN1ObjectIdentifier oid = rdn.getFirst().getType();
           if (!hs.contains(oid)) {
               hs.add(oid);
               final RDN[] valueList = x500Name.getRDNs(oid);
               // -- Only add the OID if has not null value
               for (final RDN value : valueList) {
                   newOrdering.add(oid);
                   newValues.add(value);
                   if (log.isDebugEnabled()) {
                       log.debug("added --> " + oid + " val: " + value);
                   }
               }
           }
       }
       // If the requested ordering was the reverse of the ordering the input string was in (by our guess in the beginning)
       // we have to reverse the vectors.
       // Unless we have specified a custom order, and choose to not apply LDAP Order to this custom order, in which case we will not change the order from the custom
       if ( (useCustomOrder && applyLdapToCustomOrder) || !useCustomOrder) {
           if (ldaporder != isLdapOrder) {
               if (log.isDebugEnabled()) {
                   log.debug("Reversing order of DN, ldaporder=" + ldaporder + ", isLdapOrder=" + isLdapOrder);
               }
               Collections.reverse(newOrdering);
               Collections.reverse(newValues);
           }
       }

       X500NameBuilder nameBuilder = new X500NameBuilder(nameStyle);
       for (int i = 0; i < newOrdering.size(); i++) {
           RDN rdn = newValues.get(i);
           if (rdn.isMultiValued()) {
               AttributeTypeAndValue avas[] = rdn.getTypesAndValues();
               if (log.isDebugEnabled()) {
                   log.debug("Multi-value RDN with "+avas.length+" number of values in it.");
               }
               nameBuilder.addMultiValuedRDN(avas);
           } else {
               nameBuilder.addRDN(newOrdering.get(i), rdn.getFirst().getValue());
           }
       }
       // -- Return X500Name with the ordered fields
       return nameBuilder.build();
   }

    private static List<String> getPartsFromDNInternal(final String dn, final String dnPart, final boolean onlyReturnFirstMatch) {
        if (log.isTraceEnabled()) {
            log.trace(">getPartsFromDNInternal: dn:'" + dn + "', dnpart=" + dnPart + ", onlyReturnFirstMatch=" + onlyReturnFirstMatch);
        }
        final List<String> parts = new ArrayList<>();
        if (dn != null && dnPart != null) {
            final String dnPartLowerCase = dnPart.toLowerCase();
            final int dnPartLenght = dnPart.length();
            boolean quoted = false;
            boolean escapeNext = false;
            int currentStartPosition = -1;
            for (int i = 0; i < dn.length(); i++) {
                final char current = dn.charAt(i);
                // Toggle quoting for every non-escaped "-char
                if (!escapeNext && current == '"') {
                    quoted = !quoted;
                }
                // If there is an unescaped and unquoted =-char we need to investigate if it is a match for the sought after part
                if (!quoted && !escapeNext && current == '=' && dnPartLenght <= i) {
                    // Check that the character before our expected partName isn't a letter (e.g. dnsName=.. should not match E=..)
                    if (i - dnPartLenght - 1 < 0 || !Character.isLetter(dn.charAt(i - dnPartLenght - 1))) {
                        boolean match = true;
                        for (int j = 0; j < dnPartLenght; j++) {
                            if (Character.toLowerCase(dn.charAt(i - dnPartLenght + j)) != dnPartLowerCase.charAt(j)) {
                                match = false;
                                break;
                            }
                        }
                        if (match) {
                            currentStartPosition = i + 1;
                        }
                    }
                }
                // When we have found a start marker, we need to be on the lookout for the ending marker
                if (currentStartPosition != -1 && ((!quoted && !escapeNext && (current == ',' || current == '+')) || i == dn.length() - 1)) {
                    int endPosition = (i == dn.length() - 1) ? dn.length() - 1 : i - 1;
                    // Remove white spaces from the end of the value
                    while (endPosition > currentStartPosition && dn.charAt(endPosition) == ' ') {
                        endPosition--;
                    }
                    // Remove white spaces from the beginning of the value
                    while (endPosition > currentStartPosition && dn.charAt(currentStartPosition) == ' ') {
                        currentStartPosition++;
                    }
                    // Only return the inner value if the part is quoted
                    if (currentStartPosition != dn.length() && dn.charAt(currentStartPosition) == '"' && dn.charAt(endPosition) == '"') {
                        currentStartPosition++;
                        endPosition--;
                    }
                    parts.add(unescapeFieldValue(dn.substring(currentStartPosition, endPosition + 1)));
                    if (onlyReturnFirstMatch) {
                        break;
                    }
                    currentStartPosition = -1;
                }
                if (escapeNext) {
                    // This character was escaped, so don't escape the next one
                    escapeNext = false;
                } else {
                    if (!quoted && current == '\\') {
                        // This escape character is not escaped itself, so the next one should be
                        escapeNext = true;
                    }
                }
            }
        }
        if (log.isTraceEnabled()) {
            log.trace("<getPartsFromDNInternal: resulting DN part=" + parts.toString());
        }
        return parts;
    }

    /**
     * Returns the RDN after unescaping the characters requiring escaping.
     *
     * <p>For example, for the rdn "cn=Acme\, Inc", the unescapeRDN method
     * returns "cn=Acme, Inc".</p>
     * <p><b>Note:</b>This function doesn't check for the
     * validity of the RDN string use isValid(String) function to check the
     * validity. The results is undefined for invalid RDN's.
     * </p>
     * unescapeRDN unescapes the AttributeValue by
     * removing the '\' when the next character fits the following:<BR>
     * ',' '+' '"' '\' '<' '>' ';'<BR>
     * '#' if it comes at the beginning of the Attribute Name
     * (without the '\').<BR>
     * ' ' (space) if it comes at the beginning or the end of the Attribute Name
     * </p>
     *  @param rdn            The RDN to unescape.
     *
     * @return The RDN with the escaping characters removed.
     */
    private static String unescapeRDN(String rdn) {
        StringBuffer unescaped = new StringBuffer();
        int i = 0;

        while (i < rdn.length() && rdn.charAt(i) != '=') {
            unescaped.append(rdn.charAt(i));
            i++; //advance until we find the separator =
        }
        //add character '='
        unescaped.append(rdn.charAt(i));
        if (i == rdn.length()) {
            throw new IllegalArgumentException("Could not parse rdn: Attribute " + "type and name must be separated by an equal symbol, '='");
        }
        i++;
        //check if the first two chars are "\ " (slash space) or "\#"
        if ((rdn.charAt(i) == '\\') && (i + 1 < rdn.length() - 1) //bounds checking
                && ((rdn.charAt(i + 1) == ' ') || (rdn.charAt(i + 1) == '#'))) {
            i++;
        }
        for (; i < rdn.length(); i++) {
            //if the current char is a slash, not the end char, and is followed
            // by a special char then...
            if ((rdn.charAt(i) == '\\') && (i != rdn.length() - 1)) {
                if ((rdn.charAt(i + 1) == ',') || (rdn.charAt(i + 1) == '+') || (rdn.charAt(i + 1) == '"') || (rdn.charAt(i + 1) == '\\')
                        || (rdn.charAt(i + 1) == '<') || (rdn.charAt(i + 1) == '>') || (rdn.charAt(i + 1) == ';')) { //I'm not sure if I have to check for these special chars
                    unescaped.append(rdn.charAt(i + 1));
                    i++;
                    continue;
                }
                //check if the last two chars are "\ "
                else if ((rdn.charAt(i + 1) == ' ') && (i + 2 == rdn.length())) {
                    //if the last char is a space
                    continue;
                }
            }
            unescaped.append(rdn.charAt(i));
        }
        return unescaped.toString();
    }

    /**
     * Reads properties from a properties file. Fails nicely if file wasn't found.
     *
     * @param propertiesFile
     */
    private static void loadProfileMappingsFromFile(String propertiesFile) {
        // Read the file to an array of lines
        String line;

        BufferedReader in = null;
        InputStreamReader inf = null;
        try {
            InputStream is = obj.getClass().getResourceAsStream(propertiesFile);
            if (is != null) {
                inf = new InputStreamReader(is);
                in = new BufferedReader(inf);
                if (!in.ready()) {
                    throw new IOException("Couldn't read " + propertiesFile);
                }
                String[] splits = null;
                int lines = 0;
                ArrayList<Integer> dnids = new ArrayList<>();
                ArrayList<Integer> profileids = new ArrayList<>();
                while ((line = in.readLine()) != null) {
                    if (!line.startsWith("#")) { // # is a comment line
                        splits = StringUtils.split(line, ';');
                        if ((splits != null) && (splits.length > 5)) {
                            String type = splits[0];
                            String dnname = splits[1];
                            Integer dnid = Integer.valueOf(splits[2]);
                            String profilename = splits[3];
                            Integer profileid = Integer.valueOf(splits[4]);
                            String errstr = splits[5];
                            String langstr = splits[6];
                            if (dnids.contains(dnid)) {
                                log.error("Duplicated DN Id " + dnid + " detected in mapping file.");
                            } else {
                                dnids.add(dnid);
                            }
                            if (profileids.contains(profileid)) {
                                log.error("Duplicated Profile Id " + profileid + " detected in mapping file.");
                            } else {
                                profileids.add(profileid);
                            }
                            // Fill maps
                            profileNameIdMap.put(profilename, profileid);
                            dnIdToProfileNameMap.put(dnid, profilename);
                            dnIdToProfileIdMap.put(dnid, profileid);
                            dnIdErrorMap.put(dnid, errstr);
                            profileIdToDnIdMap.put(profileid, dnid);
                            dnErrorTextMap.put(dnid, errstr);
                            profileNameLanguageMap.put(profilename, langstr);
                            profileIdLanguageMap.put(profileid, langstr);
                            if (type.equals("DN")) {
                                dnNameToIdMap.put(dnname, dnid);
                                dnProfileFields.add(profilename);
                                dnProfileFieldsHashSet.add(profilename);
                                dnLanguageTexts.add(langstr);
                                dnDnIds.add(dnid);
                                dnExtractorFields.add(dnname + "=");
                                dnIdToExtractorFieldMap.put(dnid, dnname + "=");
                            }
                            if (type.equals("ALTNAME")) {
                                altNameToIdMap.put(dnname, dnid);
                                altNameFields.add(dnname);
                                altNameFieldsHashSet.add(dnname);
                                altNameLanguageTexts.add(langstr);
                                altNameDnIds.add(dnid);
                                altNameExtractorFields.add(dnname + "=");
                                altNameIdToExtractorFieldMap.put(dnid, dnname + "=");
                            }
                            if (type.equals("DIRATTR")) {
                                dirAttrToIdMap.put(dnname, dnid);
                                dirAttrFields.add(dnname);
                                dirAttrFieldsHashSet.add(dnname);
                                dirAttrLanguageTexts.add(langstr);
                                dirAttrDnIds.add(dnid);
                                dirAttrExtractorFields.add(dnname + "=");
                                dirAttrIdToExtractorFieldMap.put(dnid, dnname + "=");
                            }
                            lines++;
                        }
                    }
                }
                in.close();
                if(log.isDebugEnabled()) {
                log.debug("Read profile maps with " + lines + " lines.");
                }
            } else {
                if(log.isDebugEnabled()) {
                    log.debug("Properties file " + propertiesFile + " was not found.");
                }
            }
        } catch (IOException e) {
            log.error("Can not load profile mappings: ", e);
        } finally {
            try {
                if (inf != null) {
                    inf.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                log.debug("Error occurred while closing input stream", e);
            }
        }
    }

    /**
     * Load DN ordering used in stringToBCDNString etc.
     * Loads from file placed in src/dncomponents.properties
     *
     */
    private static void loadOrdering() {
        // Read the file to an array of lines
        String line;
        LinkedHashMap<String, ASN1ObjectIdentifier> map = new LinkedHashMap<>();
        BufferedReader in = null;
        InputStreamReader inf = null;
        try {
            InputStream is = obj.getClass().getResourceAsStream("/dncomponents.properties");
            //log.info("is is: " + is);
            if (is != null) {
                inf = new InputStreamReader(is);
                //inf = new FileReader("c:\\foo.properties");
                in = new BufferedReader(inf);
                if (!in.ready()) {
                    throw new IOException();
                }
                String[] splits = null;
                while ((line = in.readLine()) != null) {
                    if (!line.startsWith("#")) { // # is a comment line
                        splits = StringUtils.split(line, '=');
                        if ((splits != null) && (splits.length > 1)) {
                            String name = splits[0].toLowerCase(Locale.ROOT);
                            ASN1ObjectIdentifier oid = new ASN1ObjectIdentifier(splits[1]);
                            map.put(name, oid);
                        }
                    }
                }
                in.close();
                // Now we have read it in, transfer it to the main oid map
                log.info("Using DN components from properties file");
                oids.clear();
                oids.putAll(map);
                Set<String> keys = map.keySet();
                // Set the maps to the desired ordering
                dNObjectsForward = keys.toArray(new String[keys.size()]);
            } else {
                log.debug("Using default values for DN components");
            }
        } catch (IOException e) {
            log.debug("Using default values for DN components");
        } finally {
            try {
                if (inf != null) {
                    inf.close();
                }
                if (in != null) {
                    in.close();
                }
            } catch (IOException e) {
                log.debug("Error occurred while closing input stream", e);
            }
        }

    }

    /**
     * Obtains a List with the ASN1ObjectIdentifiers for dNObjects names, in the specified order
     *
     * @param order an array of DN objects.
     * @return a List with ASN1ObjectIdentifiers defining the known order we require
     * @see com.keyfactor.util.certificate.DnComponents#getDnObjects(boolean) for definition of the contents of the input array
     */
    private static List<ASN1ObjectIdentifier> getX509FieldOrder(String[] order) {
        List<ASN1ObjectIdentifier> fieldOrder = new ArrayList<>();
        for (final String dNObject : order) {
            fieldOrder.add(DnComponents.getOid(dNObject));
        }
        return fieldOrder;
    }

    /**
     * class for breaking up an X500 Name into it's component tokens, ala java.util.StringTokenizer.
     */
    private static class X509NameTokenizer {
        private String value;
        private int index;
        private char separator;
        private StringBuffer buf = new StringBuffer();

        /** Creates the object, using the default comma (,) as separator for tokenization */
        public X509NameTokenizer(String oid) {
            this(oid, ',');
        }

        public X509NameTokenizer(String oid, char separator) {
            this.value = oid;
            this.index = -1;
            this.separator = separator;
        }

        public boolean hasMoreTokens() {
            return (value != null && index != value.length());
        }

        public String nextToken() {
            if (index == value.length()) {
                return null;
            }

            int end = index + 1;
            boolean quoted = false;
            boolean escaped = false;

            buf.setLength(0);

            while (end != value.length()) {
                char c = value.charAt(end);

                if (c == '"') {
                    if (!escaped) {
                        quoted = !quoted;
                    } else {
                        if (c == '#' && buf.charAt(buf.length() - 1) == '=') {
                            buf.append('\\');
                        } else if (c == '+' && separator != '+') {
                            buf.append('\\');
                        }
                        buf.append(c);
                    }
                    escaped = false;
                } else {
                    if (escaped || quoted) {
                        if (c == '#' && buf.charAt(buf.length() - 1) == '=') {
                            buf.append('\\');
                        } else if (c == '+' && separator != '+') {
                            buf.append('\\');
                        }
                        buf.append(c);
                        escaped = false;
                    } else if (c == '\\') {
                        escaped = true;
                    } else if (c == separator) {
                        break;
                    } else {
                        buf.append(c);
                    }
                }
                end++;
            }

            index = end;
            return buf.toString().trim();
        }

        /**
         * Returns the remaining (not yet tokenized) part of the DN.
         */
        String getRemainingString() {
            return index + 1 < value.length() ? value.substring(index + 1) : "";
        }
    }

    /**
     * class for breaking up an X500 Name into it's component tokens, ala java.util.StringTokenizer. Taken from BouncyCastle, but does NOT use or
     * consider escaped characters. Used for reversing DNs without unescaping.
     */
    private static class BasicX509NameTokenizer {
        private final String oid;
        private int index = -1;
        /*
         * Since this class isn't thread safe anyway, we can use the slightly faster StringBuilder instead of StringBuffer
         */
        private StringBuilder buf = new StringBuilder();

        public BasicX509NameTokenizer(String oid) {
            this.oid = oid;
        }

        public boolean hasMoreTokens() {
            return (index != oid.length());
        }

        public String nextToken() {
            if (index == oid.length()) {
                return null;
            }

            int end = index + 1;
            boolean quoted = false;
            boolean escaped = false;

            buf.setLength(0);

            while (end != oid.length()) {
                char c = oid.charAt(end);

                if (c == '"') {
                    if (!escaped) {
                        buf.append(c);
                        quoted ^= true; // Faster than "quoted = !quoted;"
                    } else {
                        buf.append(c);
                    }
                    escaped = false;
                } else {
                    if (escaped || quoted) {
                        buf.append(c);
                        escaped = false;
                    } else if (c == '\\') {
                        buf.append(c);
                        escaped = true;
                    } else if ((c == ',') && (!escaped)) {
                        break;
                    } else {
                        buf.append(c);
                    }
                }
                end++;
            }

            index = end;
            return StringTools.trimUnescaped(buf.toString());
        }
    }


}
