/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.crypto.algorithm;

import java.util.Arrays;
import java.util.List;

/** Constants for digital signature algorithms.
 */
public final class AlgorithmConstants {

    public static final String SIGALG_MD5_WITH_RSA             = "MD5WithRSA";
    public static final String SIGALG_SHA1_WITH_RSA            = "SHA1WithRSA";
    public static final String SIGALG_SHA256_WITH_RSA          = "SHA256WithRSA";
    public static final String SIGALG_SHA384_WITH_RSA          = "SHA384WithRSA";
    public static final String SIGALG_SHA512_WITH_RSA          = "SHA512WithRSA";
    public static final String SIGALG_SHA3_256_WITH_RSA        = "SHA3-256withRSA";
    public static final String SIGALG_SHA3_384_WITH_RSA        = "SHA3-384withRSA";
    public static final String SIGALG_SHA3_512_WITH_RSA        = "SHA3-512withRSA";
    public static final String SIGALG_SHA1_WITH_ECDSA          = "SHA1withECDSA";
    public static final String SIGALG_SHA224_WITH_ECDSA        = "SHA224withECDSA";
    public static final String SIGALG_SHA256_WITH_ECDSA        = "SHA256withECDSA";
    public static final String SIGALG_SHA384_WITH_ECDSA        = "SHA384withECDSA";
    public static final String SIGALG_SHA512_WITH_ECDSA        = "SHA512withECDSA";
    public static final String SIGALG_SHA3_256_WITH_ECDSA      = "SHA3-256withECDSA";
    public static final String SIGALG_SHA3_384_WITH_ECDSA      = "SHA3-384withECDSA";
    public static final String SIGALG_SHA3_512_WITH_ECDSA      = "SHA3-512withECDSA";
    public static final String SIGALG_SHA256_WITH_RSA_AND_MGF1 = "SHA256withRSAandMGF1";
    public static final String SIGALG_SHA384_WITH_RSA_AND_MGF1 = "SHA384withRSAandMGF1";
    public static final String SIGALG_SHA512_WITH_RSA_AND_MGF1 = "SHA512withRSAandMGF1";
    public static final String SIGALG_SHA1_WITH_RSA_AND_MGF1   = "SHA1withRSAandMGF1"; // Not possible to select in Admin-GUI
    public static final String SIGALG_ED25519                  = "Ed25519";
    public static final String SIGALG_ED448                    = "Ed448";
    public static final String SIGALG_FALCON512                = "FALCON-512";
    public static final String SIGALG_FALCON1024               = "FALCON-1024";
    public static final String SIGALG_MLKEM512                 = "ML-KEM-512";
    public static final String SIGALG_MLKEM768                 = "ML-KEM-768";
    public static final String SIGALG_MLKEM1024                = "ML-KEM-1024";
    public static final String SIGALG_MLDSA44                  = "ML-DSA-44";
    public static final String SIGALG_MLDSA65                  = "ML-DSA-65";
    public static final String SIGALG_MLDSA87                  = "ML-DSA-87";
    public static final String SIGALG_LMS                      = "LMS";
    public static final String SIGALG_SLHDSA_SHA2_128S         = "SLH-DSA-SHA2-128S";
    public static final String SIGALG_SLHDSA_SHAKE_128S        = "SLH-DSA-SHAKE-128S";
    public static final String SIGALG_SLHDSA_SHA2_128F         = "SLH-DSA-SHA2-128F";
    public static final String SIGALG_SLHDSA_SHAKE_128F        = "SLH-DSA-SHAKE-128F";
    public static final String SIGALG_SLHDSA_SHA2_192S         = "SLH-DSA-SHA2-192S";
    public static final String SIGALG_SLHDSA_SHAKE_192S        = "SLH-DSA-SHAKE-192S";
    public static final String SIGALG_SLHDSA_SHA2_192F         = "SLH-DSA-SHA2-192F";
    public static final String SIGALG_SLHDSA_SHAKE_192F        = "SLH-DSA-SHAKE-192F";
    public static final String SIGALG_SLHDSA_SHA2_256S         = "SLH-DSA-SHA2-256S";
    public static final String SIGALG_SLHDSA_SHAKE_256S        = "SLH-DSA-SHAKE-256S";
    public static final String SIGALG_SLHDSA_SHA2_256F         = "SLH-DSA-SHA2-256F";
    public static final String SIGALG_SLHDSA_SHAKE_256F        = "SLH-DSA-SHAKE-256F";
    public static final String SIGALG_MLDSA44_RSA2048_PSS_SHA256 = "MLDSA44-RSA2048-PSS-SHA256";
    public static final String SIGALG_MLDSA44_RSA2048_PKCS15_SHA256 = "MLDSA44-RSA2048-PKCS15-SHA256";
    public static final String SIGALG_MLDSA44_ECDSA_P256_SHA256 = "MLDSA44-ECDSA-P256-SHA256";
    public static final String SIGALG_MLDSA44_Ed25519_SHA512 = "MLDSA44-Ed25519-SHA512";
    public static final String SIGALG_MLDSA65_RSA3072_PSS_SHA512 = "MLDSA65-RSA3072-PSS-SHA512";
    public static final String SIGALG_MLDSA65_RSA4096_PSS_SHA512 = "MLDSA65-RSA4096-PSS-SHA512";
    public static final String SIGALG_MLDSA65_RSA3072_PKCS15_SHA512 = "MLDSA65-RSA3072-PKCS15-SHA512";
    public static final String SIGALG_MLDSA65_RSA4096_PKCS15_SHA512 = "MLDSA65-RSA4096-PKCS15-SHA512";
    public static final String SIGALG_MLDSA65_ECDSA_P256_SHA512 = "MLDSA65-ECDSA-P256-SHA512";
    public static final String SIGALG_MLDSA65_ECDSA_P384_SHA512 = "MLDSA65-ECDSA-P384-SHA512";
    public static final String SIGALG_MLDSA65_Ed25519_SHA512 = "MLDSA65-Ed25519-SHA512";
    public static final String SIGALG_MLDSA65_ECDSA_brainpoolP256r1_SHA512 = "MLDSA65-ECDSA-brainpoolP256r1-SHA512";
    public static final String SIGALG_MLDSA87_RSA3072_PSS_SHA512 = "MLDSA87-RSA3072-PSS-SHA512";
    public static final String SIGALG_MLDSA87_RSA4096_PSS_SHA512 = "MLDSA87-RSA4096-PSS-SHA512";
    public static final String SIGALG_MLDSA87_ECDSA_P384_SHA512 = "MLDSA87-ECDSA-P384-SHA512";
    public static final String SIGALG_MLDSA87_ECDSA_P521_SHA512 = "MLDSA87-ECDSA-P521-SHA512";
    public static final String SIGALG_MLDSA87_ECDSA_brainpoolP384r1_SHA512 = "MLDSA87-ECDSA-brainpoolP384r1-SHA512";
    public static final String SIGALG_MLDSA87_Ed448_SHAKE256 = "MLDSA87-Ed448-SHAKE256";

    /**
     * Signature algorithms available to choose from.
     * Call AlgorithmTools.isSigAlgEnabled() to determine if a given sigalg is enabled and should be shown in the UI.
     * Note: For composite algorithms we don't support PKCS15 based ones yet
     */
    public static final String[] AVAILABLE_SIGALGS = {
        SIGALG_SHA1_WITH_RSA,
        SIGALG_SHA256_WITH_RSA,
        SIGALG_SHA384_WITH_RSA,
        SIGALG_SHA512_WITH_RSA,
        SIGALG_SHA3_256_WITH_RSA,
        SIGALG_SHA3_384_WITH_RSA,
        SIGALG_SHA3_512_WITH_RSA,
        SIGALG_SHA256_WITH_RSA_AND_MGF1,
        SIGALG_SHA384_WITH_RSA_AND_MGF1,
        SIGALG_SHA512_WITH_RSA_AND_MGF1,
        SIGALG_SHA1_WITH_ECDSA,
        SIGALG_SHA224_WITH_ECDSA,
        SIGALG_SHA256_WITH_ECDSA,
        SIGALG_SHA384_WITH_ECDSA,
        SIGALG_SHA512_WITH_ECDSA,
        SIGALG_SHA3_256_WITH_ECDSA,
        SIGALG_SHA3_384_WITH_ECDSA,
        SIGALG_SHA3_512_WITH_ECDSA,
        SIGALG_ED25519,
        SIGALG_ED448,
        SIGALG_FALCON512,
        SIGALG_FALCON1024,
        SIGALG_MLKEM512,
        SIGALG_MLKEM768,
        SIGALG_MLKEM1024,
        SIGALG_MLDSA44,
        SIGALG_MLDSA65,
        SIGALG_MLDSA87,
        SIGALG_LMS,
        SIGALG_SLHDSA_SHA2_128S,
        SIGALG_SLHDSA_SHAKE_128S,
        SIGALG_SLHDSA_SHA2_128F,
        SIGALG_SLHDSA_SHAKE_128F,
        SIGALG_SLHDSA_SHA2_192S,
        SIGALG_SLHDSA_SHAKE_192S,
        SIGALG_SLHDSA_SHA2_192F,
        SIGALG_SLHDSA_SHAKE_192F,
        SIGALG_SLHDSA_SHA2_256S,
        SIGALG_SLHDSA_SHAKE_256S,
        SIGALG_SLHDSA_SHA2_256F,
        SIGALG_SLHDSA_SHAKE_256F,
        SIGALG_MLDSA44_RSA2048_PSS_SHA256,
        SIGALG_MLDSA44_ECDSA_P256_SHA256,
        SIGALG_MLDSA44_Ed25519_SHA512,
        SIGALG_MLDSA65_RSA3072_PSS_SHA512,
        SIGALG_MLDSA65_RSA4096_PSS_SHA512,
        SIGALG_MLDSA65_ECDSA_P256_SHA512,
        SIGALG_MLDSA65_ECDSA_P384_SHA512,
        SIGALG_MLDSA65_Ed25519_SHA512,
        SIGALG_MLDSA65_ECDSA_brainpoolP256r1_SHA512,
        SIGALG_MLDSA87_RSA3072_PSS_SHA512,
        SIGALG_MLDSA87_RSA4096_PSS_SHA512,
        SIGALG_MLDSA87_ECDSA_P384_SHA512,
        SIGALG_MLDSA87_ECDSA_P521_SHA512,
        SIGALG_MLDSA87_ECDSA_brainpoolP384r1_SHA512,
        SIGALG_MLDSA87_Ed448_SHAKE256
    };

    public static final String KEYALGORITHM_RSA                     = "RSA";
    public static final String KEYALGORITHM_EC                      = "EC";
    public static final String KEYALGORITHM_ECDSA                   = "ECDSA"; //The same as "EC", just named differently sometimes. "EC" and "ECDSA" should be handled in the same way
    public static final String KEYALGORITHM_ED25519                 = "Ed25519";
    public static final String KEYALGORITHM_ED448                   = "Ed448";
    public static final String KEYALGORITHM_FALCON512               = "FALCON-512";
    public static final String KEYALGORITHM_FALCON1024              = "FALCON-1024";
    public static final String KEYALGORITHM_MLKEM512                = "ML-KEM-512";
    public static final String KEYALGORITHM_MLKEM768                = "ML-KEM-768";
    public static final String KEYALGORITHM_MLKEM1024               = "ML-KEM-1024";
    public static final String KEYALGORITHM_MLDSA                   = "ML-DSA"; // Generic for key algorithms, use the specific for generating keys
    public static final String KEYALGORITHM_MLDSA44                 = "ML-DSA-44";
    public static final String KEYALGORITHM_MLDSA65                 = "ML-DSA-65";
    public static final String KEYALGORITHM_MLDSA87                 = "ML-DSA-87";
    public static final String KEYALGORITHM_SLHDSA_SHA2_128S        = "SLH-DSA-SHA2-128S";
    public static final String KEYALGORITHM_SLHDSA_SHAKE_128S       = "SLH-DSA-SHAKE-128S";
    public static final String KEYALGORITHM_SLHDSA_SHA2_128F        = "SLH-DSA-SHA2-128F";
    public static final String KEYALGORITHM_SLHDSA_SHAKE_128F       = "SLH-DSA-SHAKE-128F";
    public static final String KEYALGORITHM_SLHDSA_SHA2_192S        = "SLH-DSA-SHA2-192S";
    public static final String KEYALGORITHM_SLHDSA_SHAKE_192S       = "SLH-DSA-SHAKE-192S";
    public static final String KEYALGORITHM_SLHDSA_SHA2_192F        = "SLH-DSA-SHA2-192F";
    public static final String KEYALGORITHM_SLHDSA_SHAKE_192F       = "SLH-DSA-SHAKE-192F";
    public static final String KEYALGORITHM_SLHDSA_SHA2_256S        = "SLH-DSA-SHA2-256S";
    public static final String KEYALGORITHM_SLHDSA_SHAKE_256S       = "SLH-DSA-SHAKE-256S";
    public static final String KEYALGORITHM_SLHDSA_SHA2_256F        = "SLH-DSA-SHA2-256F";
    public static final String KEYALGORITHM_SLHDSA_SHAKE_256F       = "SLH-DSA-SHAKE-256F";
    public static final String KEYALGORITHM_LMS                     = "LMS"; // Generic for key algorithms, use keySPec with parameters for generating keys, i.e. LMS_SHA256_N32_H5
    public static final String KEYALGORITHM_HSS                     = "HSS";
    // For composite algorithms the key and signature algorithms are exactly the same name
    public static final String KEYALGORITHM_MLDSA44_RSA2048_PSS_SHA256 = SIGALG_MLDSA44_RSA2048_PSS_SHA256;
    public static final String KEYALGORITHM_MLDSA44_RSA2048_PKCS15_SHA256 = SIGALG_MLDSA44_RSA2048_PKCS15_SHA256;
    public static final String KEYALGORITHM_MLDSA44_ECDSA_P256_SHA256 = SIGALG_MLDSA44_ECDSA_P256_SHA256;
    public static final String KEYALGORITHM_MLDSA44_Ed25519_SHA512 = SIGALG_MLDSA44_Ed25519_SHA512;
    public static final String KEYALGORITHM_MLDSA65_RSA3072_PSS_SHA512 = SIGALG_MLDSA65_RSA3072_PSS_SHA512;
    public static final String KEYALGORITHM_MLDSA65_RSA4096_PSS_SHA512 = SIGALG_MLDSA65_RSA4096_PSS_SHA512;
    public static final String KEYALGORITHM_MLDSA65_RSA3072_PKCS15_SHA512 = SIGALG_MLDSA65_RSA3072_PKCS15_SHA512;
    public static final String KEYALGORITHM_MLDSA65_RSA4096_PKCS15_SHA512 = SIGALG_MLDSA65_RSA4096_PKCS15_SHA512;
    public static final String KEYALGORITHM_MLDSA65_ECDSA_P256_SHA512 = SIGALG_MLDSA65_ECDSA_P256_SHA512;
    public static final String KEYALGORITHM_MLDSA65_ECDSA_P384_SHA512 = SIGALG_MLDSA65_ECDSA_P384_SHA512;
    public static final String KEYALGORITHM_MLDSA65_Ed25519_SHA512 = SIGALG_MLDSA65_Ed25519_SHA512;
    public static final String KEYALGORITHM_MLDSA65_ECDSA_brainpoolP256r1_SHA512 = SIGALG_MLDSA65_ECDSA_brainpoolP256r1_SHA512;
    public static final String KEYALGORITHM_MLDSA87_RSA3072_PSS_SHA512 = SIGALG_MLDSA87_RSA3072_PSS_SHA512;
    public static final String KEYALGORITHM_MLDSA87_RSA4096_PSS_SHA512 = SIGALG_MLDSA87_RSA4096_PSS_SHA512;
    public static final String KEYALGORITHM_MLDSA87_ECDSA_P384_SHA512 = SIGALG_MLDSA87_ECDSA_P384_SHA512;
    public static final String KEYALGORITHM_MLDSA87_ECDSA_P521_SHA512 = SIGALG_MLDSA87_ECDSA_P521_SHA512;
    public static final String KEYALGORITHM_MLDSA87_ECDSA_brainpoolP384r1_SHA512 = SIGALG_MLDSA87_ECDSA_brainpoolP384r1_SHA512;
    public static final String KEYALGORITHM_MLDSA87_Ed448_SHAKE256 = SIGALG_MLDSA87_Ed448_SHAKE256;

    public static final String HASHALGORITHM_SHA1 = "SHA1";
    public static final String HASHALGORITHM_SHA224 = "SHA224";
    public static final String HASHALGORITHM_SHA256 = "SHA256";
    public static final String HASHALGORITHM_SHA384 = "SHA384";
    public static final String HASHALGORITHM_SHA512 = "SHA512";
    public static final String HASHALGORITHM_SHA3_256 = "SHA3-256";
    public static final String HASHALGORITHM_SHA3_384 = "SHA3-384";
    public static final String HASHALGORITHM_SHA3_512 = "SHA3-512";

    //The following curves may be used for ECCDH: P-224, P-256, P-384, P-521, K-233, K-283, K-409, K-571, B-233, B-283, B-409, B-571
    //See https://pages.nist.gov/ACVP/draft-hammett-acvp-kas-ecc-sp800-56ar3.html#name-ecc-cdh-component-test
    public static final List<String> ECCDH_PERMITTED_CURVES = Arrays.asList("secp224r1", "P-224", "prime256v1", "secp256r1", "P-256", "prime384v1", "secp384r1",
            "P-384", "prime521v1", "secp521r1", "P-521", "sect233k1", "K-233", "sect283k1", "K-283", "sect409k1", "K-409", "sect571k1", "K-571",
            "sect233r1", "B-233", "sect283r1", "B-283", "sect309r1", "B-409", "sect571r1", "B-571"

    );

    public static final List<String> BLACKLISTED_EC_CURVES = Arrays.asList(
            // No blacklisted EC curves at the moment
    );

    // Extra EC curves that we want to include that are not part of the "standard" curves in BC (ECNamedCurveTable.getNames)
    public static final List<String> EXTRA_EC_CURVES = Arrays.asList(
            // Part of CustomNamedCurves in BouncyCastle 1.54
            // Commented out due to experimental nature 2017-04 as the signatures using this currently probably is not correct
            // Should probably wait for edDSA, See ECA-5796 and linked issues.
            //"curve25519",
    );

    private AlgorithmConstants () {} // Not for instantiation
}
