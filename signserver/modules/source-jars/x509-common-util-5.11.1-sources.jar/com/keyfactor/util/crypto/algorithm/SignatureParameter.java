/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.crypto.algorithm;

/**
 * Enum to specify additional signature parameters.
 */
public enum SignatureParameter {
    /** No additional parameters */
    NONE,
    /** Use Probabilistic Signature Scheme (PSS) for RSA signatures */
    PSS
}