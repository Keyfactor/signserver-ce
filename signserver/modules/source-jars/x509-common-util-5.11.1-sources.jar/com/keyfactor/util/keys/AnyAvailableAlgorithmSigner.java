/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.keys;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.bouncycastle.asn1.DERSet;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.jce.ECKeyUtil;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.BufferingContentSigner;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;

import com.keyfactor.util.CertTools;
import com.keyfactor.util.crypto.algorithm.AlgorithmConstants;

/*
 * This class will perform a signature with any available algorithm for the given provider, caching a known good one for future use. 
 */
public enum AnyAvailableAlgorithmSigner {
	INSTANCE;

	private static final Logger log = Logger.getLogger(AnyAvailableAlgorithmSigner.class);

	/**
	 * This cache returns a previously known good algorithm, and is indexed on a
	 * hash of the provider and list of available algorithms
	 */
	private Map<Integer, String> providerAndAlgorithmCache = new ConcurrentHashMap<>();

	private int getMapKey(final String provider, List<String> availableSigningAlgorithms) {
		return availableSigningAlgorithms.hashCode() ^ provider.hashCode();
	}

	public void resetCache() {
		providerAndAlgorithmCache = new ConcurrentHashMap<>();
	}

	/**
	 * 
	 * @param provider                   a cryptographic provider
	 * @param availableSigningAlgorithms a list of available algorithms
	 * @return the preferred algorithm for this combination, or null if it's never
	 *         been referenced
	 */
	public String getStoredAlgorithm(final String provider, List<String> availableSigningAlgorithms) {
		return providerAndAlgorithmCache.get(getMapKey(provider, availableSigningAlgorithms));
	}

	/**
	 * Sign an X.509 certificate using the first usable algorithm from the list of
	 * available signature algorithms. This choice will be cached for future use.
	 * 
	 * @param provider                   the cryptographic provider
	 * @param availableSigningAlgorithms a list of available signature algorithms
	 * @param certificateBuilder         a certificate builder
	 * @param privateKey                 the private key needed for the signature
	 * @return the signed certificate
	 * @throws SignatureException if none of the available algorithms
	 */
	public X509CertificateHolder signX509Certificate(final String provider, List<String> availableSigningAlgorithms,
			final X509v3CertificateBuilder certificateBuilder, final PrivateKey privateKey) throws SignatureException {
		final int mapKey = getMapKey(provider, availableSigningAlgorithms);

		if (providerAndAlgorithmCache.containsKey(mapKey)) {
			// If we've used this combo before, get a known working signing algorithm
			final String signingAlgorithm = providerAndAlgorithmCache.get(mapKey);
			if (log.isTraceEnabled()) {
				log.trace("Using previously succesful choice of " + signingAlgorithm);
			}
			try {
				return attemptToSignX509Certificate(signingAlgorithm, provider, privateKey, certificateBuilder);
			} catch (OperatorCreationException e) {
				throw new IllegalStateException("Signing failed in spite of being with known good algorithm", e);
			}
		} else {
			// Nope? Lets' find one.
			for (String signingAlgorithm : availableSigningAlgorithms) {
				if (log.isTraceEnabled()) {
					log.trace("Attempting to use algorithm " + signingAlgorithm);
				}
				try {
					X509CertificateHolder result = attemptToSignX509Certificate(signingAlgorithm, provider, privateKey,
							certificateBuilder);
					providerAndAlgorithmCache.put(mapKey, signingAlgorithm);
					return result;
				} catch (Exception e) { // Catch all - HSM error output can be unpredictable
					// Signing failed, try the next one.
				}
			}
		}

		throw new SignatureException("No algorithm in the available list could be used for private key of algorithm "
				+ privateKey.getAlgorithm() + " Options were: "
				+ availableSigningAlgorithms.stream().collect(Collectors.joining(",")));

	}

	private X509CertificateHolder attemptToSignX509Certificate(final String signingAlgorithm, final String provider,
			final PrivateKey privateKey, final X509v3CertificateBuilder certificateBuilder)
			throws OperatorCreationException {
		final ContentSigner signer = new BufferingContentSigner(
				new JcaContentSignerBuilder(signingAlgorithm).setProvider(provider).build(privateKey), 20480);
		return certificateBuilder.build(signer);
	}

	/**
	 * Sign a CSR using the first usable algorithm from the list of available signature algorithms. This choice will be cached for future use.
	 * 
	 * @param provider the cryptographic provider
	 * @param availableSigningAlgorithms a list of available signature algorithms
	 * @param publicKey the public key to include in the CSR
	 * @param privateKey the signing key
	 * @param alias the alias of the private key being used
	 * @param subjectDn a subject DN, will be replaced with CN='alias' if null
	 * @param explicitEccParameters use only for  ICAO 9303 CSRs
	 * @return a CSR
	 * @throws SignatureException if none of the signing algorithms could be used with the private key
	 */
	public PKCS10CertificationRequest signPkcs10(final String provider, List<String> availableSigningAlgorithms,
			PublicKey publicKey, PrivateKey privateKey, final String alias, final String subjectDn,
			boolean explicitEccParameters) throws SignatureException {
		final int mapKey = getMapKey(provider, availableSigningAlgorithms);

		if (providerAndAlgorithmCache.containsKey(mapKey)) {
			final String signingAlgorithm = providerAndAlgorithmCache.get(mapKey);
			if (log.isTraceEnabled()) {
				log.trace("Using previously succesful choice of " + signingAlgorithm);
			}

			try {
				return attemptToSignPkcs10(signingAlgorithm, provider, publicKey, privateKey, alias, subjectDn,
						explicitEccParameters);
			} catch (OperatorCreationException e) {
				throw new IllegalStateException("Signing failed in spite of being with known good algorithm", e);
			}
		} else {
			for (String signingAlgorithm : availableSigningAlgorithms) {
				if (log.isTraceEnabled()) {
					log.trace("Attempting to use algorithm " + signingAlgorithm);
				}
				try {
					PKCS10CertificationRequest result = attemptToSignPkcs10(signingAlgorithm, provider, publicKey,
							privateKey, alias, subjectDn, explicitEccParameters);
					providerAndAlgorithmCache.put(mapKey, signingAlgorithm);
					return result;
				} catch (Exception e) { // Catch all - HSM error output can be unpredictable
					// Signing failed, try the next one.
				}
			}
		}

		throw new SignatureException("No algorithm in the available list could be used for private key of algorithm "
				+ privateKey.getAlgorithm() + " Options were: "
				+ availableSigningAlgorithms.stream().collect(Collectors.joining(",")));
	}

	private PKCS10CertificationRequest attemptToSignPkcs10(final String signingAlgorithm, final String provider,
			PublicKey publicKey, PrivateKey privateKey, final String alias, final String subjectDn,
			boolean explicitEccParameters) throws OperatorCreationException {
		if (log.isDebugEnabled()) {
			log.debug(String.format("alias: %s, SHA1 of public key: %s, Signature Algorithm: %s, Key Algorithm: %s", alias,
					CertTools.getFingerprintAsString(publicKey.getEncoded()), signingAlgorithm, publicKey.getAlgorithm()));
		}
		if (signingAlgorithm.contains(AlgorithmConstants.KEYALGORITHM_ECDSA) && explicitEccParameters) {
			log.info("Using explicit parameter encoding for ECC key.");
			try {
				publicKey = ECKeyUtil.publicToExplicitParameters(publicKey, BouncyCastleProvider.PROVIDER_NAME);
			} catch (NoSuchAlgorithmException e) {
				throw new IllegalStateException(
						AlgorithmConstants.KEYALGORITHM_ECDSA + " was not found as an algorithm.", e);
			} catch (NoSuchProviderException e) {
				throw new IllegalStateException("BouncyCastle was not found as a provider", e);
			}
		}
		final X500Name sDNName = subjectDn != null ? new X500Name(subjectDn) : new X500Name("CN=" + alias);
		return CertTools.genPKCS10CertificationRequest(signingAlgorithm, sDNName, publicKey, new DERSet(), privateKey,
				provider);

	}

	/**
	 * Sign a block of data using the first usable algorithm from the list of available signature algorithms. This choice will be cached for future use.
	 * 
	 * @param provider the cryptographic provider. If null the BouncyCastle provider will be chosen. 
	 * @param availableSigningAlgorithms a list of available signature algorithms
	 * @param privateKey the private key to sign with
	 * @param payload the byte array to sign
	 * @return a signature of the inputed data
	 * @throws SignatureException if none of the signing algorithms could be used with the private key
	 */
	public byte[] signData(String provider, List<String> availableSigningAlgorithms, final PrivateKey privateKey,
			byte[] payload) throws SignatureException {
		
		if(provider == null) {
			provider = BouncyCastleProvider.PROVIDER_NAME;
		}
		
		final int mapKey = getMapKey(provider, availableSigningAlgorithms);
		try {
			if (providerAndAlgorithmCache.containsKey(mapKey)) {
				final String signingAlgorithm = providerAndAlgorithmCache.get(mapKey);
				if (log.isTraceEnabled()) {
					log.trace("Using previously succesful choice of " + signingAlgorithm);
				}
				try {
					return attemptToSignData(signingAlgorithm, provider, privateKey, payload);
				} catch (SignatureException e) {
					throw new IllegalStateException("Signing failed in spite of being with known good algorithm", e);
				}
			} else {
				for (String signingAlgorithm : availableSigningAlgorithms) {
					if (log.isTraceEnabled()) {
						log.trace("Attempting to use algorithm " + signingAlgorithm);
					}
					try {
						byte[] result = attemptToSignData(signingAlgorithm, provider, privateKey, payload);
						providerAndAlgorithmCache.put(mapKey, signingAlgorithm);
						return result;
					} catch (Exception e) { // Catch all - HSM error output can be unpredictable
						// Signing failed, try the next one.
					}
				}
			}
		} catch (NoSuchProviderException e) {
			throw new SignatureException("Provider " + provider + " not found.", e);
		}
		throw new SignatureException("No algorithm in the available list could be used for private key of algorithm "
				+ privateKey.getAlgorithm() + " Options were: "
				+ availableSigningAlgorithms.stream().collect(Collectors.joining(",")));
	}

	private byte[] attemptToSignData(final String signingAlgorithm, final String provider, final PrivateKey privateKey,
			byte[] payload) throws NoSuchProviderException, SignatureException {
		try {
			Signature signature = Signature.getInstance(signingAlgorithm, provider);
			signature.initSign(privateKey);
			signature.update(payload);
			return signature.sign();
			// IllegalArgumentException may be thrown if the key is too small for the
			// algorithm
		} catch (NoSuchAlgorithmException | InvalidKeyException | SignatureException | IllegalArgumentException e) {
			throw new SignatureException("Could not sign payload with algorithm " + signingAlgorithm, e);
		}
	}
}
