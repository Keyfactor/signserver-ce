/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.keys;

import java.io.Serializable;

/**
 * POJO representing a key attestation.
 */
public class KeyAttestation implements Serializable {

    private static final long serialVersionUID = 7480879196353793436L;

    /**
     * Byte array holding the key attestation
     */
    private byte[] data;

    /**
     * String telling the receiver of the KeyAttestation object what HSM vendor created the key attestation.
     * Having this field should help the receiver know how to parse the data.
     */
    private String vendor;

    public KeyAttestation(byte[] data, String vendor) {
        this.data = data;
        this.vendor = vendor;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data) {
        this.data = data;
    }

    public String getVendor() {
        return vendor;
    }

    public void setVendor(String vendor) {
        this.vendor = vendor;
    }
}
