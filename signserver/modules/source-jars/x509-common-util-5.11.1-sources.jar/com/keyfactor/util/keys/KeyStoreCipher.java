/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.keys;

import java.util.HashMap;
import java.util.Map;

/**
 * Enum containing supported PKCS#12 ciphers defined in BouncyCastle
 */

public enum KeyStoreCipher {
	PKCS12_3DES_3DES("PKCS12-3DES-3DES"), 
	PKCS12_AES256_AES128("PKCS12-AES256-AES128");
	
	private static final Map<String, KeyStoreCipher> lookupMap = new HashMap<>();
	
	static {
		for(KeyStoreCipher keyStoreCipher : KeyStoreCipher.values()) {
			lookupMap.put(keyStoreCipher.getLabel(), keyStoreCipher);
		}
	}
	
	private final String label;

	
	private KeyStoreCipher(final String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}
	
	/**
	 * Returns an enum based on string label
	 * 
	 * @param label a label defined in this enum
	 * @return the appropriate enum, or null if not found
	 */
	public static KeyStoreCipher fromLabel(final String label) {
		return lookupMap.get(label);
	}
}


