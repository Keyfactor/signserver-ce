/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.keys;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigInteger;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.SignatureException;
import java.security.UnrecoverableEntryException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.ECGenParameterSpec;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import javax.crypto.KeyGenerator;

import com.keyfactor.util.CertTools;
import com.keyfactor.util.CryptoProviderTools;
import com.keyfactor.util.crypto.algorithm.AlgorithmConstants;
import com.keyfactor.util.crypto.algorithm.AlgorithmTools;
import com.keyfactor.util.keys.token.KeyGenParams;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.Strings;
import org.apache.log4j.Logger;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.crypto.ec.CustomNamedCurves;
import org.bouncycastle.jcajce.PKCS12StoreParameter;
import org.bouncycastle.jcajce.provider.asymmetric.util.ECUtil;
import org.bouncycastle.jcajce.spec.EdDSAParameterSpec;
import org.bouncycastle.jcajce.spec.MLDSAParameterSpec;
import org.bouncycastle.jcajce.spec.SLHDSAParameterSpec;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.operator.ContentVerifierProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.pkcs.PKCSException;
import org.bouncycastle.pqc.jcajce.spec.FalconParameterSpec;
import org.bouncycastle.pqc.jcajce.spec.LMSKeyGenParameterSpec;

/**
 *
 */
public class KeyStoreTools {
    private static final Logger log = Logger.getLogger(KeyStoreTools.class);

    protected final CachingKeyStoreWrapper keyStore;
    private final String providerName;

    public KeyStoreTools(CachingKeyStoreWrapper keyStore, String providerName){
        this.keyStore = keyStore;
        this.providerName = providerName;
    }

    /**
     * @return the name of the Provider used by this container
     */
    public String getProviderName() {
        return this.providerName;
    }

    /**
     * @return a reference to the KeyStore for this container
     */
    public CachingKeyStoreWrapper getKeyStore() {
        return this.keyStore;
    }

    public void setKeyEntry(String alias, Key key, Certificate[] chain) throws KeyStoreException {
        // Removal of old key is only needed for sun-p11 with none ASCII chars in the alias.
        // But it makes no harm to always do it and it should be fast.
        // If not done the entry will not be stored correctly in the p11 KeyStore.
        getKeyStore().deleteEntry(alias);
        getKeyStore().setKeyEntry(alias, key, null, chain);
    }

    private void deleteAlias(String alias) throws KeyStoreException {
        getKeyStore().deleteEntry(alias);
    }
    /** Deletes an entry in the keystore
     *
     * @param alias is a reference to the entry in the KeyStore that should be deleted, if alias is null, all entries are deleted.
     * @throws KeyStoreException  key store exception.
     */
    public void deleteEntry(final String alias) throws KeyStoreException {
        if ( alias!=null ) {
            deleteAlias(alias);
            return;
        }
        final Enumeration<String> e = getKeyStore().aliases();
        while( e.hasMoreElements() ) {
            final String str = e.nextElement();
            deleteAlias( str );
        }
    }
    /**
     * Rename the alias of an entry.
     * This has just been tested on pkcs#11 keystores. On other keystore it might
     * be that you will get two aliases for the same key (copy). But on p11
     * we know that the oldAlias is not existing after the method is called.
     *
     * @param oldAlias is the current name
     * @param newAlias is the new name
     */
    public void renameEntry( String oldAlias, String newAlias ) {
        // only one key with same public part (certificate) is existing on a p11 token. this has been tested.
        try {
            getKeyStore().setEntry(newAlias, getKeyStore().getEntry(oldAlias, null), null);
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableEntryException e) {
            throw new KeyUtilRuntimeException("Renaming entry failed.", e);
        }
    }

    private X509Certificate getSelfCertificate(String myName, long validity, List<String> sigAlgs, KeyPair keyPair) throws InvalidKeyException,
            CertificateException {
        final long currentTime = new Date().getTime();
        final Date firstDate = new Date(currentTime - 24 * 60 * 60 * 1000);
        final Date lastDate = new Date(currentTime + validity * 1000);
        final X500Name issuer = new X500Name(myName);
        final BigInteger serno = BigInteger.valueOf(firstDate.getTime());
        final PublicKey publicKey = keyPair.getPublic();
        if (publicKey == null) {
            throw new InvalidKeyException("Public key is null");
        }

        try {
            final X509v3CertificateBuilder cb = new JcaX509v3CertificateBuilder(issuer, serno, firstDate, lastDate, issuer, publicKey);
            final KeyPair signingKeys;
            if(publicKey.getAlgorithm().startsWith("ML-KEM-")) {
            	//If the keypair is ML-KEM there is no way we can produce a self signed certificate. Since this is a dummy cert, we'll just go ahead
                //and generate a new keypair for the signature.
                try {
					signingKeys = KeyTools.genKeys("secp256r1", AlgorithmConstants.KEYALGORITHM_ECDSA);
				} catch (InvalidAlgorithmParameterException e) {
					throw new IllegalStateException("Was not able to produce a secp256r1 EC key.");
				}
                sigAlgs = Arrays.asList(AlgorithmConstants.SIGALG_SHA256_WITH_ECDSA);
            } else {
            	signingKeys = keyPair;
            }

            String provider = this.providerName;
            if (BouncyCastleProvider.PROVIDER_NAME.equals(this.providerName)) {
                provider = CryptoProviderTools.getProviderNameFromAlg(sigAlgs.get(0));
            }
            final X509CertificateHolder cert = AnyAvailableAlgorithmSigner.INSTANCE.signX509Certificate(provider, sigAlgs, cb, signingKeys.getPrivate());
            if ( cert==null ) {
                throw new CertificateException("Self signing of certificate failed.");
            }
            return CertTools.getCertfromByteArray(cert.getEncoded(), X509Certificate.class);
        } catch (SignatureException e) {
            log.error("Error creating content signer: ", e);
            throw new CertificateException(e);
        } catch (IOException e) {
            throw new CertificateException("Could not read certificate", e);
        }
    }

    private void generateEC(final String ecNamedCurveBc, final String keyAlias) throws InvalidAlgorithmParameterException {
        if (log.isTraceEnabled()) {
            log.trace(">generate EC: curve name "+ecNamedCurveBc+", keyEntryName "+keyAlias);
        }
        if (Strings.CS.contains(Security.getProvider(this.providerName).getClass().getName(), "iaik")) {
            throw new InvalidAlgorithmParameterException("IAIK ECC key generation not implemented.");
        }
        final AlgorithmParameterSpec keyParams;

        // Convert it to the OID if possible since the human friendly name might differ in the provider
        if (ECUtil.getNamedCurveOid(ecNamedCurveBc) != null) {
            final String oidOrName = AlgorithmTools.getEcKeySpecOidFromBcName(ecNamedCurveBc);
            if (log.isDebugEnabled()) {
                log.debug("keySpecification '" + ecNamedCurveBc + "' transformed into OID " + oidOrName);
            }
            keyParams = new ECGenParameterSpec(oidOrName);
        } else {
            if (log.isDebugEnabled()) {
                log.debug("Curve did not have an OID in BC, trying to pick up Parameter spec: " + ecNamedCurveBc);
            }
            // This may be a new curve without OID, like curve25519 and we have to do something a bit different
            X9ECParameters ecP = CustomNamedCurves.getByName(ecNamedCurveBc);
            if (ecP == null) {
                throw new InvalidAlgorithmParameterException("Can not generate EC curve, no OID and no ECParameters found: " + ecNamedCurveBc);
            }
            keyParams = new org.bouncycastle.jce.spec.ECParameterSpec(ecP.getCurve(), ecP.getG(), ecP.getN(), ecP.getH(), ecP.getSeed());
        }


        generateKeyPair(keyParams, keyAlias, AlgorithmConstants.KEYALGORITHM_EC, AlgorithmTools.SIG_ALGS_ECDSA);

        if (log.isTraceEnabled()) {
            log.trace("<generate: curve name "+ecNamedCurveBc+", keyEntryName "+keyAlias);
        }
    }

    private void generateRSA(final int keySize, final String keyEntryName) throws InvalidAlgorithmParameterException {
        if (log.isTraceEnabled()) {
            log.trace(">generate: keySize " + keySize + ", keyEntryName " + keyEntryName);
        }
        generateKeyPair(
                new SizeAlgorithmParameterSpec(keySize), keyEntryName,
                AlgorithmConstants.KEYALGORITHM_RSA,
                AlgorithmTools.SIG_ALGS_RSA_NOSHA1);
        if (log.isTraceEnabled()) {
            log.trace("<generate: keySize " + keySize + ", keyEntryName " + keyEntryName);
        }
    }

    private void generateEdDSAOrPQC(final String keySpec, final String keyAlias) throws InvalidAlgorithmParameterException {
        if (log.isTraceEnabled()) {
            log.trace(">generate: keySpec " + keySpec+ ", keyEntryName " + keyAlias);
        }
        // Generate the Keypair
        final List<String> sigAlgs;
        AlgorithmParameterSpec keyParams = null;
        switch (keySpec) {
        case AlgorithmConstants.KEYALGORITHM_ED25519:
            sigAlgs = AlgorithmTools.SIG_ALGS_ED25519;
            break;
        case AlgorithmConstants.KEYALGORITHM_ED448:
            sigAlgs = AlgorithmTools.SIG_ALGS_ED448;
            break;
        case AlgorithmConstants.KEYALGORITHM_FALCON512:
            sigAlgs = AlgorithmTools.SIG_ALGS_FALCON512;
            break;
        case AlgorithmConstants.KEYALGORITHM_FALCON1024:
            sigAlgs = AlgorithmTools.SIG_ALGS_FALCON1024;
            break;
        case AlgorithmConstants.KEYALGORITHM_MLDSA44:
            sigAlgs = AlgorithmTools.SIG_ALGS_MLDSA44;
            break;
        case AlgorithmConstants.KEYALGORITHM_MLDSA65:
            sigAlgs = AlgorithmTools.SIG_ALGS_MLDSA65;
            break;
        case AlgorithmConstants.KEYALGORITHM_MLDSA87:
            sigAlgs = AlgorithmTools.SIG_ALGS_MLDSA87;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_128S:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_128S;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128S:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_128S;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_128F:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_128F;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128F:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_128F;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_192S:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_192S;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192S:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_192S;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_192F:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_192F;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192F:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_192F;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_256S:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_256S;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256S:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_256S;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_256F:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_256F;
            break;
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256F:
            sigAlgs = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_256F;
            break;
        case AlgorithmConstants.SIGALG_MLDSA44_RSA2048_PSS_SHA256:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA44_RSA2048_PSS_SHA256;
            break;
        case AlgorithmConstants.SIGALG_MLDSA44_RSA2048_PKCS15_SHA256:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA44_RSA2048_PKCS15_SHA256;
            break;
        case AlgorithmConstants.SIGALG_MLDSA44_ECDSA_P256_SHA256:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA44_ECDSA_P256_SHA256;
            break;
        case AlgorithmConstants.SIGALG_MLDSA44_Ed25519_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA44_Ed25519_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA65_RSA3072_PSS_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA65_RSA3072_PSS_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA65_RSA4096_PSS_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA65_RSA4096_PSS_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA65_RSA3072_PKCS15_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA65_RSA3072_PKCS15_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA65_RSA4096_PKCS15_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA65_RSA4096_PKCS15_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA65_ECDSA_P256_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA65_ECDSA_P256_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA65_ECDSA_P384_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA65_ECDSA_P384_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA65_Ed25519_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA65_Ed25519_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA65_ECDSA_brainpoolP256r1_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA65_ECDSA_brainpoolP256r1_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA87_RSA3072_PSS_SHA512:
            sigAlgs = AlgorithmTools.SIG_MLDSA87_RSA3072_PSS_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA87_RSA4096_PSS_SHA512:
            sigAlgs = AlgorithmTools.SIG_MLDSA87_RSA4096_PSS_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA87_ECDSA_P384_SHA512:
            sigAlgs = AlgorithmTools.SIG_MLDSA87_ECDSA_P384_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA87_ECDSA_P521_SHA512:
            sigAlgs = AlgorithmTools.SIG_MLDSA87_ECDSA_P521_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA87_ECDSA_brainpoolP384r1_SHA512:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA87_ECDSA_brainpoolP384r1_SHA512;
            break;
        case AlgorithmConstants.SIGALG_MLDSA87_Ed448_SHAKE256:
            sigAlgs = AlgorithmTools.SIGALG_MLDSA87_Ed448_SHAKE256;
            break;
        case AlgorithmConstants.KEYALGORITHM_LMS:
            sigAlgs = AlgorithmTools.SIG_ALGS_LMS;
            // Hardcoded to a simple LMS test key. Larger LMS keys can take ages to generate, and we will only allow
            // LMS key generation for testing
            keyParams = LMSKeyGenParameterSpec.fromNames("lms-sha256-n32-h5", "sha256-n32-w8");
            break;
        case AlgorithmConstants.SIGALG_MLKEM512:
            sigAlgs = AlgorithmTools.SIG_ALGS_MLKEM512;
            break;
        case AlgorithmConstants.SIGALG_MLKEM768:
            sigAlgs = AlgorithmTools.SIG_ALGS_MLKEM768;
            break;
        case AlgorithmConstants.SIGALG_MLKEM1024:
            sigAlgs = AlgorithmTools.SIG_ALGS_MLKEM1024;
            break;
        default:
            throw new InvalidAlgorithmParameterException("Only Ed25519, Ed448, FALCON-512, FALCON-1024, ML-DSA-44,"
                    + " ML-DSA-65, ML-DSA-87, SLH-DSA-SHA2-128S, SLH-DSA-SHAKE-128S, SLH-DSA-SHA2-128F, SLH-DSA-SHAKE-128F,"
                    + " SLH-DSA-SHA2-192S, SLH-DSA-SHAKE-192S, SLH-DSA-SHA2-192F, SLH-DSA-SHAKE-192F,"
                    + " SLH-DSA-SHA2-256S, SLH-DSA-SHAKE-256S, SLH-DSA-SHA2-256F, SLH-DSA-SHAKE-256F,"
                    + " MLDSA44-RSA2048-PSS-SHA256, MLDSA44-Ed25519-SHA512,"
                    + " MLDSA44-ECDSA-P256-SHA256, MLDSA65-RSA3072-PSS-SHA512,"
                    + " MLDSA65-RSA4096-PSS-SHA512, MLDSA65-ECDSA-P256-SHA512,"
                    + " MLDSA65-ECDSA-P384-SHA512, MLDSA65-ECDSA-brainpoolP256r1-SHA512,"
                    + " MLDSA65-Ed25519-SHA512, MLDSA87-ECDSA-brainpoolP384r1-SHA512,"
                    + " MLDSA87-Ed448-SHAKE256, MLDSA87-RSA3072-PSS-SHA512, MLDSA87-RSA4096-PSS-SHA512,"
                    + " MLDSA87-ECDSA-P384-SHA512, MLDSA87-ECDSA-P521-SHA512,"
                    + " ML-KEM-512, ML-KEM-768, ML-KEM-1024"
                    + " is allowed for EdDSA/PQC key generation: " + keySpec);
        }
        generateKeyPair(keyParams, keyAlias, keySpec, sigAlgs);
        if (log.isTraceEnabled()) {
            log.trace("<generate: keySpec " + keySpec + ", keyEntryName " + keyAlias);
        }
    }

    /** Generates asymmetric keys in the Keystore token.
     *
     * @param keySpec all decimal digits RSA key length, otherwise name of ECC curve
     * @param keyEntryName key entry name.
     */
    public void generateKeyPair(final String keySpec, final String keyEntryName) throws
            InvalidAlgorithmParameterException {
        if (keySpec.toUpperCase().startsWith("ED") || keySpec.toUpperCase().startsWith("FALCON")
                || keySpec.toUpperCase().startsWith("ML") || keySpec.toUpperCase().startsWith("LMS")
                || keySpec.toUpperCase().startsWith("SLH") || keySpec.toUpperCase().startsWith("MLDSA")) {
            generateEdDSAOrPQC(keySpec, keyEntryName);
        } else {
            final String formatCheckedKeySpec = KeyGenParams.getKeySpecificationNumeric(keySpec);
            try {
                generateRSA(Integer.parseInt(formatCheckedKeySpec.trim()), keyEntryName);
            } catch (NumberFormatException e) {
                generateEC(keySpec, keyEntryName);
            }
        }
    }

    /** Generates symmetric keys in the Keystore token.
     *
     * @param algorithm symmetric algorithm specified in http://download.oracle.com/javase/1.5.0/docs/api/index.html, suggest AES, DESede or DES
     * @param keysize keysize of symmetric key, suggest 128 or 256 for AES, 64 for 168 for DESede and 64 for DES
     * @param keyEntryName the alias the key will get in the keystore
     * @throws NoSuchProviderException provider exception.
     * @throws NoSuchAlgorithmException algorithm exception.
     * @throws KeyStoreException  key store exception.
     */
    public void generateKey(final String algorithm, final int keysize,
                            final String keyEntryName) throws NoSuchAlgorithmException, NoSuchProviderException, KeyStoreException {
        final KeyGenerator generator = KeyGenerator.getInstance(algorithm, this.providerName);
        generator.init(keysize);
        final Key key = generator.generateKey();
        setKeyEntry(keyEntryName, key, null);
    }

    /** Generates keys in the Keystore token.
     * @param keyParams AlgorithmParameterSpec for the KeyPairGenerator. Can be anything like RSAKeyGenParameterSpec, ECParameterSpec or ECGenParameterSpec.
     * @param keyAlias key alias.
     * @throws InvalidAlgorithmParameterException invalid algorithm parameter exception.
     */
    public void generateKeyPair(final AlgorithmParameterSpec keyParams, final String keyAlias) throws InvalidAlgorithmParameterException {
        if (log.isTraceEnabled()) {
            log.trace(">generate from AlgorithmParameterSpec: "+keyParams.getClass().getName());
        }
        // Generate the KeyPair
        final String keyAlgorithm;
        final List<String> certSignAlgorithms;
        final String specName = keyParams.getClass().getName();
        if (specName.equals(EdDSAParameterSpec.class.getName())) {
            EdDSAParameterSpec edSpec = (EdDSAParameterSpec) keyParams;
            keyAlgorithm = edSpec.getCurveName();
            certSignAlgorithms = Collections.singletonList(edSpec.getCurveName());
        } else if (specName.contains(AlgorithmConstants.KEYALGORITHM_RSA)) {
            keyAlgorithm = AlgorithmConstants.KEYALGORITHM_RSA;
            certSignAlgorithms = AlgorithmTools.SIG_ALGS_RSA_NOSHA1;
        } else if (specName.equals(FalconParameterSpec.class.getName())) {
            if (FalconParameterSpec.falcon_512.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_FALCON512;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_FALCON512;
            } else if (FalconParameterSpec.falcon_1024.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_FALCON1024;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_FALCON1024;
            } else {
                throw new InvalidAlgorithmParameterException("Invalid Falcon keyspec: " + keyParams);
            }
        } else if (specName.equals(MLDSAParameterSpec.class.getName())) {
            if (MLDSAParameterSpec.ml_dsa_44.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_MLDSA44;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_MLDSA44;
            } else if (MLDSAParameterSpec.ml_dsa_65.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_MLDSA65;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_MLDSA65;
            } else if (MLDSAParameterSpec.ml_dsa_87.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_MLDSA87;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_MLDSA87;
            } else {
                throw new InvalidAlgorithmParameterException("Invalid ML-DSA keyspec: " + keyParams);
            }
        } else if (specName.equals(SLHDSAParameterSpec.class.getName())) {
            if (SLHDSAParameterSpec.slh_dsa_sha2_128s.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128S;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_128S;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_128s.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128S;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_128S;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_128f.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128F;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_128F;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_128f.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128F;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_128F;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_192s.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192S;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_192S;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_192s.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192S;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_192S;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_192f.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192F;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_192F;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_192f.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192F;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_192F;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_256s.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256S;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_256S;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_256s.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256S;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_256S;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_256f.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256F;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHA2_256F;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_256f.equals(keyParams)) {
                keyAlgorithm = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256F;
                certSignAlgorithms = AlgorithmTools.SIG_ALGS_SLHDSA_SHAKE_256F;
            } else {
                throw new InvalidAlgorithmParameterException("Invalid SLH-DSA keyspec: " + keyParams);
            }
        } else {
            keyAlgorithm = AlgorithmConstants.KEYALGORITHM_EC;
            certSignAlgorithms = AlgorithmTools.SIG_ALGS_ECDSA;
        }
        generateKeyPair(keyParams, keyAlias, keyAlgorithm, certSignAlgorithms);
    }

    private static class SizeAlgorithmParameterSpec implements AlgorithmParameterSpec {
        final int keySize;
        public SizeAlgorithmParameterSpec(final int keySize) {
            this.keySize = keySize;
        }
    }

    private void generateKeyPair(final AlgorithmParameterSpec keyParams, final String keyAlias, final String keyAlgorithm,
            final List<String> certSignAlgorithms) throws InvalidAlgorithmParameterException {
        final KeyPairGenerator kpg;
        try {
            String provider = this.providerName;
            if (BouncyCastleProvider.PROVIDER_NAME.equals(this.providerName)) {
                provider = CryptoProviderTools.getProviderNameFromAlg(keyAlgorithm);
            }
            kpg = KeyPairGenerator.getInstance(keyAlgorithm, provider);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Algorithm " + keyAlgorithm + " was not recognized.", e);
        } catch (NoSuchProviderException e) {
            throw new IllegalStateException(this.providerName+ " was not found as a provider.", e);
        }

        try {
            if (keyParams instanceof SizeAlgorithmParameterSpec) {
                kpg.initialize(((SizeAlgorithmParameterSpec) keyParams).keySize);
            } else if (keyParams != null || keyAlgorithm.startsWith("EC")) {
                // Null here means "implicitlyCA", which is allowed only for EC keys
                kpg.initialize(keyParams);
            }
        } catch (InvalidAlgorithmParameterException e) {
            log.debug("Algorithm parameters not supported: " + e.getMessage());
            throw e;
        }

        // We will make a loop to retry key generation here. Using the IAIK provider it seems to give
        // CKR_OBJECT_HANDLE_INVALID about every second time we try to store keys
        // But if we try again it succeeds
        int bar = 0;
        while (bar < 3) {
            try {
                log.debug("generating...");
                final KeyPair keyPair = kpg.generateKeyPair();
                final int randomInt = ThreadLocalRandom.current().nextInt(1000000, 10000000);
                final X509Certificate selfSignedCert = getSelfCertificate("CN=Dummy certificate created by a CESeCore application " + randomInt, (long) 30 * 24 * 60 * 60 * 365, certSignAlgorithms, keyPair);
                final X509Certificate chain[] = new X509Certificate[]{selfSignedCert};
                if (log.isDebugEnabled()) {
                    log.debug("Creating certificate with entry " + keyAlias + '.');
                }
                setKeyEntry(keyAlias, keyPair.getPrivate(), chain);
                break; // success no need to try more
            } catch (KeyStoreException e) {
                if ( bar<3 ) {
                    log.info("Failed to generate or store new key, will try 3 times. This was try: " + bar, e);
                } else {
                    throw new KeyCreationException("Signing failed.", e);
                }
            } catch(CertificateException e) {
                throw new KeyCreationException("Can't create keystore because dummy certificate chain creation failed.",e);
            } catch (InvalidKeyException e) {
               throw new KeyCreationException("Dummy certificate chain was created with an invalid key" , e);
            }
            bar++;
        }
        if (log.isTraceEnabled()) {
            log.trace("<generate from AlgorithmParameterSpec: "+(keyParams!=null ? keyParams.getClass().getName() : "null"));
        }
    }

    /** Generates a certificate request (CSR) in PKCS#10 format and writes to file
     * @param alias for the key to be used
     * @param sDN the DN to be used. If null the 'CN=alias' will be used
     * @param explicitEccParameters false should be default and will use NamedCurve encoding of ECC public keys (IETF recommendation), use true to include all parameters explicitly (ICAO ePassport requirement).
     */
    public void generateCertReq(String alias, String sDN, boolean explicitEccParameters) {
        try {
            final PublicKey publicKey = getCertificate(alias).getPublicKey();
            if (log.isDebugEnabled()) {
                log.debug("alias: " + alias + " SHA1 of public key: " + CertTools.getFingerprintAsString(publicKey.getEncoded()));
            }
            // Candidate algorithms. The first working one will be selected.
            final List<String> sigAlg = AlgorithmTools.getSignatureAlgorithms(publicKey);
			final PKCS10CertificationRequest certReq = AnyAvailableAlgorithmSigner.INSTANCE.signPkcs10(
					this.providerName, sigAlg, publicKey, getPrivateKey(alias), alias, sDN, explicitEccParameters);
            final ContentVerifierProvider verifier = CertTools.genContentVerifierProvider(publicKey);
            if ( !certReq.isSignatureValid(verifier) ) {
                final String msg = "Certificate request is not verifying.";
                throw new KeyUtilRuntimeException(msg);
            }
            final String filename = alias+".pem";

            try( final OutputStream os = new FileOutputStream(filename) ) {
                os.write( CertTools.getPEMFromCertificateRequest(certReq.getEncoded()) );
            }
            log.info("Wrote csr to file: "+filename);
        } catch (KeyStoreException | SignatureException | NoSuchAlgorithmException | UnrecoverableEntryException | OperatorCreationException | PKCSException | IOException  e) {
            throw new KeyUtilRuntimeException("Failed to generate a certificate request.", e);
        }
    }

    /**
     * Install certificate chain to key in keystore.
     * @param fileName name of the file with chain. Starting with the certificate of the key. Ending with the root certificate.
     */
    public void installCertificate(final String fileName) {
        try( final InputStream is = new FileInputStream(fileName) ) {
            final X509Certificate[] chain;
            chain = CertTools.getCertsFromPEM(is, X509Certificate.class).toArray(new X509Certificate[0]);
            final PublicKey importPublicKey = chain[0].getPublicKey();
            final String importKeyHash = CertTools.getFingerprintAsString(importPublicKey.getEncoded());
            final Enumeration<String> eAlias = getKeyStore().aliases();
            boolean notFound = true;
            while ( eAlias.hasMoreElements() && notFound ) {
                final String alias = eAlias.nextElement();
                final PublicKey hsmPublicKey = getCertificate(alias).getPublicKey();
                if (log.isDebugEnabled()) {
                    log.debug("alias: " + alias + " SHA1 of public hsm key: " + CertTools.getFingerprintAsString(hsmPublicKey.getEncoded())
                    + " SHA1 of first public key in chain: " + importKeyHash
                    +  (chain.length==1?"":("SHA1 of last public key in chain: " + CertTools.getFingerprintAsString(chain[chain.length-1].getPublicKey().getEncoded()))));
                }
                if ( hsmPublicKey.equals(importPublicKey) ) {
                    log.info("Found a matching public key for alias \"" + alias + "\".");
                    getKeyStore().setKeyEntry(alias, getPrivateKey(alias), null, chain);
                    notFound = false;
                }
            }
            if ( notFound ) {
                final String msg = "Key with public key hash " + importKeyHash + " not on token.";
                throw new KeyUtilRuntimeException(msg);
            }
        } catch (IOException | CertificateParsingException | KeyStoreException | UnrecoverableKeyException | NoSuchAlgorithmException e) {
            throw new KeyUtilRuntimeException("Failed to install cert chain into keystore.", e);
        }
    }

    /**
     * Install trusted root in trust store
     * @param fileName name of the trusted root.
     */
    public void installTrustedRoot(String fileName) {
        try( final InputStream is = new FileInputStream(fileName) ) {
            final List<Certificate> chain = CertTools.getCertsFromPEM(is, Certificate.class);
            if ( chain.size()<1 ) {
                throw new KeyUtilRuntimeException("No certificate in file");
            }
            // assume last cert in chain is root if more than 1
            getKeyStore().setCertificateEntry("trusted", chain.get(chain.size()-1));
        } catch (IOException | CertificateParsingException | KeyStoreException e) {
            throw new KeyUtilRuntimeException("Failing to install trusted certificate.", e);
        }
    }
    private PrivateKey getPrivateKey(String alias) throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException {
        final PrivateKey key = (PrivateKey)getKey(alias);
        if ( key==null ) {
            String msg = "Key alias '" + alias + "' not found in keystore.";
            log.info(msg);
        }
        return key;
    }
    private Key getKey(String alias) throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException {
        return getKeyStore().getKey(alias, null);
    }
    private X509Certificate getCertificate( String alias ) throws KeyStoreException {
        final X509Certificate cert = (X509Certificate)this.keyStore.getCertificate(alias);
        if ( cert==null ) {
            String msg = "Certificate alias '" + alias +"' not found in keystore.";
            log.info(msg);
        }
        return cert;
    }

    /**
     * Encodes the passed in keystore to the also passed in output stream, taking care of encoding variants. Currently ensuring that (BC) keystores
     * are encoded using definite length encoding
     *
     * @param ks the KeyStore object to store/encode into the outputstream, can be any type of backed keystore, i.e. PKCS12, JKS, BCFKS
     * @param os the OutputStream where the keystore will be written to
     * @param pwd the password used to protect the keystore, if the keystore class supports protection as PKCS12, JKS, BCFKS does
     * @throws KeyStoreException if the keystore is invalid
     * @throws NoSuchAlgorithmException if the keystore protection algorithm can not be found
     * @throws CertificateException if the certificate in the keystore is invalid
     * @throws IOException if writing to the OutputStream fails
     */
    public static void storeKeyStore(KeyStore ks, OutputStream os, char[] pwd) throws KeyStoreException, NoSuchAlgorithmException, CertificateException, IOException {
        // If password below is more than 7 chars, strong crypto is needed
        if (Strings.CS.startsWith(ks.getType(), "PKCS12") && BouncyCastleProvider.PROVIDER_NAME.equals(ks.getProvider().getName())) {
            // If it is a PKCS12 keystore, and BC provider, make sure we store is using definite length encoding
            PKCS12StoreParameter params = new PKCS12StoreParameter(os, pwd, true);
            ks.store(params);
        } else {
            ks.store(os, pwd);
        }
    }

    /**
     * Encodes a Keystore to a byte array.
     * @param keyStore the keystore.
     * @param password the password.
     * @return the keystore encoded as byte array, or an empty array (length 0) if there is an error encoding the keystore
     */
    public static byte[] getAsByteArray(final KeyStore keyStore, final String password) {
        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            KeyStoreTools.storeKeyStore(keyStore, outputStream, password.toCharArray());
            return outputStream.toByteArray();
        } catch (IOException | KeyStoreException | NoSuchAlgorithmException | CertificateException e) {
            log.warn(e); //should never happen if keyStore is valid object
        }
        return ArrayUtils.EMPTY_BYTE_ARRAY;
    }
}
