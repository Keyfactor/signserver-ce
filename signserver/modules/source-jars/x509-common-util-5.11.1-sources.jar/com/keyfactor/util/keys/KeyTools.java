/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.keys;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateParsingException;
import java.security.cert.X509Certificate;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.AlgorithmParameterSpec;
import java.security.spec.ECFieldFp;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.EllipticCurve;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.RSAKeyGenParameterSpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.interfaces.DHPrivateKey;
import javax.crypto.interfaces.DHPublicKey;

import com.keyfactor.util.Base64;
import com.keyfactor.util.CertTools;
import com.keyfactor.util.CryptoProviderTools;
import com.keyfactor.util.RandomHelper;
import com.keyfactor.util.certificate.DnComponents;
import com.keyfactor.util.crypto.algorithm.AlgorithmConstants;
import com.keyfactor.util.crypto.algorithm.AlgorithmTools;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.Strings;
import org.apache.log4j.Logger;
import org.bouncycastle.asn1.ASN1InputStream;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.DERBMPString;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DLSequence;
import org.bouncycastle.asn1.edec.EdECObjectIdentifiers;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.cert.X509CRLHolder;
import org.bouncycastle.cert.X509ExtensionUtils;
import org.bouncycastle.cert.bc.BcX509ExtensionUtils;
import org.bouncycastle.cms.CMSEnvelopedData;
import org.bouncycastle.cms.CMSEnvelopedDataGenerator;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSProcessableByteArray;
import org.bouncycastle.cms.RecipientInformation;
import org.bouncycastle.cms.RecipientInformationStore;
import org.bouncycastle.cms.jcajce.JceCMSContentEncryptorBuilder;
import org.bouncycastle.cms.jcajce.JceKeyTransEnvelopedRecipient;
import org.bouncycastle.cms.jcajce.JceKeyTransRecipientInfoGenerator;
import org.bouncycastle.crypto.ec.CustomNamedCurves;
import org.bouncycastle.crypto.util.PublicKeyFactory;
import org.bouncycastle.jcajce.CompositePublicKey;
import org.bouncycastle.jcajce.interfaces.EdDSAPrivateKey;
import org.bouncycastle.jcajce.interfaces.EdDSAPublicKey;
import org.bouncycastle.jcajce.interfaces.MLDSAPrivateKey;
import org.bouncycastle.jcajce.interfaces.MLDSAPublicKey;
import org.bouncycastle.jcajce.interfaces.MLKEMPrivateKey;
import org.bouncycastle.jcajce.interfaces.MLKEMPublicKey;
import org.bouncycastle.jcajce.interfaces.SLHDSAPrivateKey;
import org.bouncycastle.jcajce.interfaces.SLHDSAPublicKey;
import org.bouncycastle.jcajce.provider.asymmetric.ec.BCECPublicKey;
import org.bouncycastle.jcajce.provider.asymmetric.edec.BCEdDSAPrivateKey;
import org.bouncycastle.jcajce.provider.asymmetric.edec.BCEdDSAPublicKey;
import org.bouncycastle.jcajce.provider.asymmetric.util.ECUtil;
import org.bouncycastle.jcajce.spec.EdDSAParameterSpec;
import org.bouncycastle.jcajce.spec.MLDSAParameterSpec;
import org.bouncycastle.jcajce.spec.MLKEMParameterSpec;
import org.bouncycastle.jcajce.spec.SLHDSAParameterSpec;
import org.bouncycastle.jce.interfaces.PKCS12BagAttributeCarrier;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.jce.provider.JCEECPublicKey;
import org.bouncycastle.jce.spec.ECNamedCurveSpec;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.openssl.PEMKeyPair;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;
import org.bouncycastle.openssl.jcajce.JcaPEMWriter;
import org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequest;
import org.bouncycastle.pqc.jcajce.interfaces.FalconPrivateKey;
import org.bouncycastle.pqc.jcajce.interfaces.FalconPublicKey;
import org.bouncycastle.pqc.jcajce.spec.FalconParameterSpec;
import org.bouncycastle.util.encoders.DecoderException;
import org.bouncycastle.util.encoders.Hex;

/**
 * Tools to handle common key and keystore operations.
 */
public final class KeyTools {
    private static final Logger log = Logger.getLogger(KeyTools.class);

    private static final byte[] BAG_ATTRIBUTES = "Bag Attributes\n".getBytes();
    private static final byte[] FRIENDLY_NAME = "    friendlyName: ".getBytes();
    private static final byte[] SUBJECT_ATTRIBUTE = "subject=/".getBytes();
    private static final byte[] ISSUER_ATTRIBUTE = "issuer=/".getBytes();
    private static final byte[] BEGIN_CERTIFICATE = "-----BEGIN CERTIFICATE-----".getBytes();
    private static final byte[] END_CERTIFICATE = "-----END CERTIFICATE-----".getBytes();
    private static final byte[] BEGIN_PRIVATE_KEY = "-----BEGIN PRIVATE KEY-----".getBytes();
    private static final byte[] END_PRIVATE_KEY = "-----END PRIVATE KEY-----".getBytes();
    private static final byte[] NL = "\n".getBytes();

    public static final String CA_CERT_CHAIN_ALIAS = "cacert";
    public static final String ERROR_MESSAGE_SIGNING_FAILED = "Result from signing is null.";
    public static final String ERROR_MESSAGE_VERIFICATION_FAILED = "Signature was not correctly verified.";

    /**
     * Prevent from creating new KeyTools object
     */
    private KeyTools() {
        // should never be called
    }

    /**
     * Generates a keypair
     *
     * @param keySpec
     *            string specification of keys to generate, typical value is 2048 for RSA keys,
     *            secp256r1 for ECDSA keys, Ed25519 or Ed448 for EdDSA or null if algspec is to be used.
     * @param algSpec
     *            AlgorithmParameterSpec of keys to generate, typically an EXParameterSpec for EC keys, or null if keySpec is to be used. See {@link KeyTools#getKeyGenSpec(PublicKey)}
     * @param keyAlg
     *            algorithm of keys to generate, typical value is RSA or ECDSA, see AlgorithmConstants.KEYALGORITHM_XX, if value is Ed25519, Ed448, FALCON-512, FALCON-1024, ML-DSA-44, ML-DSA-65, ML-DSA-87, SLH-DSA variants, keySpec or algSpec is not needed
     *
     * @see com.keyfactor.util.crypto.algorithm.AlgorithmConstants
     * @see org.bouncycastle.asn1.x9.X962NamedCurves
     * @see org.bouncycastle.asn1.nist.NISTNamedCurves
     * @see org.bouncycastle.asn1.sec.SECNamedCurves
     * @see KeyTools#getKeyGenSpec(PublicKey)
     *
     * @return KeyPair the generated keypair
     * @throws InvalidAlgorithmParameterException  if the given parameters are inappropriate for this key pair generator.
     * @see com.keyfactor.util.crypto.algorithm.AlgorithmConstants#KEYALGORITHM_RSA
     */
    public static KeyPair genKeys(final String keySpec, final AlgorithmParameterSpec algSpec, final String keyAlg) throws InvalidAlgorithmParameterException {
        if (log.isTraceEnabled()) {
            log.trace(">genKeys(" + keySpec + ", " + keyAlg + ")");
        }

        KeyPairGenerator keygen;
        try {
            // A small note on RSA keys.
            // RSA keys are encoded as a SubjectPublicKeyInfo in X.509 certificates (public key) and PKCS#8 private key blobs (private key)
            // In a SubjectPublicKeyInfo encoded is as an AlgorithmIdentifier, which has an OID and parameters.
            // See section 1.2 in https://tools.ietf.org/html/rfc4055
            // and section 2.1 in https://tools.ietf.org/html/rfc4056
            // The "normal" OID used is rsaEncryption, but it can also be id-RSASSA-PSS "When the RSA private key owner wishes to limit the use of the public
            // key exclusively to RSASSA-PSS" (quote from RFC4055).
            // How it's encoded can be controlled during key generation. We use "RSA" for RSA keys, which means rsaEncryption.
            // Albeit we don't see any need right now (May 2020), it is possible to use id-RSASSA-PSS if on uses RSASSA-PSS instead of RSA when creating the
            // KeyPairGeneratos, i.e. KeyPairGenerator.getInstance("RSASSA-PSS", BouncyCastleProvider.PROVIDER_NAME)
            keygen = KeyPairGenerator.getInstance(keyAlg, CryptoProviderTools.getProviderNameFromAlg(keyAlg));
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Algorithm " + keyAlg + " was not recognized.", e);
        } catch (NoSuchProviderException e) {
            throw new IllegalStateException("BouncyCastle was not found as a provider.", e);
        }
        if (Strings.CS.equals(keyAlg, AlgorithmConstants.KEYALGORITHM_ECDSA) || Strings.CS.equals(keyAlg, AlgorithmConstants.KEYALGORITHM_EC)) {
            if ((keySpec != null)) {
                log.debug("Generating named curve ECDSA key pair: " + keySpec);
                // Check if we have an OID for this named curve
                if (ECUtil.getNamedCurveOid(keySpec) != null) {
                    ECGenParameterSpec bcSpec = new ECGenParameterSpec(keySpec);
                    keygen.initialize(bcSpec, RandomHelper.getInstance("BCSP800HYBRID"));
                } else {
                    if (log.isDebugEnabled()) {
                        log.debug("Curve did not have an OID in BC, trying to pick up Parameter spec: " + keySpec);
                    }
                    // This may be a new curve without OID, like curve25519 and we have to do something a bit different
                    X9ECParameters ecP = CustomNamedCurves.getByName(keySpec);
                    if (ecP == null) {
                        throw new InvalidAlgorithmParameterException("Can not generate EC curve, no OID and no ECParameters found: "+keySpec);
                    }
                    org.bouncycastle.jce.spec.ECParameterSpec ecSpec = new org.bouncycastle.jce.spec.ECParameterSpec(
                            ecP.getCurve(), ecP.getG(), ecP.getN(), ecP.getH(), ecP.getSeed());
                    keygen.initialize(ecSpec, RandomHelper.getInstance("BCSP800HYBRID"));
                }
                // The old code should work in BC v1.50b6 and later, but in versions prior to that the below produces a key with explicit parameter encoding instead of named curves.
                // There is a test for this in KeyToolsTest.testGenKeysECDSAx9
                //                ecSpec = ECNamedCurveTable.getParameterSpec(keySpec);
                //                if (ecSpec == null) {
                //                    throw new InvalidAlgorithmParameterException("keySpec " + keySpec + " is invalid for ECDSA.");
                //                }
                //                keygen.initialize(ecSpec, new SecureRandom());
            } else if (algSpec != null) {
                log.debug("Generating ECDSA key pair from AlgorithmParameterSpec: " + algSpec);
                keygen.initialize(algSpec, RandomHelper.getInstance("BCSP800HYBRID"));
            } else {
                throw new InvalidAlgorithmParameterException("No keySpec or algSpec specified");
            }
        } else if (StringUtils.isNumeric(keySpec) && Strings.CI.startsWith(keyAlg, "FALCON")) {
            // Falcon has security levels, such as Falcon-512
            final AlgorithmParameterSpec spec;
            if ("512".equals(keySpec)) {
                spec = FalconParameterSpec.falcon_512;
            } else if ("1024".equals(keySpec)) {
                spec = FalconParameterSpec.falcon_1024;
            } else {
                throw new InvalidAlgorithmParameterException(keySpec + " is not a valid FALCON algorithm parameter");
            }
            keygen.initialize(spec);
        } else if (StringUtils.isNumeric(keySpec) && Strings.CI.startsWith(keyAlg, "ML-KEM")) {
            // ML-KEM has security levels, such as ML-KEM--512
            final AlgorithmParameterSpec spec;
            if ("512".equals(keySpec)) {
                spec = MLKEMParameterSpec.ml_kem_512;
            } else if ("768".equals(keySpec)) {
                spec = MLKEMParameterSpec.ml_kem_768;
            } else if ("1024".equals(keySpec)) {
                spec = MLKEMParameterSpec.ml_kem_1024;
            } else {
                throw new InvalidAlgorithmParameterException(keySpec + " is not a valid ML-KEM algorithm parameter");
            }
            keygen.initialize(spec);
        } else if (Strings.CI.startsWith(keyAlg, "ML-DSA")) {
            // ML-DSA has security levels, 1, 2, 3
            final AlgorithmParameterSpec spec;
            if ("ML-DSA-44".equalsIgnoreCase(keyAlg)) {
                spec = MLDSAParameterSpec.ml_dsa_44;
            } else if ("ML-DSA-65".equals(keyAlg)) {
                spec = MLDSAParameterSpec.ml_dsa_65;
            } else if ("ML-DSA-87".equals(keyAlg)) {
                spec = MLDSAParameterSpec.ml_dsa_87;
            } else {
                throw new InvalidAlgorithmParameterException(keySpec + " is not a valid ML-DSA key algorithm specification");
            }
            keygen.initialize(spec);
        }  else if (StringUtils.isNumeric(keySpec) && !Strings.CS.startsWith(keyAlg, "Ed")) {
            // RSA key where keyspec is simply the key length
            // If it is Ed, be nice and ignore the keysize
            final int keysize = Integer.parseInt(keySpec);
            keygen.initialize(keysize);
        }  else if (Strings.CI.startsWith(keyAlg, "SLH-DSA")) {
            // SLH-DSA has SHA2 or SHAKE hashes, security levels, 1, 3, 5 and speed either 'f' fast or 's' slow
            final AlgorithmParameterSpec spec;
            if ("SLH-DSA-SHA2-128S".equalsIgnoreCase(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_sha2_128s;
            } else if ("SLH-DSA-SHAKE-128S".equalsIgnoreCase(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_shake_128s;
            } else if ("SLH-DSA-SHA2-128F".equalsIgnoreCase(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_sha2_128f;
            } else if ("SLH-DSA-SHAKE-128F".equals(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_shake_128f;
            } else if ("SLH-DSA-SHA2-192S".equalsIgnoreCase(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_sha2_192s;
            } else if ("SLH-DSA-SHAKE-192S".equals(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_shake_192s;
            } else if ("SLH-DSA-SHA2-192F".equalsIgnoreCase(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_sha2_192f;
            } else if ("SLH-DSA-SHAKE-192F".equals(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_shake_192f;
            } else if ("SLH-DSA-SHA2-256S".equalsIgnoreCase(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_sha2_256s;
            } else if ("SLH-DSA-SHAKE-256S".equals(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_shake_256s;
            } else if ("SLH-DSA-SHA2-256F".equalsIgnoreCase(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_sha2_256f;
            } else if ("SLH-DSA-SHAKE-256F".equals(keyAlg)) {
                spec = SLHDSAParameterSpec.slh_dsa_shake_256f;
            } else {
                throw new InvalidAlgorithmParameterException(keySpec + " is not a valid ML-DSA key algorithm specification");
            }
            keygen.initialize(spec);
        }
        // If KeyAlg is Ed448 or Ed25519, we don't even need a keySpec
        final KeyPair keys = keygen.generateKeyPair();

        if (log.isDebugEnabled()) {
            final PublicKey pk = keys.getPublic();
            final int len = getKeyLength(pk);
            log.debug("Generated " + keys.getPublic().getAlgorithm() + " keys with length " + len);
        }
        log.trace("<genKeys()");
        return keys;
    } // genKeys

    /**
     * @see KeyTools#genKeys(String,AlgorithmParameterSpec,String)
     *
     * @throws InvalidAlgorithmParameterException  if the given parameters are inappropriate for this key pair generator.
     */
    public static KeyPair genKeys(final String keySpec, final String keyAlg) throws InvalidAlgorithmParameterException {
       return genKeys(keySpec, null, keyAlg);
    }


    /**
     * Encodes an EC point
     *
     * @param ecPoint an EC point
     * @param curve an EC curve
     * @return the EC point as a byte array or null if the point couldn't be encoded
     */
    public static byte[] encodeEcPoint(final ECPoint ecPoint, final EllipticCurve curve) {
        byte[] x = ecPoint.getAffineX().toByteArray();
        byte[] y = ecPoint.getAffineY().toByteArray();
        int i, xoff = 0, yoff = 0;
        for (i = 0; i < x.length - 1; i++) {
            if (x[i] != 0) {
                xoff = i;
                break;
            }
        }
        for (i = 0; i < y.length - 1; i++) {
            if (y[i] != 0) {
                yoff = i;
                break;
            }
        }
        int len = (curve.getField().getFieldSize() + 7) / 8;
        if ((x.length - xoff) > len || (y.length - yoff) > len) {
            return null;
        }
        byte[] ret = new byte[len * 2 + 1];
        ret[0] = 4;
        System.arraycopy(x, xoff, ret, 1 + len - (x.length - xoff), x.length - xoff);
        System.arraycopy(y, yoff, ret, ret.length - (y.length - yoff), y.length - yoff);
        return ret;
    }

    /**
     * Decodes an EC Point
     *
     * @param encodedKey the encoded key
     * @param curve an EC curve
     * @return the decoded point or null if the point couldn't be decoded
     */
    public static ECPoint decodeEcPoint(final byte[] encodedKey, final EllipticCurve curve) {
        int length = (curve.getField().getFieldSize() + 7) / 8;
        if (encodedKey.length != 2 * length + 1 || encodedKey[0] != 4) {
            return null;
        }
        byte[] x = new byte[length];
        byte[] y = new byte[length];
        System.arraycopy(encodedKey, 1, x, 0, length);
        System.arraycopy(encodedKey, length + 1, y, 0, length);
        return new ECPoint(new BigInteger(1,x), new BigInteger(1,y));
    }

    /**
     * Takes a Ed25519 public key and encodes it
     *
     * @param edPublicKey a Ed25519 public key
     * @return the resulting byte array
     */
    public static byte[] encodeEd25519PublicKey(final PublicKey edPublicKey) {
        try {
            ASN1InputStream asn1InputStream = new ASN1InputStream(edPublicKey.getEncoded());
            try {
                DLSequence id = (DLSequence) asn1InputStream.readObject();
                DERBitString raw = (DERBitString) id.getObjectAt(1).toASN1Primitive();
                return raw.getBytes();
            } finally {
                asn1InputStream.close();
            }
        } catch (IOException e) {
            throw new IllegalStateException("IOException encountered when encoding Ed25519 key.");
        }
    }

    /**
     * Takes an encoded Ed25519 public key and returns it as a PublicKey
     *
     * @param keyBody the encoded public key
     * @return the public key as a PublicKey object
     */
    public static PublicKey decodeEd25519PublicKey(final byte[] keyBody) {
        KeyFactory keyFactory;
        try {
            keyFactory = KeyFactory.getInstance(EdECObjectIdentifiers.id_Ed25519.getId(), BouncyCastleProvider.PROVIDER_NAME);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Ed25519 was not found as an algorithm", e);
        } catch (NoSuchProviderException e) {
            throw new IllegalStateException("BouncyCastle was not found as a provider.", e);
        }
        SubjectPublicKeyInfo pubKeyInfo = new SubjectPublicKeyInfo(new AlgorithmIdentifier(EdECObjectIdentifiers.id_Ed25519), keyBody);
        try {
            EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(pubKeyInfo.getEncoded());
            return keyFactory.generatePublic(x509KeySpec);
        } catch (IOException | InvalidKeySpecException e) {
            throw new IllegalStateException("Couldn't decode Ed25519 public key", e);
        }
    }


    /**
     * Gets the key length of supported keys
     *
     * @param pk
     *            PublicKey used to derive the keysize
     * @return -1 if key is unsupported, otherwise a number >= 0. 0 usually means the length can not be calculated
     */
    public static int getKeyLength(final PublicKey pk) {
        if (pk instanceof RSAPublicKey) {
            final RSAPublicKey rsapub = (RSAPublicKey) pk;
            return rsapub.getModulus().bitLength();
        }
        if (pk instanceof JCEECPublicKey) {
            final JCEECPublicKey ecpriv = (JCEECPublicKey) pk;
            final org.bouncycastle.jce.spec.ECParameterSpec spec = ecpriv.getParameters();
            if (spec != null) {
                return spec.getN().bitLength();
            }
            // We support the key, but we don't know the key length
            return 0;
        }
        if (pk instanceof BCECPublicKey) {
            final BCECPublicKey ecpriv = (BCECPublicKey) pk;
            final org.bouncycastle.jce.spec.ECParameterSpec spec = ecpriv.getParameters();
            if (spec != null) {
                return spec.getN().bitLength();
            }
            // We support the key, but we don't know the key length
            return 0;
        }
        if (pk instanceof ECPublicKey) {
            final ECPublicKey ecpriv = (ECPublicKey) pk;
            final java.security.spec.ECParameterSpec spec = ecpriv.getParams();
            if (spec != null) {
                return spec.getOrder().bitLength(); // does this really return something we expect?
            }
            // We support the key, but we don't know the key length
            return 0;
        }
        if (pk instanceof BCEdDSAPublicKey) {
            final String algo = pk.getAlgorithm();
            switch (algo) {
            case AlgorithmConstants.KEYALGORITHM_ED25519:
                return 255;
            case AlgorithmConstants.KEYALGORITHM_ED448:
                return 448;
            }
        }
        if (pk instanceof FalconPublicKey) {
            // Security levels 2, 3, 5 corresponds to security bit strength 128, 192, 256 (equals to AES 128, 192, 256)
            // For example: https://asecuritysite.com/pqc/falcon01
            if (FalconParameterSpec.falcon_512.equals(((FalconPublicKey)pk).getParameterSpec())) {
                return 128;
            } else if (FalconParameterSpec.falcon_1024.equals(((FalconPublicKey)pk).getParameterSpec())) {
                return 256;
            }

        }
        if (pk instanceof MLKEMPublicKey) {
            // Security levels 2, 3, 5 corresponds to security bit strength 128, 192, 256 (equals to AES 128, 192, 256)
            if (MLKEMParameterSpec.ml_kem_512.equals(((MLKEMPublicKey)pk).getParameterSpec())) {
                return 128;
            } else if (MLKEMParameterSpec.ml_kem_768.equals(((MLKEMPublicKey)pk).getParameterSpec())) {
                return 192;
            } else if (MLKEMParameterSpec.ml_kem_1024.equals(((MLKEMPublicKey)pk).getParameterSpec())) {
                return 256;
            }

        }
        if (pk instanceof MLDSAPublicKey) {
            // Security levels 2, 3, 5 corresponds to security bit strength 128, 192, 256 (equals to AES 128, 192, 256)
            if (MLDSAParameterSpec.ml_dsa_44.equals(((MLDSAPublicKey)pk).getParameterSpec())) {
                return 128;
            } else if (MLDSAParameterSpec.ml_dsa_65.equals(((MLDSAPublicKey)pk).getParameterSpec())) {
                return 192;
            } else if (MLDSAParameterSpec.ml_dsa_87.equals(((MLDSAPublicKey)pk).getParameterSpec())) {
                return 256;
            }
        }
        if (pk instanceof SLHDSAPublicKey) {
            // Security levels 2, 3, 5 corresponds to security bit strength 128, 192, 256 (equals to AES 128, 192, 256)
            SLHDSAParameterSpec slhdsaParameterSpec =  ((SLHDSAPublicKey)pk).getParameterSpec();
            if(List.of(SLHDSAParameterSpec.slh_dsa_sha2_128s, SLHDSAParameterSpec.slh_dsa_shake_128s,
                    SLHDSAParameterSpec.slh_dsa_sha2_128f, SLHDSAParameterSpec.slh_dsa_shake_128f).contains(slhdsaParameterSpec)) {
                return 128;
            } else if(List.of(SLHDSAParameterSpec.slh_dsa_sha2_192s, SLHDSAParameterSpec.slh_dsa_shake_192s,
                    SLHDSAParameterSpec.slh_dsa_sha2_192f, SLHDSAParameterSpec.slh_dsa_shake_192f).contains(slhdsaParameterSpec)) {
                return 192;
            } else if(List.of(SLHDSAParameterSpec.slh_dsa_sha2_256s, SLHDSAParameterSpec.slh_dsa_shake_256s,
                    SLHDSAParameterSpec.slh_dsa_sha2_256f, SLHDSAParameterSpec.slh_dsa_shake_256f).contains(slhdsaParameterSpec)) {
                return 256;
            }
        }

        // The return value comes from public key length found in the draft
        // https://www.ietf.org/archive/id/draft-ietf-lamps-pq-composite-sigs-13.html#name-maximum-key-and-signature-s
        if (pk instanceof CompositePublicKey) {
            if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA44_RSA2048_PSS_SHA256)) {
                return 1582;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA44_Ed25519_SHA512)) {
                return 1344;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA44_ECDSA_P256_SHA256)) {
                return 1377;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_RSA3072_PSS_SHA512)) {
                return 2350;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_RSA4096_PSS_SHA512)) {
                return 2478;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_P256_SHA512)) {
                return 2017;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_P384_SHA512)) {
                return 2049;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_brainpoolP256r1_SHA512)) {
                return 2017;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_Ed25519_SHA512)) {
                return 1984;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_RSA3072_PSS_SHA512)) {
                return 2990;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_RSA4096_PSS_SHA512)) {
                return 3118;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_P384_SHA512)) {
                return 2689;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_P521_SHA512)) {
                return 2725;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_brainpoolP384r1_SHA512)) {
                return 2689;
            } else if (pk.getAlgorithm().equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_Ed448_SHAKE256)) {
                return 2649;
            }
        }

        // Unknown key type, or something that does not have an intuitive key length (ML-DSA for example)
        return -1;
    }

    /**
     * Gets the key AlgorithmParameterSpec of supported keys. Can be used to initialize a KeyPairGenerator to generate a key of equal type and size.
     *
     * @param pk
     *            PublicKey used to derive the AlgorithmParameterSpec
     * @return null if key is unsupported or pk is null, otherwise a AlgorithmParameterSpec.
     */
    public static AlgorithmParameterSpec getKeyGenSpec(final PublicKey pk) {
        if (pk == null) {
            return null;
        }
        if (pk instanceof RSAPublicKey) {
            log.debug("getKeyGenSpec: RSA");
            final RSAPublicKey rpk = (RSAPublicKey) pk;
            return new RSAKeyGenParameterSpec(getKeyLength(pk), rpk.getPublicExponent());
        }
        if (pk instanceof ECPublicKey) {
            log.debug("getKeyGenSpec: ECPublicKey");
            final ECPublicKey ecpub = (ECPublicKey) pk;
            final java.security.spec.ECParameterSpec sunsp = ecpub.getParams();
            final EllipticCurve ecurve = new EllipticCurve(sunsp.getCurve().getField(), sunsp.getCurve().getA(), sunsp.getCurve().getB());
            // ECParameterSpec par = new ECNamedCurveSpec(null, sunsp.getCurve(), sunsp.getGenerator(), sunsp.getOrder(),
            // BigInteger.valueOf(sunsp.getCofactor()));
            final ECParameterSpec params = new ECParameterSpec(ecurve, sunsp.getGenerator(), sunsp.getOrder(), sunsp.getCofactor());
            if (log.isDebugEnabled()) {
                log.debug("Fieldsize: " + params.getCurve().getField().getFieldSize());
                final EllipticCurve curve = params.getCurve();
                log.debug("CurveA: " + curve.getA().toString(16));
                log.debug("CurveB: " + curve.getB().toString(16));
                log.debug("CurveSeed: " + curve.getSeed());
                final ECFieldFp field = (ECFieldFp) curve.getField();
                log.debug("CurveSfield: " + field.getP().toString(16));
                final ECPoint p = params.getGenerator();
                log.debug("Generator: " + p.getAffineX().toString(16) + ", " + p.getAffineY().toString(16));
                log.debug("Order: " + params.getOrder().toString(16));
                log.debug("CoFactor: " + params.getCofactor());
            }
            return params;
        }
        if (pk instanceof JCEECPublicKey) {
            log.debug("getKeyGenSpec: JCEECPublicKey");
            final JCEECPublicKey ecpub = (JCEECPublicKey) pk;
            final org.bouncycastle.jce.spec.ECParameterSpec bcsp = ecpub.getParameters();
            final ECCurve curve = bcsp.getCurve();
            // TODO: this probably does not work for key generation with the Sun PKCS#11 provider. Maybe seed needs to be set to null as above? Or
            // something else, the BC curve is it the same?
            final ECParameterSpec params = new ECNamedCurveSpec(null, curve, bcsp.getG(), bcsp.getN(), bcsp.getH());
            return params;
            // EllipticCurve ecc = new EllipticCurve(curve.)
            // ECParameterSpec sp = new ECParameterSpec(, bcsp.getG(), bcsp.getN(), bcsp.getH().intValue());
        }
        if (pk instanceof BCEdDSAPublicKey) {
            log.debug("getKeyGenSpec: BCEdDSAPublicKey");
            final EdDSAParameterSpec edSpec = new EdDSAParameterSpec(pk.getAlgorithm());
            return edSpec;
        }
        if (pk instanceof FalconPublicKey) {
            log.debug("getKeyGenSpec: FalconPublicKey");
            final FalconParameterSpec spec = ((FalconPublicKey)pk).getParameterSpec();
            return spec;
        }
        if (pk instanceof MLKEMPublicKey) {
            log.debug("getKeyGenSpec: MLKEMPublicKey");
            final MLKEMParameterSpec spec = ((MLKEMPublicKey)pk).getParameterSpec();
            return spec;
        }
        if (pk instanceof MLDSAPublicKey) {
            log.debug("getKeyGenSpec: MLDSAPublicKey");
            final MLDSAParameterSpec spec = ((MLDSAPublicKey)pk).getParameterSpec();
            return spec;
        }
        if (pk instanceof SLHDSAPublicKey) {
            log.debug("getKeyGenSpec: SLHDSAPublicKey");
            final SLHDSAParameterSpec spec = ((SLHDSAPublicKey)pk).getParameterSpec();
            return spec;
        }
        return null;
    }


    /**
     * Creates PKCS12-file that can be imported in IE or Firefox. The alias for the private key is set to 'privateKey' and the private key password is
     * null.
     *
     * @param alias
     *            the alias used for the key entry
     * @param privKey
     *            RSA private key
     * @param cert
     *            user certificate
     * @param cacert
     *            CA-certificate or null if only one cert in chain, in that case use 'cert'.
     * @param keyStoreCipher A cipher as supported by BouncyCastle
     *
     * @return KeyStore containing PKCS12-keystore
     * @throws CertificateException if the certificate couldn't be parsed
     * @throws CertificateEncodingException if the encoded bytestream of the certificate couldn't be retrieved
     * @throws NoSuchAlgorithmException if the algorithm defined in privKey couldn't be found
     * @throws InvalidKeySpecException if the key specification defined in privKey couldn't be found
     *
     * @deprecated Use the X509Certificate taking equivalent
     */
    @Deprecated(forRemoval = true)
	public static KeyStore createP12(final String alias, final PrivateKey privKey, final Certificate cert,
			final Certificate cacert, final KeyStoreCipher keyStoreCipher)
			throws CertificateException, NoSuchAlgorithmException, InvalidKeySpecException {
    	if(!(cert instanceof X509Certificate) || !(cacert instanceof X509Certificate)) {
    		throw new IllegalStateException("createP12 method has been called for a non X509Certificate certificate type");
    	}

		return createP12(alias, privKey, (X509Certificate) cert, (X509Certificate) cacert, keyStoreCipher);
    }

    /**
     * Creates PKCS12-file that can be imported in IE or Firefox. The alias for the private key is set to 'privateKey' and the private key password is
     * null.
     *
     * @param alias the alias used for the key entry
     * @param privKey RSA private key
     * @param cert user certificate
     * @param cacert CA-certificate or null if only one cert in chain, in that case use 'cert'.
     * @param keyStoreCipher A cipher as supported by BouncyCastle
     *
     * @return KeyStore containing PKCS12-keystore
     * @throws CertificateException if the certificate couldn't be parsed
     * @throws CertificateEncodingException if the encoded bytestream of the certificate couldn't be retrieved
     * @throws NoSuchAlgorithmException if the algorithm defined in privKey couldn't be found
     * @throws InvalidKeySpecException if the key specification defined in privKey couldn't be found
     */
	public static KeyStore createP12(final String alias, final PrivateKey privKey, final X509Certificate cert,
			final X509Certificate cacert, final KeyStoreCipher keyStoreCipher)
			throws CertificateException, NoSuchAlgorithmException, InvalidKeySpecException {
        final X509Certificate[] chain;

        if (cacert == null) {
            chain = null;
        } else {
            chain = new X509Certificate[1];
            chain[0] = cacert;
        }

        return createP12(alias, privKey, cert, chain, keyStoreCipher);
    }

	/**
     * Creates PKCS12-file that can be imported in IE or Firefox. The alias for the private key is set to 'privateKey' and the private key password is
     * null.
     *
     * @param alias
     *            the alias used for the key entry
     * @param privKey
     *            RSA private key
     * @param cert
     *            user certificate
     * @param cacerts
     *            Collection of X509Certificate, or null if only one cert in chain, in that case use 'cert'.
     * @param keyStoreCipher A cipher as supported by BouncyCastle
     * @return KeyStore containing PKCS12-keystore
     * @throws CertificateException if the certificate couldn't be parsed
     * @throws CertificateEncodingException if the encoded bytestream of the certificate couldn't be retrieved
     * @throws NoSuchAlgorithmException if the algorithm defined in privKey couldn't be found
     * @throws InvalidKeySpecException if the key specification defined in privKey couldn't be found
     *
     * @deprecated User the X509Certificate equivalent
     */
	@Deprecated
	public static KeyStore createP12(final String alias, final PrivateKey privKey, final Certificate cert,
			final Collection<Certificate> cacerts, final KeyStoreCipher keyStoreCipher)
			throws CertificateException, NoSuchAlgorithmException, InvalidKeySpecException {
        final Certificate[] chain;
        if (cacerts == null) {
            chain = null;
        } else {
            chain = cacerts.toArray(new Certificate[cacerts.size()]);
        }
        return createP12(alias, privKey, cert, chain, keyStoreCipher);
    }


    /**
     * Creates PKCS12-file that can be imported in IE or Firefox. The alias for the private key is set to 'privateKey' and the private key password is
     * null.
     *
     * @param alias
     *            the alias used for the key entry
     * @param privKey
     *            RSA private key
     * @param cert
     *            user certificate
     * @param cacerts
     *            Collection of X509Certificate, or null if only one cert in chain, in that case use 'cert'.
     * @param keyStoreCipher A cipher as supported by BouncyCastle
     * @return KeyStore containing PKCS12-keystore
     * @throws CertificateException if the certificate couldn't be parsed
     * @throws CertificateEncodingException if the encoded bytestream of the certificate couldn't be retrieved
     * @throws NoSuchAlgorithmException if the algorithm defined in privKey couldn't be found
     * @throws InvalidKeySpecException if the key specification defined in privKey couldn't be found
     */
	public static KeyStore createP12(final String alias, final PrivateKey privKey, final X509Certificate cert,
			final Collection<X509Certificate> cacerts, final KeyStoreCipher keyStoreCipher)
			throws CertificateException, NoSuchAlgorithmException, InvalidKeySpecException {
        final X509Certificate[] chain;
        if (cacerts == null) {
            chain = null;
        } else {
            chain = cacerts.toArray(new X509Certificate[cacerts.size()]);
        }
        return createP12(alias, privKey, cert, chain, keyStoreCipher);
    }

	 /**
     * Creates PKCS12-file that can be imported in IE or Firefox. The alias for the private key is set to 'privateKey' and the private key password is
     * null.
     *
     * @param alias
     *            the alias used for the key entry
     * @param privateKey
     *            private key
     * @param certificate
     *            user certificate
     * @param caCertificateChain
     *            CA-certificate chain or null if only one cert in chain, in that case use 'cert'.
     * @param keyStoreCipher A cipher as supported by BouncyCastle
     * @return KeyStore containing PKCS12-keystore
     * @throws CertificateException if the certificate couldn't be parsed
     * @throws CertificateEncodingException if the encoded bytestream of the certificate couldn't be retrieved
     * @throws NoSuchAlgorithmException if the algorithm defined in privKey couldn't be found
     * @throws InvalidKeySpecException if the key specification defined in privKey couldn't be found
     *
     * @deprecated Use the X509Certificate equivalent
     */
	@Deprecated(forRemoval = true)
	public static KeyStore createP12(final String alias, final PrivateKey privateKey, final Certificate certificate,
			final Certificate[] caCertificateChain, final KeyStoreCipher keyStoreCipher)
			throws CertificateEncodingException, CertificateException, NoSuchAlgorithmException,
			InvalidKeySpecException {
        return createP12(alias, privateKey, (X509Certificate) certificate, (X509Certificate[]) caCertificateChain, keyStoreCipher);
    }

    /**
     * Creates PKCS12-file that can be imported in IE or Firefox. The alias for the private key is set to 'privateKey' and the private key password is
     * null.
     *
     * @param alias
     *            the alias used for the key entry
     * @param privateKey
     *            private key
     * @param certificate
     *            user certificate
     * @param caCertificateChain
     *            CA-certificate chain or null if only one cert in chain, in that case use 'cert'.
     * @param keyStoreCipher A cipher as supported by BouncyCastle
     * @return KeyStore containing PKCS12-keystore
     * @throws CertificateException if the certificate couldn't be parsed
     * @throws CertificateEncodingException if the encoded bytestream of the certificate couldn't be retrieved
     * @throws NoSuchAlgorithmException if the algorithm defined in privKey couldn't be found
     * @throws InvalidKeySpecException if the key specification defined in privKey couldn't be found
     */
	public static KeyStore createP12(final String alias, final PrivateKey privateKey, final X509Certificate certificate,
			final X509Certificate[] caCertificateChain, final KeyStoreCipher keyStoreCipher)
			throws CertificateEncodingException, CertificateException, NoSuchAlgorithmException,
			InvalidKeySpecException {
        try {
            KeyStore store = KeyStore.getInstance(keyStoreCipher.getLabel(), BouncyCastleProvider.PROVIDER_NAME);
            store.load(null, null);
            return createP12(alias, privateKey, certificate, caCertificateChain, store);
        } catch (IOException | KeyStoreException | NoSuchProviderException e) {
            throw new IllegalStateException(e);
        }
    }

    @SuppressWarnings("unused") // TODO Make public when EJBCAINTER-789 is done
    private static KeyStore createP12(final String alias, final PrivateKey privateKey,
			final PrivateKey alternativePrivateKey, final X509Certificate certificate,
			final X509Certificate[] caCertificateChain, final KeyStoreCipher keyStoreCipher) throws CertificateEncodingException, CertificateException,
			NoSuchAlgorithmException, InvalidKeySpecException {
		try {
			KeyStore store = KeyStore.getInstance(keyStoreCipher.getLabel(), BouncyCastleProvider.PROVIDER_NAME);
			store.load(null, null);
			return createP12(alias, privateKey, alternativePrivateKey, certificate, caCertificateChain, store);
		} catch (IOException | KeyStoreException | NoSuchProviderException e) {
			throw new IllegalStateException(e);
		}
	}

    /**
     * Create a Bouncy Castle's BCFKS. See https://downloads.bouncycastle.org/fips-java/docs/ for the userguide
     *
     * @param alias the alias to use for keystore entries.
     * @param privateKey the private key to store in the keystore.
     * @param certificate the user's certificate to store in the keystore.
     * @param caCertificateChain the CA certificate chain to store in the keystore.
     * @return a BCFKS keystore as a {@link KeyStore} object.
     *
     * @throws CertificateEncodingException if the certificate could not be decoded.
     * @throws CertificateException
     * @throws NoSuchAlgorithmException if an algorithm is unavailable.
     * @throws InvalidKeySpecException
     *
     * @Deprecated use the X509Certificate equivalent
     */
    @Deprecated(forRemoval = true)
    public static KeyStore createBcfks(final String alias, final PrivateKey privateKey, final Certificate certificate, final Certificate[] caCertificateChain)
            throws CertificateException, NoSuchAlgorithmException, InvalidKeySpecException {
        return createBcfks(alias, privateKey, (X509Certificate) certificate, (X509Certificate[]) caCertificateChain);
    }

    /**
     * Create a Bouncy Castle's BCFKS. See https://downloads.bouncycastle.org/fips-java/docs/ for the userguide
     *
     * @param alias the alias to use for keystore entries.
     * @param privateKey the private key to store in the keystore.
     * @param certificate the user's certificate to store in the keystore.
     * @param caCertificateChain the CA certificate chain to store in the keystore.
     * @return a BCFKS keystore as a {@link KeyStore} object.
     *
     * @throws CertificateEncodingException if the certificate could not be decoded.
     * @throws CertificateException
     * @throws NoSuchAlgorithmException if an algorithm is unavailable.
     * @throws InvalidKeySpecException
     */
    public static KeyStore createBcfks(final String alias, final PrivateKey privateKey, final X509Certificate certificate, final X509Certificate[] caCertificateChain)
            throws CertificateException, NoSuchAlgorithmException, InvalidKeySpecException {
        try {
            KeyStore store = KeyStore.getInstance("BCFKS", CryptoProviderTools.getProviderNameFromAlg(privateKey.getAlgorithm()));
            store.load(null, null);
            return createP12(alias, privateKey, certificate, caCertificateChain, store);
        } catch (IOException | KeyStoreException | NoSuchProviderException e) {
            throw new IllegalStateException(e);
        }
    }

    private static KeyStore createP12(final String alias, final PrivateKey privateKey, final X509Certificate certificate, final X509Certificate[] caCertificateChain, final KeyStore store)
            throws CertificateException, NoSuchAlgorithmException, InvalidKeySpecException {
        return createP12(alias, privateKey, null, certificate, caCertificateChain, store);
    }

	private static KeyStore createP12(final String alias, final PrivateKey privateKey,
			final PrivateKey alternativePrivateKey, final X509Certificate certificate,
			final X509Certificate[] caCertificateChain, final KeyStore store)
			throws CertificateException, NoSuchAlgorithmException, InvalidKeySpecException {
		if (log.isTraceEnabled()) {
			log.trace(">createP12: alias=" + alias + ", privateKey, alternativePrivateKey, certificate=" + CertTools.getSubjectDN(certificate)
					+ ", caCertificateChain.length=" + ((caCertificateChain == null) ? 0 : caCertificateChain.length));
		}
		// Certificate chain
		if (certificate == null) {
			throw new IllegalArgumentException("Parameter certificate cannot be null.");
		}
		int len = 1;
		if (caCertificateChain != null) {
			len += caCertificateChain.length;
		}
		final Certificate[] chain = new Certificate[len];
		// To not get a ClassCastException we need to generate a real new certificate
		// with BC
		final CertificateFactory cf = CertTools.getCertificateFactory();
		chain[0] = cf.generateCertificate(new ByteArrayInputStream(certificate.getEncoded()));

		if (caCertificateChain != null) {
			for (int i = 0; i < caCertificateChain.length; i++) {
				final X509Certificate tmpcert = (X509Certificate) cf
						.generateCertificate(new ByteArrayInputStream(caCertificateChain[i].getEncoded()));
				chain[i + 1] = tmpcert;
			}
		}
		if (chain.length > 1) {
			for (int i = 1; i < chain.length; i++) {
				final X509Certificate cacert = (X509Certificate) cf
						.generateCertificate(new ByteArrayInputStream(chain[i].getEncoded()));
				// Set attributes on CA-certificate
				try {
					final PKCS12BagAttributeCarrier caBagAttr = (PKCS12BagAttributeCarrier) chain[i];
					// We construct a friendly name for the CA, and try with some parts from the DN
					// if they exist.
					String cafriendly = DnComponents.getPartFromDN(CertTools.getSubjectDN(cacert), "CN");
					// On the ones below we +i to make it unique, O might not be otherwise
					if (cafriendly == null) {
						cafriendly = DnComponents.getPartFromDN(CertTools.getSubjectDN(cacert), "O");
						if (cafriendly == null) {
							cafriendly = DnComponents.getPartFromDN(CertTools.getSubjectDN(cacert), "OU");
							if (cafriendly == null) {
								cafriendly = "CA_unknown" + i;
							} else {
								cafriendly = cafriendly + i;
							}
						} else {
							cafriendly = cafriendly + i;
						}
					}
					caBagAttr.setBagAttribute(PKCSObjectIdentifiers.pkcs_9_at_friendlyName,
							new DERBMPString(cafriendly));
				} catch (ClassCastException e) {
					log.error("ClassCastException setting BagAttributes, can not set friendly name: ", e);
				}
			}
		}

		// Set attributes on user-certificate
		try {
			final PKCS12BagAttributeCarrier certBagAttr = (PKCS12BagAttributeCarrier) chain[0];
			certBagAttr.setBagAttribute(PKCSObjectIdentifiers.pkcs_9_at_friendlyName, new DERBMPString(alias));
			// in this case we just set the local key id to that of the public key
			certBagAttr.setBagAttribute(PKCSObjectIdentifiers.pkcs_9_at_localKeyId,
					createSubjectKeyId(chain[0].getPublicKey()));
		} catch (ClassCastException e) {
			log.error("ClassCastException setting BagAttributes, can not set friendly name: ", e);
		}
		try {
			// "Clean" private key, i.e. remove any old attributes,
			// As well as convert any EdDSA key to v1 format that is understood by openssl
			// v1.1.1 and earlier
			// EdDSA (Ed25519 or Ed448) keys have a v1 format, with only the private key,
			// and a v2 format that includes both the private and public
			final PrivateKeyInfo pkInfo = PrivateKeyInfo.getInstance(privateKey.getEncoded());
			final PrivateKeyInfo v1PkInfo = new PrivateKeyInfo(pkInfo.getPrivateKeyAlgorithm(),
			        pkInfo.getPrivateKey().getOctets());
			final KeyFactory keyfact = KeyFactory.getInstance(privateKey.getAlgorithm(),
					CryptoProviderTools.getProviderNameFromAlg(privateKey.getAlgorithm()));
			final PrivateKey pk = keyfact.generatePrivate(new PKCS8EncodedKeySpec(v1PkInfo.getEncoded()));
			// The PKCS#12 bag attributes PKCSObjectIdentifiers.pkcs_9_at_friendlyName and
            // PKCSObjectIdentifiers.pkcs_9_at_localKeyId
            // are set automatically by BC when setting the key entry
            store.setKeyEntry(alias, pk, null, chain);

            // "Clean" alternative private key, i.e. remove any old attributes,
			// As well as convert any EdDSA key to v1 format that is understood by openssl
			// v1.1.1 and earlier
			// EdDSA (Ed25519 or Ed448) keys have a v1 format, with only the private key,
			// and a v2 format that includes both the private and public
            if (alternativePrivateKey != null) {
				final PrivateKeyInfo altPkInfo = PrivateKeyInfo.getInstance(alternativePrivateKey.getEncoded());
				final PrivateKeyInfo altV1PkInfo = new PrivateKeyInfo(altPkInfo.getPrivateKeyAlgorithm(),
						altPkInfo.getPrivateKey().getOctets());
				final KeyFactory altKeyfact = KeyFactory.getInstance(alternativePrivateKey.getAlgorithm(),
						CryptoProviderTools.getProviderNameFromAlg(alternativePrivateKey.getAlgorithm()));
				final PrivateKey altPK = altKeyfact.generatePrivate(new PKCS8EncodedKeySpec(altV1PkInfo.getEncoded()));
				// The PKCS#12 bag attributes PKCSObjectIdentifiers.pkcs_9_at_friendlyName and
				// PKCSObjectIdentifiers.pkcs_9_at_localKeyId
				// are set automatically by BC when setting the key entry
				store.setKeyEntry(alias, altPK, null, chain);
				throw new UnsupportedOperationException("Hybrid keystore support is not fully implemented yet"); // TODO See EJBCAINTER-789
            }
			if (log.isTraceEnabled()) {
				log.trace("<createP12: alias=" + alias + ", privateKey, alternativePrivateKey, certificate="
						+ CertTools.getSubjectDN(certificate) + ", caCertificateChain.length="
						+ ((caCertificateChain == null) ? 0 : caCertificateChain.length));
			}
			return store;
		} catch (NoSuchProviderException e) {
			throw new IllegalStateException("BouncyCastle provider was not found.", e);
		} catch (KeyStoreException e) {
			throw new IllegalStateException("PKCS12 keystore type could not be instanced.", e);
		} catch (IOException e) {
			throw new IllegalStateException("IOException should not be thrown when instancing an empty keystore.", e);
		}
	}

    /**
     * Creates JKS-file that can be used with JDK. The alias for the private key is set to 'privateKey' and the private key password is null.
     *
     * @param alias
     *            the alias used for the key entry
     * @param privKey
     *            RSA private key
     * @param password
     *            user's password
     * @param cert
     *            user certificate
     * @param cachain
     *            CA-certificate chain or null if only one cert in chain, in that case use 'cert'.
     *
     * @return KeyStore containing JKS-keystore
     * @throws KeyStoreException is storing the certificate failed, perhaps because the alias is already being used?
     */
    public static KeyStore createJKS(final String alias, final PrivateKey privKey, final String password, final X509Certificate cert,
            final Certificate[] cachain) throws KeyStoreException {
        if (log.isTraceEnabled()) {
            log.trace(">createJKS: alias=" + alias + ", privKey, cert=" + CertTools.getSubjectDN(cert) + ", cachain.length="
                    + ((cachain == null) ? 0 : cachain.length));
        }
        final String caAlias = CA_CERT_CHAIN_ALIAS;

        // Certificate chain
        if (cert == null) {
            throw new IllegalArgumentException("Parameter cert cannot be null.");
        }
        int len = 1;
        if (cachain != null) {
            len += cachain.length;
        }
        final Certificate[] chain = new Certificate[len];
        chain[0] = cert;
        if (cachain != null) {
            System.arraycopy(cachain, 0, chain, 1, cachain.length);
        }

        // store the key and the certificate chain
        final KeyStore store;
        try {
            store = KeyStore.getInstance("JKS");
        } catch (KeyStoreException e) {
            throw new IllegalStateException("No JKS implementation found in provider", e);
        }
        try {
            store.load(null, null);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        } catch (CertificateException e) {
            throw new IllegalStateException(e);
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }

        // First load the key entry
        final X509Certificate[] usercert = new X509Certificate[1];
        usercert[0] = cert;
        try {
            store.setKeyEntry(alias, privKey, password.toCharArray(), usercert);
        } catch (KeyStoreException e) {
            throw new IllegalStateException("Keystore apparently hasn't been loaded?", e);

        }

        // Add the root cert as trusted
        if (cachain != null) {
            if (!CertTools.isSelfSigned(cachain[cachain.length - 1])) {
                throw new IllegalArgumentException("Root cert is not self-signed.");
            }
            store.setCertificateEntry(caAlias, cachain[cachain.length - 1]);
        }

        // Set the complete chain
        log.debug("Storing cert chain of length " + chain.length);
        store.setKeyEntry(alias, privKey, password.toCharArray(), chain);
        if (log.isTraceEnabled()) {
            log.trace("<createJKS: alias=" + alias + ", privKey, cert=" + CertTools.getSubjectDN(cert) + ", cachain.length="
                    + ((cachain == null) ? 0 : cachain.length));
        }
        return store;
    } // createJKS

    /**
     * Convert a KeyStore to PEM format.
     */
    public static byte[] getSinglePemFromKeyStore(final KeyStore ks, final char[] password) throws KeyStoreException,
            CertificateEncodingException, IOException, UnrecoverableKeyException, NoSuchAlgorithmException {
        final ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        // Find the key private key entry in the keystore
        final Enumeration<String> e = ks.aliases();
        Object o = null;
        String alias = "";
        PrivateKey serverPrivKey = null;
        while (e.hasMoreElements()) {
            o = e.nextElement();
            if (o instanceof String) {
                if ((ks.isKeyEntry((String) o)) && ((serverPrivKey = (PrivateKey) ks.getKey((String) o, password)) != null)) {
                    alias = (String) o;
                    break;
                }
            }
        }

        final byte[] privKeyEncoded = serverPrivKey!=null ? serverPrivKey.getEncoded() : "".getBytes();

        final Certificate[] chain = KeyTools.getCertChain(ks, (String) o);
        final X509Certificate userX509Certificate = (X509Certificate) chain[0];
        {
            final byte[] output = userX509Certificate.getEncoded();
            final String sn = CertTools.getSubjectDN(userX509Certificate);

            final String subjectdnpem = sn.replace(',', '/');
            final String issuerdnpem = CertTools.getIssuerDN(userX509Certificate).replace(',', '/');

            buffer.write(BAG_ATTRIBUTES);
            buffer.write(FRIENDLY_NAME);
            buffer.write(alias.getBytes());
            buffer.write(NL);
            buffer.write(BEGIN_PRIVATE_KEY);
            buffer.write(NL);

            final byte[] privKey = Base64.encode(privKeyEncoded);
            buffer.write(privKey);
            buffer.write(NL);
            buffer.write(END_PRIVATE_KEY);
            buffer.write(NL);
            buffer.write(BAG_ATTRIBUTES);
            buffer.write(FRIENDLY_NAME);
            buffer.write(alias.getBytes());
            buffer.write(NL);
            buffer.write(SUBJECT_ATTRIBUTE);
            buffer.write(subjectdnpem.getBytes());
            buffer.write(NL);
            buffer.write(ISSUER_ATTRIBUTE);
            buffer.write(issuerdnpem.getBytes());
            buffer.write(NL);
            buffer.write(BEGIN_CERTIFICATE);
            buffer.write(NL);

            final byte[] userCertB64 = Base64.encode(output);
            buffer.write(userCertB64);
            buffer.write(NL);
            buffer.write(END_CERTIFICATE);
            buffer.write(NL);
        }
        if (!CertTools.isSelfSigned(userX509Certificate)) {
            for (int num = 1; num < chain.length; num++) {
                final X509Certificate tmpX509Cert = (X509Certificate) chain[num];
                final String sn = CertTools.getSubjectDN(tmpX509Cert);

                final String cnTmp = DnComponents.getPartFromDN(sn, "CN");
                final String cn = StringUtils.isEmpty(cnTmp) ? cnTmp : "Unknown";

                final String subjectdnpem = sn.replace(',', '/');
                final String issuerdnpem = CertTools.getIssuerDN(tmpX509Cert).replace(',', '/');

                buffer.write(BAG_ATTRIBUTES);
                buffer.write(FRIENDLY_NAME);
                buffer.write(cn.getBytes());
                buffer.write(NL);
                buffer.write(SUBJECT_ATTRIBUTE);
                buffer.write(subjectdnpem.getBytes());
                buffer.write(NL);
                buffer.write(ISSUER_ATTRIBUTE);
                buffer.write(issuerdnpem.getBytes());
                buffer.write(NL);

                final byte[] tmpOutput = tmpX509Cert.getEncoded();
                buffer.write(BEGIN_CERTIFICATE);
                buffer.write(NL);

                final byte[] tmpCACertB64 = Base64.encode(tmpOutput);
                buffer.write(tmpCACertB64);
                buffer.write(NL);
                buffer.write(END_CERTIFICATE);
                buffer.write(NL);
            }
        }
        return buffer.toByteArray();
    }

    /**
     * Get a public key in PEM format.
     *
     * <p>Example:
     * <pre>
     * -----BEGIN PUBLIC KEY-----
     * MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAryQICCl6NZ5gDKrnSztO
     * 3Hy8PEUcuyvg/ikC+VcIo2SFFSf18a3IMYldIugqqqZCs4/4uVW3sbdLs/6PfgdX
     * 7O9D22ZiFWHPYA2k2N744MNiCD1UE+tJyllUhSblK48bn+v1oZHCM0nYQ2NqUkvS
     * j+hwUU3RiWl7x3D2s9wSdNt7XUtW05a/FXehsPSiJfKvHJJnGOX0BgTvkLnkAOTd
     * OrUZ/wK69Dzu4IvrN4vs9Nes8vbwPa/ddZEzGR0cQMt0JBkhk9kU/qwqUseP1QRJ
     * 5I1jR4g8aYPL/ke9K35PxZWuDp3U0UPAZ3PjFAh+5T+fc7gzCs9dPzSHloruU+gl
     * FQIDAQAB
     * -----END PUBLIC KEY-----
     * </pre>
     *
     * @param publicKey the public key to PEM encode
     * @return a string with the PEM encoded public key.
     * @throws IOException if the key could not be encoded.
     */
    public static String getAsPem(final PublicKey publicKey) throws IOException {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try ( final JcaPEMWriter pemWriter = new JcaPEMWriter(new OutputStreamWriter(baos)) ) {
            pemWriter.writeObject(publicKey);
        }
        return new String(baos.toByteArray(), StandardCharsets.UTF_8);
    }

    /**
     * Get a CRL in PEM format.
     *
     * <p>Example:
     * <pre>
     * -----BEGIN X509 CRL-----
     * MIICyjCBswIBATANBgkqhkiG9w0BAQsFADBPMQswCQYDVQQGEwJTRTEeMBwGA1UE
     * CgwVUHJpbWVLZXkgU29sdXRpb25zIEFCMSAwHgYDVQQDDBdDVCBMb2cgVGVzdCBJ
     * c3N1aW5nIFN1YhcNMTkwOTEzMTMzMTU5WhcNMTkwOTE0MTMzMTU5WqAwMC4wHwYD
     * VR0jBBgwFoAUk7mzIWib7jLH1mO79/7uK6InQ/cwCwYDVR0UBAQCAgEMMA0GCSqG
     * SIb3DQEBCwUAA4ICAQB0LFaIsd5Kmg+wkBKFpSNasWMIpdnjXt7qLQ/L8n/R40Qy
     * ZNtgOf/yPjVQclHP/gi0uV/eJvES1oPTwGiuxuNYB8TUUfiWNyuiOJY5bMBtSpKR
     * SiV4GHsE5kfGnpII9fOqA8CDvNZnwg4BK2c1aUH8QUtP/W2/wL6QtopZTN4iwvWQ
     * G4QvKcVbwH0aNenaSdt8A51bjf3K/GI03FP0pmyiAvTAiiho4CTSsUEjPhAI65d9
     * P2k84UyAOiKRVpMq4PxHmQLCRf+ba3CfitJB3ZZ05GVQLqiiUFiSeaqdCb8NQZlM
     * K2rDNgNFefpQvbClrEz1z7RbfbolFC5z2Q+40IoSM1gfgchiTRyie63p3OPeBweJ
     * XTfUQVwN6rGGgbU6fDtFzdKA5ydbJmn0Ey/jUpiV/cQaCrzkHGlwYzvdo0Nktg50
     * dkl2wYlNo1T+pIFShCwQz2DRJ/Bp5S3YQ/cmyXVS1mwWAGHEwwKNcsXqsQG71FJj
     * cnCY5FEmRt1BGX/8VCCwPCMOeRYvQEiSj/UzxYIQHQq8VPnvcQpF1yy/YVoN5W5P
     * LZKuZbOyMkVJb0erKggg74uNSrML1nVp7skS3+9Nnrw3tqoNqVTnDfAagGmZnvZU
     * 3q+j0IbiB3IyD12nsjWNf5Bt0pwAO/KpA2ym6bPZmVjwEtdymJrEcXKuwjQXIw==
     * -----END X509 CRL-----
     * </pre>
     *
     * @param crl the CRL to encode.
     * @return a string with the PEM encoded CRL.
     * @throws IOException if the CRL could not be encoded.
     */
    public static String getAsPem(final X509CRLHolder crl) throws IOException {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try (final JcaPEMWriter pemWriter = new JcaPEMWriter(new OutputStreamWriter(baos))) {
            pemWriter.writeObject(crl);
        }
        return new String(baos.toByteArray(), StandardCharsets.UTF_8);
    }

    /**
     * Retrieves the certificate chain from a keystore.
     *
     * @param keyStore
     *            the keystore, which has been loaded and opened.
     * @param privateKeyAlias
     *            the alias of the privatekey for which the certchain belongs.
     *
     * @return array of Certificate, or null if no certificates are found.
     */
    public static Certificate[] getCertChain(final KeyStore keyStore, final String privateKeyAlias) throws KeyStoreException {
        if (log.isTraceEnabled()) {
            log.trace(">getCertChain: alias='" + privateKeyAlias + "'");
        }
        final Certificate[] certchain = keyStore.getCertificateChain(privateKeyAlias);
        if (certchain == null) {
            return null;
        }
        log.debug("Certchain retrieved from alias '" + privateKeyAlias + "' has length " + certchain.length);

        if (certchain.length < 1) {
            log.error("Cannot load certificate chain with alias '" + privateKeyAlias + "' from keystore.");
            if (log.isTraceEnabled()) {
                log.trace("<getCertChain: alias='" + privateKeyAlias + "', retlength=" + certchain.length);
            }
            return certchain;
        } else if (certchain.length > 0) {
            if (CertTools.isSelfSigned(certchain[certchain.length - 1])) {
                if (log.isDebugEnabled()) {
                    log.debug("Issuer (self signed)='" + CertTools.getIssuerDN(certchain[certchain.length - 1]) + "'.");
                    log.debug("Subject (self signed)='" + CertTools.getSubjectDN(certchain[certchain.length - 1]) + "'.");
                }
                if (log.isTraceEnabled()) {
                    log.trace("<getCertChain: alias='" + privateKeyAlias + "', retlength=" + certchain.length);
                }
                return certchain;
            }
        }

        // If we came here, we have a cert which is not root cert in 'cert'
        final ArrayList<Certificate> array = new ArrayList<>();

        for (int i = 0; i < certchain.length; i++) {
            array.add(certchain[i]);
        }

        while ( true ) {
            final X509Certificate cert = (X509Certificate) array.get(array.size() - 1);
            final String ialias = DnComponents.getPartFromDN(CertTools.getIssuerDN(cert), "CN");
            final Certificate[] chain1 = keyStore.getCertificateChain(ialias);

            if (chain1 == null) {
                break;
            }
            if (log.isDebugEnabled()) {
                log.debug("Loaded certificate chain with length " + chain1.length + " with alias '" + ialias + "'.");
            }

            if (chain1.length == 0) {
                log.error("No RootCA certificate found!");
                break;
            }
            boolean isSelfSigned = false;
            for (int j = 0; j < chain1.length && !isSelfSigned; j++) {
                array.add(chain1[j]);

                // If one cert is slefsigned, we have found a root certificate, we don't need to go on anymore
                if (CertTools.isSelfSigned(chain1[j])) {
                    isSelfSigned = true;
                }
            }
            if ( isSelfSigned ) {
                break;
            }
        }

        final Certificate[] ret = new Certificate[array.size()];

        for (int i = 0; i < ret.length; i++) {
            ret[i] = array.get(i);
            if (log.isTraceEnabled()) {
                log.trace("Issuer='" + CertTools.getIssuerDN(ret[i]) + "'.");
                log.trace("Subject='" + CertTools.getSubjectDN(ret[i]) + "'.");
            }
        }
        if (log.isTraceEnabled()) {
            log.trace("<getCertChain: alias='" + privateKeyAlias + "', retlength=" + ret.length);
        }
        return ret;
    } // getCertChain

    /**
     * create the subject key identifier.
     *
     * @param pubKey
     *            the public key
     *
     * @return SubjectKeyIdentifer asn.1 structure
     */
    public static SubjectKeyIdentifier createSubjectKeyId(final PublicKey pubKey) {
        try {
            final ASN1Sequence keyASN1Sequence;
            try( final ASN1InputStream pubKeyAsn1InputStream = new ASN1InputStream(new ByteArrayInputStream(pubKey.getEncoded())); ) {
                final Object keyObject = pubKeyAsn1InputStream.readObject();
                if (keyObject instanceof ASN1Sequence) {
                    keyASN1Sequence = (ASN1Sequence) keyObject;
                } else {
                    // PublicKey key that doesn't encode to a ASN1Sequence. Fix this by creating a BC object instead.
                    final PublicKey altKey = (PublicKey) KeyFactory.getInstance(pubKey.getAlgorithm(), CryptoProviderTools.getProviderNameFromAlg(pubKey.getAlgorithm())).translateKey(pubKey);
                    try ( final ASN1InputStream altKeyAsn1InputStream = new ASN1InputStream(new ByteArrayInputStream(altKey.getEncoded())) ) {
                        keyASN1Sequence = (ASN1Sequence) altKeyAsn1InputStream.readObject();
                    }
                }
                X509ExtensionUtils x509ExtensionUtils = new BcX509ExtensionUtils();
                return x509ExtensionUtils.createSubjectKeyIdentifier(SubjectPublicKeyInfo.getInstance(keyASN1Sequence));
            }
        } catch (Exception e) {
            final RuntimeException e2 = new RuntimeException("error creating key"); // NOPMD
            e2.initCause(e);
            throw e2;
        }
    }

    /**
     * Sign provided data with specified private key and algortihm
     *
     * @param privateKey
     *            the private key
     * @param signatureAlgorithm a valid signature algorithm such as AlgorithmConstants.SIGALG_SHA256_WITH_RSA
     * @param data
     *            the data to sign
     * @return the signature
     * @throws NoSuchProviderException if BouncyCastleProvider is not installed
     */
    public static byte[] signData(final PrivateKey privateKey, final String signatureAlgorithm, final byte[] data) throws SignatureException,
            NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {
        final Signature signer = Signature.getInstance(signatureAlgorithm, CryptoProviderTools.getProviderNameFromAlg(privateKey.getAlgorithm()));
        signer.initSign(privateKey);
        signer.update(data);
        return (signer.sign());
    }

    /**
     * Verify signed data with specified public key, algorith and signature
     *
     * @param publicKey
     *            the public key
     * @param signatureAlgorithm a valid signature algorithm
     * @param data
     *            the data to verify
     * @param signature
     *            the signature
     * @return true if the signature is ok
     * @throws NoSuchProviderException if BouncyCastleProvider is not installed
     */
    public static boolean verifyData(final PublicKey publicKey, final String signatureAlgorithm, final byte[] data, final byte[] signature)
            throws SignatureException, NoSuchAlgorithmException, InvalidKeyException, NoSuchProviderException {
        final Signature signer = Signature.getInstance(signatureAlgorithm, CryptoProviderTools.getProviderNameFromAlg(publicKey.getAlgorithm()));
        signer.initVerify(publicKey);
        signer.update(data);
        return (signer.verify(signature));

    }
    /**
     * Testing a key pair to verify that it is possible to first sign and then verify with it.
     *
     * @param priv
     *            private key to sign a string with
     * @param pub
     *            public key to verify the signature with
     * @param sProvider
     *            A provider used for signing with the private key, or null if "BC" should be used.
     *
     * @throws InvalidKeyException
     *             if the public key can not be used to verify a string signed by the private key, because the key is wrong or the signature operation
     *             fails for other reasons such as a NoSuchAlgorithmException or SignatureException.
     *             if the provider is not installed.
     */
    public static void testKey(final PrivateKey priv, final PublicKey pub, final String sProvider) throws InvalidKeyException { // NOPMD:this is not a junit test
        final byte input[] = "Lillan gick pa vagen ut, motte dar en katt...".getBytes();
        final byte signBV[];
        final String testSigAlg;
        try {
            if (log.isDebugEnabled()) {
                final StringWriter sw = new StringWriter();
                try( final PrintWriter pw = new PrintWriter(sw) ) {
                    pw.println("Testing a key:");
                    pw.println(String.format("\tTesting keys with algorithm: %s", pub.getAlgorithm()));
                    pw.println(String.format("\tprovider: %s", sProvider));
                    pw.println(String.format("\tprivateKey: %s", priv));
                    pw.println(String.format("\tprivateKey class: %s", priv.getClass().getName()));
                    pw.println(String.format("\tpublicKey: %s", pub));
                    pw.println(String.format("\tpublicKey class: %s", pub.getClass().getName()));
                    pw.flush();
                }
                log.debug(sw.toString());
            }
            {
                // Candidate algorithms. The first working one will be selected by SignWithWorkingAlgorithm
                final List<String> availableSignAlgorithms = AlgorithmTools.getSignatureAlgorithms(pub);
                final String sigProvName;
                if (BouncyCastleProvider.PROVIDER_NAME.equals(sProvider)) {
                    sigProvName = CryptoProviderTools.getProviderNameFromAlg(pub.getAlgorithm());
                } else {
                    sigProvName = sProvider;
                }
                signBV = AnyAvailableAlgorithmSigner.INSTANCE.signData(sigProvName, availableSignAlgorithms, priv, input);
                testSigAlg = AnyAvailableAlgorithmSigner.INSTANCE.getStoredAlgorithm(sigProvName, availableSignAlgorithms);
                if (signBV == null) {
                    throw new InvalidKeyException(ERROR_MESSAGE_SIGNING_FAILED);
                }
                if (log.isDebugEnabled()) {
                    log.debug("Created signature of size: " + signBV.length);
                    log.debug("Created signature: " + new String(Hex.encode(signBV)));
                }
            }
            {
                final Signature signature;
                final String provider = CryptoProviderTools.getProviderNameFromAlg(testSigAlg);
                try {
                    signature = Signature.getInstance(testSigAlg, provider);
                } catch (NoSuchProviderException | NoSuchAlgorithmException e) {
                    throw new IllegalStateException(provider + " was not found as a provider.", e);
                }
                signature.initVerify(pub);
                signature.update(input);
                if (!signature.verify(signBV)) {
                    throw new InvalidKeyException(ERROR_MESSAGE_VERIFICATION_FAILED);
                }
            }
        } catch (InvalidKeyException e) {
            throw e;
        } catch (SignatureException e) {
            throw new InvalidKeyException(String.format("Exception testing key: %s", e.getMessage()), e);
        }
    }
    /**
     * Testing an encrypt de-crypt- only key pair by performing an encrypt and de-crypt operations.
     * @param pubKey public key used for encryption
     * @param privKey private key used for de-cryption
     * @param provider provider
     * @return true if de-crypted message equals original message
     * @throws InvalidKeyException if failing encrypt or de-crypt operation
     */
    public static boolean testEncryptionDecryptionKeys(PublicKey pubKey, PrivateKey privKey, String provider) throws InvalidKeyException {
    	if (log.isDebugEnabled()) {
    		final StringWriter sw = new StringWriter();
    		try( final PrintWriter pw = new PrintWriter(sw) ) {
    			pw.println("Testing a key:");
    			pw.println(String.format("\tTesting keys with algorithm: %s", pubKey.getAlgorithm()));
    			pw.println(String.format("\tprovider: %s", provider));
    			pw.println(String.format("\tprivateKey: %s", privKey));
    			pw.println(String.format("\tprivateKey class: %s", privKey.getClass().getName()));
    			pw.println(String.format("\tpublicKey: %s", pubKey));
    			pw.println(String.format("\tpublicKey class: %s", pubKey.getClass().getName()));
    			pw.flush();
    		}
    		log.debug(sw.toString());
    	}
    	//ENCRYPT
    	//Message to be encrypted...
    	final String varArLillan = "Lillan ar borta...";
    	CMSEnvelopedData cMSEnvelopedData = null;
    	final CMSEnvelopedDataGenerator cMSEDGenerator = new CMSEnvelopedDataGenerator();
    	final byte[] keyId = KeyTools.createSubjectKeyId(pubKey).getKeyIdentifier();
    	cMSEDGenerator.addRecipientInfoGenerator(new JceKeyTransRecipientInfoGenerator(keyId, pubKey));
    	final JceCMSContentEncryptorBuilder builder = new JceCMSContentEncryptorBuilder(NISTObjectIdentifiers.id_aes256_CBC).setProvider(BouncyCastleProvider.PROVIDER_NAME);
    	try {
    		cMSEnvelopedData = cMSEDGenerator.generate(new CMSProcessableByteArray(varArLillan.getBytes(StandardCharsets.US_ASCII)), builder.build());
    	} catch (CMSException e) {
    		throw new InvalidKeyException(e.getMessage());
    	}
    	//DECRYPT
    	final RecipientInformationStore recipients = cMSEnvelopedData.getRecipientInfos();
    	final RecipientInformation recipient = recipients.getRecipients().iterator().next();
    	final JceKeyTransEnvelopedRecipient rec = new JceKeyTransEnvelopedRecipient(privKey);
    	rec.setProvider(provider);
    	rec.setContentProvider(BouncyCastleProvider.PROVIDER_NAME);
    	rec.setMustProduceEncodableUnwrappedKey(false);
    	String decryptedString = "";
    	try {
    		decryptedString = new String(recipient.getContent(rec), StandardCharsets.US_ASCII);
    	} catch (CMSException e) {
    		throw new InvalidKeyException(e.getMessage());
    	}
    	return varArLillan.equals(decryptedString);
    }

    /**
     * Print parameters of public part of a key.
     *
     * @param publK
     *            the key
     * @param ps
     *            stream to print to.
     */
    public static void printPublicKeyInfo(final PublicKey publK, final PrintStream ps) {
        if (publK instanceof RSAPublicKey) {
            ps.println("RSA key:");
            final RSAPublicKey rsa = (RSAPublicKey) publK;
            ps.println("  modulus: " + rsa.getModulus().toString(16));
            ps.println("  public exponent: " + rsa.getPublicExponent().toString(16));
            return;
        }
        if (publK instanceof ECPublicKey) {
            ps.println("Elliptic curve key:");
            final ECPublicKey ec = (ECPublicKey) publK;
            ps.println("  Named curve: "+AlgorithmTools.getKeySpecification(ec));
            ps.println("  the affine x-coordinate: " + ec.getW().getAffineX().toString(16));
            ps.println("  the affine y-coordinate: " + ec.getW().getAffineY().toString(16));
            return;
        }
        if (publK instanceof DHPublicKey) {
            ps.println("DH key:");
            final DHPublicKey dh = (DHPublicKey) publK;
            ps.println("  the public value y: " + dh.getY().toString(16));
            return;
        }
        if (publK instanceof BCEdDSAPublicKey) {
            ps.println("EdDSA key:");
            final String algo = publK.getAlgorithm();
            final BCEdDSAPublicKey eddsa = (BCEdDSAPublicKey) publK;
            ps.println("  " + algo);
            final String key = org.bouncycastle.util.encoders.Base64.toBase64String(eddsa.getEncoded());
            ps.println("  public key value " + key);
        }
    }

    /**
     * Test if a private key is extractable (could be stored).
     *
     * @param privK
     *            key to test.
     * @return true if the key is extractable.
     */
    public static boolean isPrivateKeyExtractable(final PrivateKey privK) {
        if (privK instanceof RSAPrivateKey) {
            final RSAPrivateKey rsa = (RSAPrivateKey) privK;
            final BigInteger result = rsa.getPrivateExponent();
            return result != null && result.bitLength() > 0;
        }
        if (privK instanceof ECPrivateKey) {
            final ECPrivateKey ec = (ECPrivateKey) privK;
            final BigInteger result = ec.getS();
            return result != null && result.bitLength() > 0;
        }
        if (privK instanceof DHPrivateKey) {
            final DHPrivateKey dh = (DHPrivateKey) privK;
            final BigInteger result = dh.getX();
            return result != null && result.bitLength() > 0;
        }
        if (privK instanceof BCEdDSAPrivateKey) {
            final BCEdDSAPrivateKey ed = (BCEdDSAPrivateKey) privK;
            byte[] result = ed.getEncoded();
            return result != null && result.length > 0;
        }
        return false;
    }

    public static void checkValidKeyLength(String keyspec) throws InvalidKeyException, InvalidAlgorithmParameterException {
        final String keyAlg = keyspecToKeyalg(keyspec);
        final int len;
        if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
            len = Integer.parseInt(keyspec);
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ED25519)) {
            len = 255;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ED448)) {
            len = 448;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_FALCON512)) {
            len = Integer.parseInt(keyspec.substring(6));
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_FALCON1024)) {
            len = Integer.parseInt(keyspec.substring(6));
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLKEM512)) {
            len = Integer.parseInt(keyspec.substring(6));
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLKEM768)) {
            len = Integer.parseInt(keyspec.substring(6));
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLKEM1024)) {
            len = Integer.parseInt(keyspec.substring(6));
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA44_RSA2048_PSS_SHA256)) {
            // The value comes from public key length found in the draft
            // https://www.ietf.org/archive/id/draft-ietf-lamps-pq-composite-sigs-14.html#name-maximum-key-and-signature-s
            len = 1582;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA44_Ed25519_SHA512)) {
            len = 1344;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA44_ECDSA_P256_SHA256)) {
            len = 1377;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_RSA3072_PSS_SHA512)) {
            len = 2350;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_RSA4096_PSS_SHA512)) {
            len = 2478;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_P256_SHA512)) {
            len = 2017;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_P384_SHA512)) {
            len = 2049;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_brainpoolP256r1_SHA512)) {
            len = 2017;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA65_Ed25519_SHA512)) {
            len = 1984;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_RSA3072_PSS_SHA512)) {
            len = 2990;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_RSA4096_PSS_SHA512)) {
            len = 3118;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_P384_SHA512)) {
            len = 2689;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_P521_SHA512)) {
            len = 2725;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_brainpoolP384r1_SHA512)) {
            len = 2689;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA87_Ed448_SHAKE256)) {
            len = 2649;
        } else {
            // Assume it's elliptic curve, ML-DSA or SLH-DSA
            final KeyPair kp = KeyTools.genKeys(keyspec, keyAlg);
            len = KeyTools.getKeyLength(kp.getPublic());
        }
        checkValidKeyLength(keyAlg, len);
    }

    public static void checkValidKeyLength(final PublicKey pk) throws InvalidKeyException {
        final String keyAlg = AlgorithmTools.getKeyAlgorithm(pk);
        final int len = KeyTools.getKeyLength(pk);
        checkValidKeyLength(keyAlg, len);
    }

    public static void checkValidKeyLength(final String keyAlg, final int len) throws InvalidKeyException {
        if (AlgorithmConstants.KEYALGORITHM_ECDSA.equals(keyAlg)) {
            if ((len >= 0) && (len < 224)) {
                final String msg = "ECDSA keys of smaller size than 224 is not allowed for a CA. Requested length was " + len;
                throw new InvalidKeyException(msg);
            }
        } else if (AlgorithmConstants.KEYALGORITHM_RSA.equals(keyAlg)) {
            if (len < 1024) {
                final String msg = "RSA keys of smaller size than 1024 is not allowed for a CA. Requested length was " + len;
                throw new InvalidKeyException(msg);
            }
        }
    }

    public static String keyspecToKeyalg(String keyspec) {
        if (StringUtils.isNumeric(keyspec)) {
            return AlgorithmConstants.KEYALGORITHM_RSA;
        }
        if (keyspec.startsWith(AlgorithmConstants.KEYALGORITHM_RSA)) {
            return AlgorithmConstants.KEYALGORITHM_RSA;
        }
        if (keyspec.equalsIgnoreCase(AlgorithmConstants.KEYALGORITHM_ED25519)) {
            return AlgorithmConstants.KEYALGORITHM_ED25519;
        }
        if (keyspec.equalsIgnoreCase(AlgorithmConstants.KEYALGORITHM_ED448)) {
            return AlgorithmConstants.KEYALGORITHM_ED448;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_FALCON512)) {
            return AlgorithmConstants.KEYALGORITHM_FALCON512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_FALCON1024)) {
            return AlgorithmConstants.KEYALGORITHM_FALCON1024;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLKEM512)) {
            return AlgorithmConstants.KEYALGORITHM_MLKEM512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLKEM768)) {
            return AlgorithmConstants.KEYALGORITHM_MLKEM768;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLKEM1024)) {
            return AlgorithmConstants.KEYALGORITHM_MLKEM1024;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA44)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA44;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA65)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA65;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA87)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA87;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128S)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128S;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128S)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128S;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128F)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128F;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128F)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128F;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192S)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192S;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192S)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192S;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192F)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192F;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192F)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192F;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256S)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256S;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256S)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256S;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256F)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256F;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256F)) {
            return AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256F;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA44_RSA2048_PSS_SHA256)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA44_RSA2048_PSS_SHA256;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA44_Ed25519_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA44_Ed25519_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA44_ECDSA_P256_SHA256)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA44_ECDSA_P256_SHA256;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA65_RSA3072_PSS_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA65_RSA3072_PSS_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA65_RSA4096_PSS_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA65_RSA4096_PSS_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_P256_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_P256_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_P384_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_P384_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_brainpoolP256r1_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA65_ECDSA_brainpoolP256r1_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA65_Ed25519_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA65_Ed25519_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA87_RSA3072_PSS_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA87_RSA3072_PSS_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA87_RSA4096_PSS_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA87_RSA4096_PSS_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_P384_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_P384_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_P521_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_P521_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_brainpoolP384r1_SHA512)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA87_ECDSA_brainpoolP384r1_SHA512;
        }
        if (Strings.CI.startsWith(keyspec, AlgorithmConstants.KEYALGORITHM_MLDSA87_Ed448_SHAKE256)) {
            return AlgorithmConstants.KEYALGORITHM_MLDSA87_Ed448_SHAKE256;
        }

        return AlgorithmConstants.KEYALGORITHM_ECDSA;
    }

    /**
     * Converts a standalone specspec that starts with the keyalg to a short keyspec which
     * is to be used together with a separate "keyalg" value.
     */
    public static String shortenKeySpec(String keyspec) {
        if (keyspec.startsWith(AlgorithmConstants.KEYALGORITHM_RSA)) {
            return keyspec.substring(3);
        }
        return keyspec;
    }

    /**
     * Get the ASN.1 encoded PublicKey as a Java PublicKey Object.
     * @param asn1EncodedPublicKey the ASN.1 encoded PublicKey
     * @return the ASN.1 encoded PublicKey as a Java Object
     */
    public static PublicKey getPublicKeyFromBytes(byte[] asn1EncodedPublicKey) {
        try {
            final SubjectPublicKeyInfo keyInfo = SubjectPublicKeyInfo.getInstance(asn1EncodedPublicKey);
            final AlgorithmIdentifier keyAlg = keyInfo.getAlgorithm();
            final X509EncodedKeySpec xKeySpec = new X509EncodedKeySpec(new DERBitString(keyInfo).getBytes());
            final KeyFactory keyFact = KeyFactory.getInstance(keyAlg.getAlgorithm().getId(), CryptoProviderTools.getProviderNameFromAlg(keyAlg.getAlgorithm().getId()));
            return keyFact.generatePublic(xKeySpec);
        } catch (IOException | NoSuchAlgorithmException | NoSuchProviderException | InvalidKeySpecException | IllegalArgumentException e) {
            log.debug("Unable to decode PublicKey.", e);
        }
        return null;
    }

    public static KeyPair getKeyPairFromPEM(final String pemData) {
        try (PEMParser pemParser = new PEMParser(new StringReader(pemData))) {
            Object obj = pemParser.readObject();
            if (obj instanceof PEMKeyPair) {
                final PEMKeyPair pemKeyPair = (PEMKeyPair) obj;
                final String alg = pemKeyPair.getPrivateKeyInfo().getPrivateKeyAlgorithm().getAlgorithm().getId();
                final JcaPEMKeyConverter keyConverter = new JcaPEMKeyConverter().setProvider(CryptoProviderTools.getProviderNameFromAlg(alg));
                return keyConverter.getKeyPair(pemKeyPair);
            } else {
                final PrivateKeyInfo privInfo = (PrivateKeyInfo)obj;
                final String alg = privInfo.getPrivateKeyAlgorithm().getAlgorithm().getId();
                final JcaPEMKeyConverter keyConverter = new JcaPEMKeyConverter().setProvider(CryptoProviderTools.getProviderNameFromAlg(alg));
                final PrivateKey privKey = keyConverter.getPrivateKey(privInfo);
                if (privKey instanceof EdDSAPrivateKey) {
                    final EdDSAPublicKey edPubKey = ((EdDSAPrivateKey)privKey).getPublicKey();
                    return new KeyPair(edPubKey, privKey);
                } else if (privKey instanceof FalconPrivateKey) {
                    final FalconPublicKey pubKey = ((FalconPrivateKey)privKey).getPublicKey();
                    return new KeyPair(pubKey, privKey);
                } else if (privKey instanceof MLKEMPrivateKey) {
                    final MLKEMPublicKey pubKey = ((MLKEMPrivateKey)privKey).getPublicKey();
                    return new KeyPair(pubKey, privKey);
                } else if (privKey instanceof MLDSAPrivateKey) {
                    final MLDSAPublicKey pubKey = ((MLDSAPrivateKey)privKey).getPublicKey();
                    return new KeyPair(pubKey, privKey);
                } else if (privKey instanceof SLHDSAPrivateKey) {
                    final SLHDSAPublicKey pubKey = ((SLHDSAPrivateKey)privKey).getPublicKey();
                    return new KeyPair(pubKey, privKey);
                }
                throw new IllegalStateException("No known keytype for object " + privKey.getClass().getName());
            }
        } catch (IOException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Gets the public composite key for the PEM
     *
     * @param pemData PEM data to extract from. May contain other types of data as well.
     * @return The CompositeKey object
     */
    public static CompositePublicKey getCompositePublicKeyFromPEM(final byte[] pemData) {
        try {
            KeyFactory keyFact = KeyFactory.getInstance("COMPOSITE", "BC");
            return (CompositePublicKey)keyFact.generatePublic(new X509EncodedKeySpec(pemData));
        } catch (NoSuchAlgorithmException | NoSuchProviderException | InvalidKeySpecException e) {
            throw new IllegalStateException(e);
        }
    }

    /**
     * Extracts the binary data from a PEM of a specified kind, e.g. public key.
     *
     * @param pem PEM data to extract from. May contain other types of data as well.
     * @param beginMarker E.g. CertTools.BEGIN_PUBLIC_KEY
     * @param endMarker E.g. CertTools.END_PUBLIC_KEY
     * @return The first entry of the matching type, or null if it couldn't be parsed.
     */
    public static byte[] getBytesFromPEM(String pem, String beginMarker, String endMarker) {
        final int start = pem.indexOf(beginMarker);
        final int end = pem.indexOf(endMarker, start);
        if (start == -1 || end == -1) {
            log.debug("Could not find "+beginMarker+" and "+endMarker+" lines in PEM");
            return null;
        }

        final String base64 = pem.substring(start + beginMarker.length(), end);
        return Base64.decode(base64.getBytes(StandardCharsets.US_ASCII));
    }

    /**
     * Extracts the binary DER data from a public key file. The file may be either in PEM format
     * or in DER format. In the latter case, the file contents is returned as-is.
     *
     * @param file Data of a PEM or DER file.
     * @return DER encoded public key.
     * @throws CertificateParsingException If the data isn't a public key in either PEM or DER format.
     */
    public static byte[] getBytesFromPublicKeyFile(final byte[] file) throws CertificateParsingException {
        if (file.length == 0) {
            throw new CertificateParsingException("Public key file is empty");
        }
        final String fileText = StandardCharsets.US_ASCII.decode(java.nio.ByteBuffer.wrap(file)).toString();
        final byte[] asn1bytes;
        {
            final byte[] tmpBytes = getBytesFromPEM(fileText, CertTools.BEGIN_PUBLIC_KEY, CertTools.END_PUBLIC_KEY);
            asn1bytes = tmpBytes!=null ? tmpBytes : file; // Assume it's in ASN1 format already if null
        }
        try {
            PublicKeyFactory.createKey(asn1bytes); // Check that it's a valid public key
            return asn1bytes;
        } catch (IOException | IllegalArgumentException e) {
            // It may be that the key is a PQC key. Right now (BC1.72b12) there are two different PublicKeyFactory
            // for standard and PQC keys, in the future it's likely to be merged into a universal one making this code obsolete
            // Try to see if it's a PQC key
            try {
                org.bouncycastle.pqc.crypto.util.PublicKeyFactory.createKey(asn1bytes);
                return asn1bytes;
            } catch (IOException | IllegalArgumentException pq1) {
                // It wasn't PQC either, Ignore and throw the original error
            }
            throw new CertificateParsingException("File is neither a valid PEM nor DER file.", e);
        }
    }

    /** Like {@link #getBytesFromCtLogKey(byte[])} , but allows for missing ----BEGIN... and END lines. */
    public static byte[] getBytesFromCtLogKey(final byte[] file) throws CertificateParsingException {
        try {
            return getBytesFromPublicKeyFile(file);
        } catch (CertificateParsingException originalException) {
            log.debug("Could not parse key as PEM or DER, trying as raw base64.", originalException);
            final byte[] decoded;
            try {
                decoded = Base64.decode(file);
            } catch (DecoderException ignored) {
                log.debug("Public key file is not valid base64");
                throw new CertificateParsingException("Public key could not be parsed as either PEM, DER or base64.", originalException);
            }
            if (decoded == null || decoded.length == 0) {
                log.debug("Decoded base64 data of public key is empty or null");
                throw originalException;
            }
            try {
                PublicKeyFactory.createKey(decoded); // Check that it's a valid public key
                return decoded;
            } catch (IOException | IllegalArgumentException e) {
                final String msg = "The base64 encoded data does not represent a public key.";
                log.debug(msg);
                throw new CertificateParsingException(msg, e);
            }
        }
    }

    /**
     * Returns the modulus of the public key.
     * @param publicKey public key
     * @return modulus of the public key
     */
    public static String getKeyModulus(final PublicKey publicKey) {
        String modulus = null;
        if ( publicKey instanceof RSAPublicKey ) {
            byte[] modulusBytes = ((RSAPublicKey) publicKey).getModulus().toByteArray();
            modulus = new String(Hex.encode(modulusBytes));
        } else if(publicKey instanceof ECPublicKey) {
            byte[] modulusBytesX = ((ECPublicKey)publicKey).getW().getAffineX().toByteArray();
            byte[] modulusBytesY = ((ECPublicKey)publicKey).getW().getAffineY().toByteArray();
            modulus = new String(Hex.encode(modulusBytesX)).concat(new String(Hex.encode(modulusBytesY)));
        }
        return modulus;
    }

    /**
     * Returns the exponent of the public key.
     * @param publicKey public key
     * @return modulus of the public key
     */
    public static String getKeyPublicExponent(final PublicKey publicKey) {
        String exponent = null;
        if ( publicKey instanceof RSAPublicKey ) {
            exponent = ((RSAPublicKey) publicKey).getPublicExponent().toString();
        }
        return exponent;
    }

    /**
     * Generates the SHA256 fingerprint of the given text string.
     * @param text input on what to generate the fingerprint
     * @return SHA256 fingerprint of given input string
     */
    public static String getSha256Fingerprint(String text) {
        byte[] sha256Fingerprint = CertTools.generateSHA256Fingerprint(text.getBytes());
        return new String(Hex.encode(sha256Fingerprint));
    }

    /**
     * Returns the signature of the given JcaPKCS10CertificationRequest.
     * @param certificationRequest BouncyCastle JcaPKCS10CertificationRequest certification request
     * @return signature of given certification request
     */
    public static String getCertificateRequestSignature(JcaPKCS10CertificationRequest certificationRequest) {
        return new String(Hex.encode(certificationRequest.getSignature()));
    }

    /**
     * Detect if "Unlimited Strength" Policy files has bean properly installed.
     *
     * @return true if key strength is limited
     */
    public static boolean isUsingExportableCryptography() {
        boolean returnValue = true;
        try {
            final int keylen = Cipher.getMaxAllowedKeyLength("DES");
            if (log.isDebugEnabled()) {
                log.debug("MaxAllowedKeyLength for DES is: "+keylen);
            }
            if ( keylen == Integer.MAX_VALUE ) {
                returnValue = false;
            }
        } catch (NoSuchAlgorithmException e) {
            // NOPMD
        }
        return returnValue;
    }
}
