/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.keys.token;

import com.keyfactor.CesecoreException;
import com.keyfactor.ErrorCode;


/**
 * An exception thrown when trying to query a key that does not exist in token.
 */
public class NoSuchAliasException extends CesecoreException {

    private static final long serialVersionUID = -3842215043295092531L;
    
    /**
     * Creates a new instance of <code>NoSuchAliasException</code> without detail message.
     */
    public NoSuchAliasException() {
        super();
        super.setErrorCode(ErrorCode.INVALID_KEY);
    }


    /**
     * Constructs an instance of <code>NoSuchAliasException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public NoSuchAliasException(String msg) {
        super(ErrorCode.INVALID_KEY, msg);
    }

    public NoSuchAliasException(Throwable e) {
        super(ErrorCode.INVALID_KEY, e);
    }
    public NoSuchAliasException(String msg, Throwable e) {
        super(ErrorCode.INVALID_KEY, msg, e);
    }

}
