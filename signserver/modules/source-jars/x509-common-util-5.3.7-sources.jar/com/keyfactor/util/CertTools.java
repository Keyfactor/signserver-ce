/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/

package com.keyfactor.util;

import static org.apache.commons.codec.binary.Base64.isBase64;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.math.BigInteger;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.CRL;
import java.security.cert.CRLException;
import java.security.cert.CertPath;
import java.security.cert.CertPathValidator;
import java.security.cert.CertPathValidatorException;
import java.security.cert.CertPathValidatorResult;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateFactory;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.CertificateParsingException;
import java.security.cert.PKIXCertPathChecker;
import java.security.cert.PKIXCertPathValidatorResult;
import java.security.cert.PKIXParameters;
import java.security.cert.TrustAnchor;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.CharUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.bouncycastle.asn1.ASN1Encodable;
import org.bouncycastle.asn1.ASN1Encoding;
import org.bouncycastle.asn1.ASN1IA5String;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.ASN1OctetString;
import org.bouncycastle.asn1.ASN1Primitive;
import org.bouncycastle.asn1.ASN1Sequence;
import org.bouncycastle.asn1.ASN1Set;
import org.bouncycastle.asn1.ASN1TaggedObject;
import org.bouncycastle.asn1.DERBitString;
import org.bouncycastle.asn1.DEROctetString;
import org.bouncycastle.asn1.cms.ContentInfo;
import org.bouncycastle.asn1.edec.EdECObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.Attribute;
import org.bouncycastle.asn1.pkcs.CertificationRequest;
import org.bouncycastle.asn1.pkcs.CertificationRequestInfo;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.RSASSAPSSparams;
import org.bouncycastle.asn1.x500.AttributeTypeAndValue;
import org.bouncycastle.asn1.x500.RDN;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.X500NameBuilder;
import org.bouncycastle.asn1.x500.X500NameStyle;
import org.bouncycastle.asn1.x500.style.IETFUtils;
import org.bouncycastle.asn1.x509.AccessDescription;
import org.bouncycastle.asn1.x509.AuthorityInformationAccess;
import org.bouncycastle.asn1.x509.AuthorityKeyIdentifier;
import org.bouncycastle.asn1.x509.DistributionPointName;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.Extensions;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.GeneralNames;
import org.bouncycastle.asn1.x509.IssuingDistributionPoint;
import org.bouncycastle.asn1.x509.KeyPurposeId;
import org.bouncycastle.asn1.x509.PolicyInformation;
import org.bouncycastle.asn1.x509.PrivateKeyUsagePeriod;
import org.bouncycastle.asn1.x509.SubjectKeyIdentifier;
import org.bouncycastle.asn1.x509.SubjectPublicKeyInfo;
import org.bouncycastle.asn1.x509.X509ObjectIdentifiers;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.cert.CertIOException;
import org.bouncycastle.cert.X509CRLHolder;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.jcajce.JcaX509CRLConverter;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509CertificateHolder;
import org.bouncycastle.cms.CMSAbsentContent;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.jcajce.util.MessageDigestUtils;
import org.bouncycastle.jce.X509KeyUsage;
import org.bouncycastle.jce.provider.BouncyCastleProvider;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.operator.BufferingContentSigner;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.ContentVerifierProvider;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaContentVerifierProviderBuilder;
import org.bouncycastle.pkcs.PKCS10CertificationRequest;
import org.bouncycastle.util.CollectionStore;
import org.bouncycastle.util.Store;
import org.bouncycastle.util.encoders.DecoderException;
import org.bouncycastle.util.encoders.Hex;

import com.keyfactor.util.certificate.CertificateImplementationRegistry;
import com.keyfactor.util.certificate.CertificateWrapper;
import com.keyfactor.util.certificate.DnComponents;
import com.keyfactor.util.certificate.SimpleCertGenerator;
import com.keyfactor.util.crypto.algorithm.AlgorithmConstants;
import com.keyfactor.util.keys.KeyTools;

/**
 * Tools to handle common certificate operations.
 */
public abstract class CertTools {

    private static final Logger log = Logger.getLogger(CertTools.class);

    // Initialize dnComponents
    static {
        DnComponents.getDnObjects(true);
    }
    @Deprecated //Use the equivalent value from DnComponents
    public static final String EMAIL = DnComponents.EMAIL;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String EMAIL1 = DnComponents.EMAIL1;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String EMAIL2 = DnComponents.EMAIL2;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String EMAIL3 = DnComponents.EMAIL3;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String DNS = DnComponents.DNS;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String URI = DnComponents.URI;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String URI1 = DnComponents.URI1;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String URI2 = DnComponents.URI2;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String IPADDR = DnComponents.IPADDR;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String DIRECTORYNAME = DnComponents.DIRECTORYNAME;
    public static final String REGISTEREDID = "registeredID";
    @Deprecated //Use the equivalent value from DnComponents
    public static final String XMPPADDR = DnComponents.XMPPADDR;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String SRVNAME = "srvName";
    @Deprecated //Use the equivalent value from DnComponents
    public static final String FASCN = "fascN";

    @Deprecated //Use the equivalent value from DnComponents
    public static final String KRB5PRINCIPAL = "krb5principal";
    @Deprecated //Use the equivalent value from DnComponents
    public static final String KRB5PRINCIPAL_OBJECTID = DnComponents.KRB5PRINCIPAL_OBJECTID;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String UPN = "upn";
    @Deprecated //Use the equivalent value from DnComponents
    public static final String UPN_OBJECTID = DnComponents.UPN_OBJECTID;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String XMPPADDR_OBJECTID = DnComponents.XMPPADDR_OBJECTID;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String SRVNAME_OBJECTID =  DnComponents.SRVNAME_OBJECTID;
    @Deprecated //Use the equivalent value from DnComponents
    public static final String PERMANENTIDENTIFIER = "permanentIdentifier";
    @Deprecated //Use the equivalent value from DnComponents
    public static final String PERMANENTIDENTIFIER_OBJECTID = DnComponents.PERMANENTIDENTIFIER_OBJECTID;
    @Deprecated //User value fromDnComponents
    public static final String PERMANENTIDENTIFIER_SEP = "/";
    @Deprecated //User value fromDnComponents
    public static final String FASCN_OBJECTID =  DnComponents.FASCN_OBJECTID;

    /** Microsoft altName for windows domain controller guid */
    public static final String GUID = "guid";
    @Deprecated //User value fromDnComponents
    public static final String GUID_OBJECTID = DnComponents.GUID_OBJECTID;
    /** ObjectID for Microsoft Encrypted File System Certificates extended key usage */
    public static final String EFS_OBJECTID = "1.3.6.1.4.1.311.10.3.4";
    /** ObjectID for Microsoft Encrypted File System Recovery Certificates extended key usage */
    public static final String EFSR_OBJECTID = "1.3.6.1.4.1.311.10.3.4.1";
    /** ObjectID for Microsoft Signer of documents extended key usage */
    public static final String MS_DOCUMENT_SIGNING_OBJECTID = "1.3.6.1.4.1.311.10.3.12";
    
    public static final String PRECERT_POISON_EXTENSION_OID = "1.3.6.1.4.1.11129.2.4.3";
    /** Object id id-pkix */
    public static final String id_pkix = "1.3.6.1.5.5.7";
    /** Object id id-kp */
    public static final String id_kp = id_pkix + ".3";
    /** Object id id-pda */
    public static final String id_pda = id_pkix + ".9";
    /**
     * Object id id-pda-dateOfBirth DateOfBirth ::= GeneralizedTime
     */
    public static final String id_pda_dateOfBirth = id_pda + ".1";
    /**
     * Object id id-pda-placeOfBirth PlaceOfBirth ::= DirectoryString
     */
    public static final String id_pda_placeOfBirth = id_pda + ".2";
    /**
     * Object id id-pda-gender Gender ::= PrintableString (SIZE(1)) -- "M", "F", "m" or "f"
     */
    public static final String id_pda_gender = id_pda + ".3";
    /**
     * Object id id-pda-countryOfCitizenship CountryOfCitizenship ::= PrintableString (SIZE (2)) -- ISO 3166 Country Code
     */
    public static final String id_pda_countryOfCitizenship = id_pda + ".4";
    /**
     * Object id id-pda-countryOfResidence CountryOfResidence ::= PrintableString (SIZE (2)) -- ISO 3166 Country Code
     */
    public static final String id_pda_countryOfResidence = id_pda + ".5";
    /** OID used for creating MS Templates certificate extension */
    public static final String OID_MSTEMPLATE = "1.3.6.1.4.1.311.20.2";
    /** OID used for creating Microsoft szOID_NTDS_CA_SECURITY_EXT for ADCS vuln. CVE-2022-26931 */
    public static final String OID_MS_SZ_OID_NTDS_CA_SEC_EXT = "1.3.6.1.4.1.311.25.2";
    /** OID used for creating the ETSI Validity Assured - Short Term certificate extension */
    public static final String OID_VALIDITY_ASSURED_SHORT_TERM = "0.4.0.194121.2.1";
    /** extended key usage OID Intel AMT (out of band) network management */
    public static final String Intel_amt = "2.16.840.1.113741.1.2.3";
    
    /** Object ID for CT (Certificate Transparency) specific extensions */
    public static final String id_ct_redacted_domains = "1.3.6.1.4.1.11129.2.4.6";
    
    public static final String BEGIN_CERTIFICATE_REQUEST = "-----BEGIN CERTIFICATE REQUEST-----";
    public static final String END_CERTIFICATE_REQUEST = "-----END CERTIFICATE REQUEST-----";
    public static final String BEGIN_KEYTOOL_CERTIFICATE_REQUEST = "-----BEGIN NEW CERTIFICATE REQUEST-----";
    public static final String END_KEYTOOL_CERTIFICATE_REQUEST = "-----END NEW CERTIFICATE REQUEST-----";
    public static final String BEGIN_CERTIFICATE = "-----BEGIN CERTIFICATE-----";
    public static final String END_CERTIFICATE = "-----END CERTIFICATE-----";
    public static final  String BEGIN_CERTIFICATE_WITH_NL = "-----BEGIN CERTIFICATE-----\n";
    public static final  String END_CERTIFICATE_WITH_NL    = "\n-----END CERTIFICATE-----\n";
    public static final String BEGIN_PUBLIC_KEY = "-----BEGIN PUBLIC KEY-----";
    public static final String END_PUBLIC_KEY = "-----END PUBLIC KEY-----";
    public static final String BEGIN_PRIVATE_KEY = "-----BEGIN PRIVATE KEY-----";
    public static final String END_PRIVATE_KEY = "-----END PRIVATE KEY-----";
    public static final String BEGIN_X509_CRL_KEY = "-----BEGIN X509 CRL-----";
    public static final String END_X509_CRL_KEY = "-----END X509 CRL-----";
    public static final  String BEGIN_PKCS7  = "-----BEGIN PKCS7-----";
    public static final  String END_PKCS7     = "-----END PKCS7-----";

    /**
     * @deprecated Use {@link DnComponents}.stringToBcX500Name
     */
    @Deprecated
    public static X500Name stringToBcX500Name(final String dn) {
        return DnComponents.stringToBcX500Name(dn);
    }

    /**
     * @deprecated Use {@link DnComponents}.stringToBcX500Name
     */
    @Deprecated
    public static X500Name stringToBcX500Name(final String dn, boolean ldapOrder) {
        return DnComponents.stringToBcX500Name(dn, ldapOrder);
    }

    /**
     * @deprecated Use {@link DnComponents}.stringToBcX500Name
     */
    @Deprecated
    public static X500Name stringToBcX500Name(String dn, final X500NameStyle nameStyle, final boolean ldaporder) {
        return DnComponents.stringToBcX500Name(dn, nameStyle, ldaporder);
    }
    
    /**
     * @deprecated Use {@link DnComponents}.stringToBcX500Name
     */
    @Deprecated
    public static X500Name stringToBcX500Name(String dn, final X500NameStyle nameStyle, final boolean ldaporder, final String[] order) {
        return DnComponents.stringToBcX500Name(dn, nameStyle, ldaporder, order);
    }
    
    /**
     * 
     * @deprecated return DnComponents.stringToBcX500Name
     */
    @Deprecated
    public static X500Name stringToBcX500Name(String dn, final X500NameStyle nameStyle, final boolean ldaporder, final String[] order, final boolean applyLdapToCustomOrder) {
        return DnComponents.stringToBcX500Name(dn, nameStyle, ldaporder, order, applyLdapToCustomOrder);
    }

    /**
     * 
     * @deprecated return DnComponents.stringToUnorderedX500Name
     */
    @Deprecated
    public static X500Name stringToUnorderedX500Name(String dn, final X500NameStyle nameStyle) {
       return DnComponents.stringToUnorderedX500Name(dn, nameStyle);
    }

    /**
     * 
     * @deprecated return DnComponents.getUnescapedPlus
     */
    @Deprecated
    public static String getUnescapedPlus(final String value) {
        return DnComponents.getUnescapedPlus(value);
    }
    
    /**
     * Simple methods that returns the signature algorithm value from the certificate. Not usable for setting signature algorithms names in EJBCA,
     * only for human presentation.
     *
     * @return Signature algorithm name from the certificate as a human readable string, for example SHA1WithRSA.
     */
    public static String getCertSignatureAlgorithmNameAsString(Certificate cert) {
        final String certSignatureAlgorithm;
        {
            final String certSignatureAlgorithmTmp = CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType())
                    .getCertificateSignatureAlgorithm(cert);
            // Try to make it easier to display some signature algorithms that cert.getSigAlgName() does not have a good string for.
            // We typically don't get here, since the x509cert.getSigAlgName handles id_RSASSA_PSS nowadays, this is old legacy code,
            // only triggered if the resulting signature algorithm returned above is an OID in stead of a sign alg name
            // (i.e. 1.2.840.113549.1.1.10 instead of SHA256WithRSAAndMGF1
            if (certSignatureAlgorithmTmp.equalsIgnoreCase(PKCSObjectIdentifiers.id_RSASSA_PSS.getId()) && cert instanceof X509Certificate) {
                // Figure out the hash algorithm, it's hidden in the Signature Algorithm Parameters when using RSA PSS
                // If we got this value we should have a x509 cert
                final X509Certificate x509cert = (X509Certificate) cert;
                final byte[] params = x509cert.getSigAlgParams();
                // Below code snipped from BC, it's hidden as private/protected methods so we can't use BC directly.
                final RSASSAPSSparams rsaParams = RSASSAPSSparams.getInstance(params);
                String digestName = MessageDigestUtils.getDigestName(rsaParams.getHashAlgorithm().getAlgorithm());
                // This is just to convert SHA-256 into SHA256, while SHA3-256 should remain as it is
                if (digestName.contains("-") && !digestName.startsWith("SHA3")) {
                    digestName = StringUtils.remove(digestName, '-');
                }
                certSignatureAlgorithm = digestName + "withRSAandMGF1";
            } else {
                certSignatureAlgorithm = certSignatureAlgorithmTmp;
            }
        }
        // EdDSA does not work to be translated (JDK11)
        if (certSignatureAlgorithm.equalsIgnoreCase(EdECObjectIdentifiers.id_Ed25519.getId())) {
            return AlgorithmConstants.SIGALG_ED25519;
        }
        if (certSignatureAlgorithm.equalsIgnoreCase(EdECObjectIdentifiers.id_Ed448.getId())) {
            return AlgorithmConstants.SIGALG_ED448;
        }
        // SHA256WithECDSA does not work to be translated in JDK5.
        if (certSignatureAlgorithm.equalsIgnoreCase(X9ObjectIdentifiers.ecdsa_with_SHA256.getId())) {
            return AlgorithmConstants.SIGALG_SHA256_WITH_ECDSA;
        }
        return certSignatureAlgorithm;
    }

    /**
     * @deprecated Use {@link DnComponents}.stringToBCDNString
     */
    @Deprecated
    public static String stringToBCDNString(String dn) {
        return DnComponents.stringToBCDNString(dn);
    }

    /**
     * @deprecated Use {@link DnComponents}.getEmailFromDN
     */
    @Deprecated
    public static List<String> getEmailFromDN(String dn) {
        return DnComponents.getEmailFromDN(dn);
    }

    /**
     * @deprecated Use {@link DnComponents}.getEMailAddress
     */
    @Deprecated
    public static String getEMailAddress(Certificate certificate) {
        return DnComponents.getEMailAddress(certificate);
    }

    /**
     * @deprecated Use {@link DnComponents}.reverseDN
     */
    @Deprecated
    public static String reverseDN(String dn) {
       return DnComponents.reverseDN(dn);
    }

    /**
     * @deprecated Use {@link DnComponents}.isDNReversed
     */
    @Deprecated
    public static boolean isDNReversed(String dn) {
       return DnComponents.isDNReversed(dn);
    } 
    
    /**
     * @deprecated Use {@link DnComponents}.dnHasMultipleComponents instead
     */
    @Deprecated
    public static boolean dnHasMultipleComponents(String dn) {
        return DnComponents.dnHasMultipleComponents(dn);
    }

    /**
     * @deprecated Use {@link DnComponents}.getPartFromDN instead
     */
    @Deprecated
    public static String getPartFromDN(String dn, String dnpart) {
        return DnComponents.getPartFromDN(dn, dnpart);
    }

    /**
     * @deprecated Use {@link DnComponents}.getPartsFromDN instead
     */
    @Deprecated
    public static List<String> getPartsFromDN(String dn, String dnpart) {
        return DnComponents.getPartsFromDN(dn, dnpart);
    }

  
    /**
     * @deprecated User {@link DnComponents}.getCustomOids
     */
    @Deprecated
    public static List<String> getCustomOids(String dn) {
       return DnComponents.getCustomOids(dn);
    }

    /**
     * Gets subject DN in the format we are sure about (BouncyCastle), supporting UTF8.
     * 
     * This method always returns DNs in LDAP order (CN first)
     * 
     * @param cert a certificate of any type supported by EJBCA
     * 
     * @return String containing the subject DN.
     */
    public static String getSubjectDN(final Certificate cert) {
        if (cert == null || CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()) == null) {
            return "";
        } else {
            return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).getSubjectDn(cert);
        }
    }

    /**
     * @deprecated Use {@link DnComponents}.getUnescapedRdnValue
     */
    @Deprecated
    public static String getUnescapedRdnValue(final String value){
        return DnComponents.getUnescapedRdnValue(value);
    }
    
    /**
     * Gets issyer DN in the format we are sure about (BouncyCastle), supporting UTF8.
     * 
     * This method always returns DNs in LDAP order (CN first)
     * 
     * @param cert a certificate of any type supported by EJBCA
     * 
     * @return String containing the issuer DN, or an empty string if the certificate was null
     */
    public static String getIssuerDN(final Certificate cert) {
        if (cert == null || CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()) == null) {
            return "";
        } else {
            return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).getIssuerDn(cert);
        }
    }

    /**
     * Gets Serial number of the certificate.
     * 
     * @param cert Certificate
     * 
     * @return BigInteger containing the certificate serial number. Can be 0 for CVC certificates with alphanumeric serial numbers if the sequence
     *         does not contain any number characters at all.
     * @throws IllegalArgumentException if null input of certificate type is not handled
     */
    public static BigInteger getSerialNumber(Certificate cert) {
        if (cert == null) {
            throw new IllegalArgumentException("Null input");
        }
        return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).getSerialNumber(cert);
    }

    /**
     * Gets a serial number in numeric form, it takes - either a hex encoded integer with length != 5 (x.509 certificate) - 5 letter numeric string
     * (cvc), will convert the number to an int - 5 letter alfanumeric string vi some numbers in it (cvc), will convert the numbers in it to a numeric
     * string (remove the letters) and convert to int - 5 letter alfanumeric string with only letters (cvc), will convert to integer from string with
     * radix 36
     * 
     * @param sernoString
     * @return BigInteger
     */
    public static BigInteger getSerialNumberFromString(String sernoString) {
        if (sernoString == null) {
            throw new IllegalArgumentException("getSerialNumberFromString: sernoString is null");
        }
        BigInteger ret;
        try {
            if (sernoString.length() != 5) {
                // This can not be a CVC certificate sequence, so it must be a hex encoded regular certificate serial number
                ret = new BigInteger(sernoString, 16);
            } else {
                // We try to handle the different cases of CVC certificate sequences, see StringTools.KEY_SEQUENCE_FORMAT
                if (NumberUtils.isCreatable(sernoString)) {
                    ret = NumberUtils.createBigInteger(sernoString);
                } else {
                    // check if input is hexadecimal
                    log.info("getSerialNumber: Sequence is not a numeric string, trying to extract numerical sequence part.");
                    StringBuilder buf = new StringBuilder();
                    for (int i = 0; i < sernoString.length(); i++) {
                        char c = sernoString.charAt(i);
                        if (CharUtils.isAsciiNumeric(c)) {
                            buf.append(c);
                        }
                    }
                    if (buf.length() > 0) {
                    	String result = buf.toString();
                    	//Remove unintended octal or hexadecimal 
                    	if(result.startsWith("0")) {
                    		result = result.substring(1);
                    	} else if(result.startsWith("0x")) {
                    		result = result.substring(2);
                    	}
                        ret = NumberUtils.createBigInteger(result);
                    } else {
                        log.info("getSerialNumber: can not extract numeric sequence part, trying alfanumeric value (radix 36).");
                        if (sernoString.matches("[0-9A-Z]{1,5}")) {
                            int numSeq = Integer.parseInt(sernoString, 36);
                            ret = BigInteger.valueOf(numSeq);
                        } else {
                            log.info("getSerialNumber: Sequence does not contain any numeric parts, returning 0.");
                            ret = BigInteger.valueOf(0);
                        }
                    }
                }
            }
        } catch (NumberFormatException e) {
            // If we can't make the sequence into a serial number big integer, set it to 0
            log.debug("getSerialNumber: NumberFormatException for sequence: " + sernoString);
            ret = BigInteger.valueOf(0);
        }
        return ret;
    }

    /**
     * Gets Serial number of the certificate as a string. For X509 Certificate this means a HEX encoded BigInteger, and for CVC certificate is means
     * the sequence field of the holder reference.
     * <p>
     * For X509 certificates, the value is normalized (uppercase without leading zeros), so there's no need to normalize the returned value.
     * 
     * @param cert Certificate
     * 
     * @return String to be displayed or used in RoleMember objects
     * @throws IllegalArgumentException if input is null or certificate type is not implemented
     */
    public static String getSerialNumberAsString(Certificate cert) {
        if (cert == null) {
            throw new IllegalArgumentException("Certificate was null");
        } else {
            return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).getSerialNumberAsString(cert);
        }
    }

    /**
     * Gets the signature value (the raw signature bits) from the certificate. For an X509 certificate this is the ASN.1 definition which is:
     * signature BIT STRING
     * 
     * @param cert Certificate
     * 
     * @return byte[] containing the certificate signature bits, if cert is null a byte[] of size 0 is returned.
     */
    public static byte[] getSignature(Certificate cert) {
        if (cert == null) {
            return new byte[0];
        } else {
            return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).getSignature(cert);
        }
    }

    /**
     * Gets issuer DN in the format we are sure about (BouncyCastle), supporting UTF8.
     * 
     * This method always returns DNs in LDAP order (CN first)
     * 
     * @param crl an X509 CRL
     * 
     * @return String containing the issuer DN
     */
    public static String getIssuerDN(X509CRL crl) {
        String dn = null;
        try {
            CertificateFactory cf = CertTools.getCertificateFactory();
            X509CRL x509crl = (X509CRL) cf.generateCRL(new ByteArrayInputStream(crl.getEncoded()));
            dn = X500Name.getInstance(CeSecoreNameStyle.INSTANCE, x509crl.getIssuerX500Principal().getEncoded()).toString();
        } catch (CRLException ce) {
            log.error("CRLException: ", ce);
            return null;
        }
        return DnComponents.stringToBCDNString(dn);
    }

    public static Date getNotBefore(Certificate cert) {
        if (cert == null) {
            throw new IllegalArgumentException("getNotBefore: cert is null");
        }
        return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).getNotBefore(cert);
    }

    public static Date getNotAfter(Certificate cert) {
        if (cert == null) {
            throw new IllegalArgumentException("getNotAfter: cert is null");
        }
        return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).getNotAfter(cert);
    }

    /** Returns a CertificateFactory that can be used to create certificates from byte arrays and such.
     * @param provider Security provider that should be used to create certificates, default BC is null is passed.
     * @return CertificateFactory
     */
    public static CertificateFactory getCertificateFactory(final String provider) {
        final String prov;
        if (provider == null) {
            prov = BouncyCastleProvider.PROVIDER_NAME;
        } else {
            prov = provider;
        }
        if (BouncyCastleProvider.PROVIDER_NAME.equals(prov)) {
            CryptoProviderTools.installBCProviderIfNotAvailable();
        }
        try {
            return CertificateFactory.getInstance("X.509", prov);
        } catch (NoSuchProviderException nspe) {
            log.error("NoSuchProvider: ", nspe);
        } catch (CertificateException ce) {
            log.error("CertificateException: ", ce);
        }
        return null;
    }

    public static CertificateFactory getCertificateFactory() {
        return getCertificateFactory(BouncyCastleProvider.PROVIDER_NAME);
    }

   /**
    * Reads certificates in PEM-format from a filename.
    * The stream may contain other things between the different certificates.
    * 
    * @param certFilename filename of the file containing the certificates in PEM-format
    * @return Ordered List of Certificates, first certificate first, or empty List
    * @throws FileNotFoundException if certFile was not found
    * @throws CertificateParsingException if the file contains an incorrect certificate.
    * 
    * @deprecated Use com.keyfactor.util.CertTools.getCertsFromPEM(String, Class<T>) instead
    */
    @Deprecated
   public static List<Certificate> getCertsFromPEM(String certFilename) throws FileNotFoundException, CertificateParsingException {
        return getCertsFromPEM(certFilename, Certificate.class);
    }
    
    /**
     * Reads certificates in PEM-format from a filename.
     * The stream may contain other things between the different certificates.
     * 
     * @param certFilename filename of the file containing the certificates in PEM-format
     * @param returnType a Class specifying the desired return type. Certificate can be used if return type is unknown.
     * 
     * @return Ordered List of Certificates, first certificate first, or empty List
     * @throws FileNotFoundException if certFile was not found
     * @throws CertificateParsingException if the file contains an incorrect certificate.
     */
    public static <T extends Certificate> List<T> getCertsFromPEM(String certFilename, Class<T> returnType) throws FileNotFoundException, CertificateParsingException {
        if (log.isTraceEnabled()) {
            log.trace(">getCertfromPEM: certFilename=" + certFilename);
        }
        final List<T> certs;
        try (final InputStream inStrm = new FileInputStream(certFilename)) {
            certs = getCertsFromPEM(inStrm, returnType);
        } catch (IOException e) {
            throw new IllegalStateException("Failed to close input stream");
        }
        if (log.isTraceEnabled()) {
            log.trace("<getCertfromPEM: certFile=" + certFilename);
        }
        return certs;
    }
    
    /**
     * Reads a CA certificate and its certificate chain by a file. If it is a chain it is a file with multiple PEM encoded certificates.
     * A single certificate is either in PEM or binary format.
     *  
     * @param file the full path of the file.
     * @return a byte array containing one PEM or binary certificate, or all certificates in the chain in PEM format. First is the CA certificate, followed by its certificate chain.
     * @throws FileNotFoundException if the file cannot be found.
     * @throws CertificateParsingException if a certificate could not be parsed.
     * @throws CertificateEncodingException if a certificate cannot be encoded.
     */
    public static final byte[] readCertificateChainAsArrayOrThrow(final String file)
            throws FileNotFoundException, IOException, CertificateParsingException, CertificateEncodingException {
        
        final List<byte[]> cachain = new ArrayList<>();
        try (FileInputStream fis = new FileInputStream(file)) {
            Collection<Certificate> certs = CertTools.getCertsFromPEM(fis, Certificate.class);
            for (Certificate cert : certs) {
                cachain.add(cert.getEncoded());
            }
        } catch (CertificateParsingException e) {
            // It was perhaps not a PEM chain...see if it was a single binary certificate
            byte[] certbytes = FileTools.readFiletoBuffer(file);
            Certificate cert = CertTools.getCertfromByteArray(certbytes, Certificate.class); // check if it is a good cert, decode PEM if it is PEM, etc
            cachain.add(cert.getEncoded());
        }
        
        try (final ByteArrayOutputStream bos = new ByteArrayOutputStream()) {
            for (byte[] bytes : cachain) {
                bos.write(bytes);
            }
            return bos.toByteArray();
        }
    }
    
    public static final List<CertificateWrapper> bytesToListOfCertificateWrapperOrThrow(final byte[] bytes) throws CertificateParsingException {
        Collection<java.security.cert.Certificate> certs = null;
        try {
            certs = CertTools.getCertsFromPEM(new ByteArrayInputStream(bytes), java.security.cert.Certificate.class);
        } catch (CertificateException e) {
            log.debug("Input stream is not PEM certificate(s): "+e.getMessage());
            // See if it is a single binary certificate
            java.security.cert.Certificate cert = CertTools.getCertfromByteArray(bytes, java.security.cert.Certificate.class);
            certs = new ArrayList<>();
            certs.add(cert);
        }
        return EJBTools.wrapCertCollection(certs);
    }

    /**
     * Reads certificates in PEM-format from an InputStream. 
     * The stream may contain other things between the different certificates.
     * 
     * @param certstream the input stream containing the certificates in PEM-format
     * @return Ordered List of Certificates, first certificate first, or empty List
     *
     * @throws CertificateParsingException if the stream contains an incorrect certificate.
     * 
     * @deprecated Use com.keyfactor.util.CertTools.getCertsFromPEM(InputStream, Class<T>) instead. 
     */
    @Deprecated
    public static List<Certificate> getCertsFromPEM(InputStream certstream) throws CertificateParsingException {
        return getCertsFromPEM(certstream, Certificate.class);
    }
    
    /**
     * Reads certificates in PEM-format from an InputStream. 
     * The stream may contain other things between the different certificates.
     * 
     * @param certstream the input stream containing the certificates in PEM-format
     * @param returnType specifies the desired certificate type. Certificate can be used if certificate type is unknown.
     * @return Ordered List of Certificates, first certificate first, or empty List
     * @exception CertificateParsingException if the stream contains an incorrect certificate.
     */
    public static <T extends Certificate> List<T> getCertsFromPEM(InputStream certstream, Class<T> returnType) throws CertificateParsingException {
        if (log.isTraceEnabled()) {
            log.trace(">getCertfromPEM");
        }
        final ArrayList<T> ret = new ArrayList<>();
        String beginKeyTrust = "-----BEGIN TRUSTED CERTIFICATE-----";
        String endKeyTrust = "-----END TRUSTED CERTIFICATE-----";
        try (final BufferedReader bufRdr = new BufferedReader(new InputStreamReader(new SecurityFilterInputStream(certstream)))) {
            while (bufRdr.ready()) {
                final ByteArrayOutputStream ostr = new ByteArrayOutputStream();
                final PrintStream opstr = new PrintStream(ostr);
                String temp;
                while ((temp = bufRdr.readLine()) != null && !(temp.equals(CertTools.BEGIN_CERTIFICATE) || temp.equals(beginKeyTrust))) {
                    continue;
                }
                if (temp == null) {
                    if (ret.isEmpty()) {
                        // There was no certificate in the file
                        throw new CertificateParsingException("Error in " + certstream.toString() + ", missing " + CertTools.BEGIN_CERTIFICATE
                                + " boundary");
                    } else {
                        // There were certificates, but some blank lines or something in the end
                        // anyhow, the file has ended so we can break here.
                        break;
                    }
                }
                while ((temp = bufRdr.readLine()) != null && !(temp.equals(CertTools.END_CERTIFICATE) || temp.equals(endKeyTrust))) {
                    opstr.print(temp);
                }
                if (temp == null) {
                    throw new IllegalArgumentException("Error in " + certstream.toString() + ", missing " + CertTools.END_CERTIFICATE
                            + " boundary");
                }
                opstr.close();

                byte[] certbuf = Base64.decode(ostr.toByteArray());
                ostr.close();
                // Phweeew, were done, now decode the cert from file back to Certificate object
                T cert = getCertfromByteArray(certbuf, returnType);
                ret.add(cert);
            }
        } catch (IOException e) {
            throw new IllegalStateException("Exception caught when attempting to read stream, see underlying IOException", e);
        }
        if (log.isTraceEnabled()) {
            log.trace("<getcertfromPEM:" + ret.size());
        }
        return ret;
    }

    /**
     * Converts a regular array of certificates into an ArrayList, using the provided provided.
     * 
     * @param certs Certificate[] of certificates to convert
     * @param provider provider for example "SUN" or "BC", use null for the default provider (BC)
     * @return An ArrayList of certificates in the same order as the passed in array
     * @throws NoSuchProviderException
     * @throws CertificateException
     */
    public static List<Certificate> getCertCollectionFromArray(Certificate[] certs, String provider) throws CertificateException,
            NoSuchProviderException {
        if (log.isTraceEnabled()) {
            log.trace(">getCertCollectionFromArray: " + provider);
        }
        ArrayList<Certificate> ret = new ArrayList<>();
        String prov = provider;
        if (prov == null) {
            prov = "BC";
        }
        for (Certificate cert : certs) {
            Certificate newcert = getCertfromByteArray(cert.getEncoded(), prov);
            ret.add(newcert);
        }
        if (log.isTraceEnabled()) {
            log.trace("<getCertCollectionFromArray: " + ret.size());
        }
        return ret;
    }

    /**
     * Returns a certificate in PEM-format.
     * 
     * @param certs Collection of Certificate to convert to PEM
     * @return byte array containing PEM certificate
     * @exception CertificateException if the stream does not contain a correct certificate.
     * 
     * @deprecated Since 6.0.0, use com.keyfactor.util.CertTools.getPemFromCertificateChain(Collection<Certificate>) instead
     */
    @Deprecated
    public static byte[] getPEMFromCerts(Collection<Certificate> certs) throws CertificateException {
        return getPemFromCertificateChain(certs);
    }

    /**
     * Returns a certificate in PEM-format.
     * 
     * @param certs Collection of Certificate to convert to PEM
     * @return byte array containing PEM certificate
     * @throws CertificateEncodingException if an encoding error occurred
     */
    public static byte[] getPemFromCertificateChain(Collection<Certificate> certs) throws CertificateEncodingException  {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try ( final PrintStream printStream = new PrintStream(baos) ) {
            for (final Certificate certificate : certs) {
                if (certificate != null) {
                    printStream.println("Subject: " + CertTools.getSubjectDN(certificate));
                    printStream.println("Issuer: " + CertTools.getIssuerDN(certificate));
                    writeAsPemEncoded(printStream, certificate.getEncoded(), BEGIN_CERTIFICATE, END_CERTIFICATE);                    
                }
            }
        }
        return baos.toByteArray();
    }
    
    /**
     * Returns a certificate in PEM-format without explanatory text.
     *
     * @param certificate a Certificate to convert to PEM
     * @return string containing the PEM certificate
     * @throws CertificateEncodingException if an encoding error occurred
     */
    public static String getPemFromCertificate(final Certificate certificate) throws CertificateEncodingException {
        byte[] enccert = certificate.getEncoded();
        byte[] b64cert = Base64.encode(enccert);
        String out = BEGIN_CERTIFICATE_WITH_NL;
        out += new String(b64cert);
        out += END_CERTIFICATE_WITH_NL;
        return out;
    }

    /**
     * Returns a list of certificates in PEM-format without explanatory text.
     *
     * @param certificates a list of certificates to convert to PEM
     * @return a String containing the list of PEM certificate
     * @throws CertificateEncodingException if an encoding error occurred
     */
    public static String getPemFromCertificates(final List<Certificate> certificates) throws CertificateEncodingException {
        final StringBuilder sb = new StringBuilder();
        for (Certificate certificate : certificates) {
            sb.append(CertTools.BEGIN_CERTIFICATE_WITH_NL).append(new String(Base64.encode(certificate.getEncoded()))).append(CertTools.END_CERTIFICATE_WITH_NL);
        }
        return sb.toString();
    }
    
    /** @return a CRL in PEM-format as a byte array. */
    public static byte[] getPEMFromCrl(byte[] crlBytes) {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try ( final PrintStream printStream = new PrintStream(baos) ) {
            writeAsPemEncoded(printStream, crlBytes, BEGIN_X509_CRL_KEY, END_X509_CRL_KEY);
        }
        return baos.toByteArray();
    }

    /** @return a PublicKey in PEM-format as a byte array. */
    public static byte[] getPEMFromPublicKey(final byte[] publicKeyBytes) {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try ( final PrintStream printStream = new PrintStream(baos) ) {
            writeAsPemEncoded(printStream, publicKeyBytes, BEGIN_PUBLIC_KEY, END_PUBLIC_KEY);
        }
        return baos.toByteArray();
    }

    public static byte[] getPEMFromPrivateKey(final byte[] privateKeyBytes) {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try ( final PrintStream printStream = new PrintStream(baos) ) {
            writeAsPemEncoded(printStream, privateKeyBytes, BEGIN_PRIVATE_KEY, END_PRIVATE_KEY);
        }
        return baos.toByteArray();
    }

    /** @return a PublicKey in PEM-format as a byte array. */
    public static byte[] getPEMFromCertificateRequest(final byte[] certificateRequestBytes) {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try ( final PrintStream printStream = new PrintStream(baos) ) {
            writeAsPemEncoded(printStream, certificateRequestBytes, BEGIN_CERTIFICATE_REQUEST, END_CERTIFICATE_REQUEST);
        }
        return baos.toByteArray();
    }
    
    /** 
     * Generates PEM from binary pkcs#7 data.
     * @param pkcs7Binary pkcs#7 binary data
     * @return a pkcs#7 PEM encoded */
    public static byte[] getPemFromPkcs7(final byte[] pkcs7Binary) {
        final ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try ( final PrintStream printStream = new PrintStream(baos) ) {
            writeAsPemEncoded(printStream, pkcs7Binary, BEGIN_PKCS7, END_PKCS7);
        }
        return baos.toByteArray();
    }

    /** Write the supplied bytes to the printstream as Base64 using beginKey and endKey around it. */
    private static void writeAsPemEncoded(PrintStream printStream, byte[] unencodedData, String beginKey, String endKey) {
        printStream.println(beginKey);
        printStream.println(new String(Base64.encode(unencodedData)));
        printStream.println(endKey);
    }


    /**
     * Creates Certificate from byte[], can be either an X509 certificate or a CVCCertificate
     * 
     * @param cert byte array containing certificate in binary (DER) format, or PEM encoded X.509 certificate
     * @param provider provider for example "SUN" or "BC", use null for the default provider (BC)
     * 
     * @return a Certificate 
     * @throws CertificateParsingException if certificate couldn't be parsed from cert
     * 
     * @deprecated Use com.keyfactor.util.CertTools.getCertfromByteArray(byte[], String, Class<T>) instead. 
     */
    @Deprecated
    public static Certificate getCertfromByteArray(byte[] cert, String provider) throws CertificateParsingException {
        return getCertfromByteArray(cert, provider, Certificate.class);
    }
    
    /**
     * Creates Certificate from byte[], can be either an X509 certificate or a CVCCertificate
     * 
     * @param cert byte array containing certificate in binary (DER) format, or PEM encoded X.509 certificate
     * @param provider provider for example "SUN" or "BC", use null for the default provider (BC)
     * @param returnType the type of Certificate to be returned. Certificate can be used if certificate type is unknown.
     * 
     * @return a Certificate 
     * @throws CertificateParsingException if certificate couldn't be parsed from cert, or if the incorrect return type was specified.
     * 
     */
    public static <T extends Certificate> T getCertfromByteArray(byte[] cert, String provider, Class<T> returnType) throws CertificateParsingException {
        return CertificateImplementationRegistry.INSTANCE.getCertfromByteArray(cert, provider, returnType);
    }
   
    /**
     * 
     * @throws CertificateParsingException if the byte array does not contain a proper certificate.
     * 
     * @deprecated Use com.keyfactor.util.CertTools.getCertfromByteArray(byte[], Class<T>) to specify return type instead.
     */
    @Deprecated
    public static Certificate getCertfromByteArray(byte[] cert) throws CertificateParsingException {
        return getCertfromByteArray(cert, Certificate.class);
    }
    
    /**
     * @param returnType the type of Certificate to be returned, for example X509Certificate.class. Certificate.class can be used if certificate type is unknown.
     * 
     * @throws CertificateParsingException if the byte array does not contain a proper certificate.
     */
    public static <T extends Certificate> T getCertfromByteArray(byte[] cert, Class<T> returnType) throws CertificateParsingException {
        return getCertfromByteArray(cert, BouncyCastleProvider.PROVIDER_NAME, returnType);
    }

    /**
     * Creates X509CRL from byte[].
     * 
     * @param crl byte array containing CRL in DER-format
     * 
     * @return X509CRL
     * 
     * @throws CRLException if the byte array does not contain a correct CRL.
     */
    public static X509CRL getCRLfromByteArray(byte[] crl) throws CRLException {
        log.trace(">getCRLfromByteArray");
        if(crl == null) {
            throw new CRLException("No content in crl byte array");
        }
        CertificateFactory cf = CertTools.getCertificateFactory();
        X509CRL x509crl = (X509CRL) cf.generateCRL(new ByteArrayInputStream(crl));
        log.trace("<getCRLfromByteArray");

        return x509crl;
    } // getCRLfromByteArray
    
    /**
     * Builds a standard CSR from a PKCS#10 request
     * 
     * @param pkcs10CertificationRequest a PKCS#10 request
     * @return a CSR as a string
     */
    public static String buildCsr(final PKCS10CertificationRequest pkcs10CertificationRequest) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(CertTools.BEGIN_CERTIFICATE_REQUEST + "\n");
        try {
            stringBuilder.append(new String(Base64.encode(pkcs10CertificationRequest.getEncoded())));
        } catch (IOException e) {
            throw new IllegalArgumentException("PKCS10 request could not be encoded", e);
        }
        stringBuilder.append("\n" + CertTools.END_CERTIFICATE_REQUEST + "\n");
        return stringBuilder.toString();
    }

    /**
     * Checks if a certificate is self signed by verifying if subject and issuer are the same.
     * 
     * @param cert the certificate that shall be checked.
     * 
     * @return boolean true if the certificate has the same issuer and subject, false otherwise.
     */
    public static boolean isSelfSigned(Certificate cert) {
        if (log.isTraceEnabled()) {
            log.trace(">isSelfSigned: cert: " + CertTools.getIssuerDN(cert) + "\n" + CertTools.getSubjectDN(cert));
        }
        boolean ret = CertTools.getSubjectDN(cert).equals(CertTools.getIssuerDN(cert));
        if (log.isTraceEnabled()) {
            log.trace("<isSelfSigned:" + ret);
        }
        return ret;
    } // isSelfSigned

    /**
     * Checks if a certificate is valid.
     * @param signerCert the certificate to be tested
     * @param warnIfAboutToExpire Also print a WARN log message if the certificate is about to expire. If false, it is still printed at DEBUG level. 
     * @param warnBeforeExpirationTime the interval in which to warn before expiration. Can be set to 0 if warnIfAboutToExpire is set to false
     * @return true if the certificate is valid
     */
    public static boolean isCertificateValid(final X509Certificate certificate, final boolean warnIfAboutToExpire, final long warnBeforeExpirationTime) {
        try {
            certificate.checkValidity();
        } catch (CertificateExpiredException e) {
            if (log.isDebugEnabled()) {
                log.debug("The certificate with serial number '" + certificate.getSerialNumber().toString(16) +"' issued by the CA '" + CertTools.getIssuerDN(certificate) + "' has expired.");                        
            }
            return false;
        } catch (CertificateNotYetValidException e) {
            if (log.isDebugEnabled()) {
                log.debug("The certificate with serial number '" + certificate.getSerialNumber().toString(16) + "' issued by the CA '" + CertTools.getIssuerDN(certificate) + "' is not yet valid.");                                           
            }
            return false;
        }
        //final long warnBeforeExpirationTime = OcspConfiguration.getWarningBeforeExpirationTime();
        if (warnBeforeExpirationTime < 1) {
            return true;
        }
        final Date warnDate = new Date(new Date().getTime() + warnBeforeExpirationTime);
        try {
            certificate.checkValidity(warnDate);
        } catch (CertificateExpiredException e) {
            if (warnIfAboutToExpire || log.isDebugEnabled()) {
                final Level logLevel = warnIfAboutToExpire ? Level.WARN : Level.DEBUG;
                log.log(logLevel, "The certificate with serial number '" + certificate.getSerialNumber().toString(16) + "' issued by the CA '" + CertTools.getIssuerDN(certificate) 
                + "' will expire at '" + certificate.getNotAfter() + "'.");
            }
        } catch (CertificateNotYetValidException e) {
            throw new IllegalStateException("This should never happen.", e);
        }
        if (log.isDebugEnabled()) {
            log.debug("Time for \"certificate will soon expire\" not yet reached. You will be warned after: "
                    + new Date(certificate.getNotAfter().getTime() - warnBeforeExpirationTime));
        }
        return true;
    }

    /**
     * Checks if a certificate is a CA certificate according to BasicConstraints (X.509), or role (CVC). If there is no basic constraints extension on
     * a X.509 certificate, false is returned.
     * 
     * @param cert the certificate that shall be checked.
     * 
     * @return boolean true if the certificate belongs to a CA.
     */
    public static boolean isCA(Certificate cert) {
        return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).isCA(cert);
    }

    /**
     * Is OCSP extended key usage set for a certificate?
     * 
     * @param cert to check.
     * @return true if the extended key usage for OCSP is check
     */
    public static boolean isOCSPCert(X509Certificate cert) {
        final List<String> keyUsages;
        try {
            keyUsages = cert.getExtendedKeyUsage();
        } catch (CertificateParsingException e) {
            return false;
        }
        return keyUsages != null && keyUsages.contains(KeyPurposeId.id_kp_OCSPSigning.getId());
    }

    /**
     * Generate a selfsigned certificate.
     * 
     * @param dn subject and issuer DN
     * @param validity in days
     * @param policyId policy string ('2.5.29.32.0') or null
     * @param privKey private key
     * @param pubKey public key
     * @param sigAlg signature algorithm, you can use one of the contants AlgorithmConstants.SIGALG_XXX
     * @param isCA boolean true or false
     * 
     * @return X509Certificate, self signed
     * 
     * @throws IOException 
     * @throws CertificateException 
     * @throws OperatorCreationException
     *
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genSelfCert(String dn, long validity, String policyId, PrivateKey privKey, PublicKey pubKey, String sigAlg,
            boolean isCA) throws OperatorCreationException, CertificateException  {
        return genSelfCert(dn, validity, policyId, privKey, pubKey, sigAlg, isCA, CryptoProviderTools.getProviderNameFromAlg(sigAlg));
    }

    /** Generates a self signed certificate with keyUsage X509KeyUsage.keyCertSign + X509KeyUsage.cRLSign, i.e. a CA certificate
     * @throws IOException 
     * @throws OperatorCreationException 
     * @throws CertificateParsingException 
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genSelfCert(String dn, long validity, String policyId, PrivateKey privKey, PublicKey pubKey, String sigAlg,
            boolean isCA, String provider, boolean ldapOrder) throws CertificateParsingException, OperatorCreationException {
        final int keyUsage;
        if (isCA) {
            keyUsage = X509KeyUsage.keyCertSign + X509KeyUsage.cRLSign;
        } else {
            keyUsage = 0;
        }
        return genSelfCertForPurpose(dn, validity, policyId, privKey, pubKey, sigAlg, isCA, keyUsage, null, null, provider, ldapOrder);
    } // genselfCert

    /** Generates a self signed certificate with keyUsage X509KeyUsage.keyCertSign + X509KeyUsage.cRLSign, i.e. a CA certificate
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genSelfCert(String dn, long validity, String policyId, PrivateKey privKey, PublicKey pubKey, String sigAlg,
            boolean isCA, String provider) throws OperatorCreationException, CertificateException {
        return genSelfCert(dn, validity, policyId, privKey, pubKey, sigAlg, isCA, provider, true);
    } // genselfCert

    /**
     * Generate a selfsigned certiicate with possibility to specify key usage.
     * 
     * @param dn subject and issuer DN
     * @param validity in days
     * @param policyId policy string ('2.5.29.32.0') or null
     * @param privKey private key
     * @param pubKey public key
     * @param sigAlg signature algorithm, you can use one of the contants AlgorithmConstants.SIGALG_XXX
     * @param isCA boolean true or false
     * @param keyusage as defined by constants in X509KeyUsage
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genSelfCertForPurpose(String dn, long validity, String policyId, PrivateKey privKey, PublicKey pubKey,
            String sigAlg, boolean isCA, int keyusage, boolean ldapOrder) throws CertificateParsingException, OperatorCreationException {
        return genSelfCertForPurpose(dn, validity, policyId, privKey, pubKey, sigAlg, isCA, keyusage, null, null, BouncyCastleProvider.PROVIDER_NAME, ldapOrder);
    }

    /**
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genSelfCertForPurpose(String dn, long validity, String policyId, PrivateKey privKey, PublicKey pubKey,
            String sigAlg, boolean isCA, int keyusage, Date privateKeyNotBefore, Date privateKeyNotAfter, String provider)
            throws CertificateParsingException, OperatorCreationException {
        return genSelfCertForPurpose(dn, validity, policyId, privKey, pubKey, sigAlg, isCA, keyusage, privateKeyNotBefore, privateKeyNotAfter,
                provider, true);
    }

    /**
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genSelfCertForPurpose(String dn, long validity, String policyId, PrivateKey privKey, PublicKey pubKey,
            String sigAlg, boolean isCA, int keyusage, Date privateKeyNotBefore, Date privateKeyNotAfter, String provider, boolean ldapOrder)
            throws CertificateParsingException, OperatorCreationException {
        try {
            return genSelfCertForPurpose(dn, validity, policyId, privKey, pubKey, sigAlg, isCA, keyusage, privateKeyNotBefore, privateKeyNotAfter,
                    provider, ldapOrder, null);
        } catch (CertIOException e) {
          throw new IllegalStateException("CertIOException was thrown due to an invalid extension, but no extensions were provided.", e);
        }
    }

    /**
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genSelfCertForPurpose(String dn, long validity, String policyId, PrivateKey privKey, PublicKey pubKey,
            String sigAlg, boolean isCA, int keyusage, Date privateKeyNotBefore, Date privateKeyNotAfter, String provider, boolean ldapOrder,
            List<Extension> additionalExtensions) throws CertificateParsingException, OperatorCreationException, CertIOException {
        // Create self signed certificate
        Date firstDate = new Date();

        // Set back startdate ten minutes to avoid some problems with wrongly set clocks.
        firstDate.setTime(firstDate.getTime() - (10 * 60 * 1000));

        Date lastDate = new Date();

        // validity in days = validity*24*60*60*1000 milliseconds
        lastDate.setTime(lastDate.getTime() + (validity * (24 * 60 * 60 * 1000)));

        return genSelfCertForPurpose(dn, firstDate, lastDate, policyId, privKey, pubKey, sigAlg, isCA, keyusage, privateKeyNotBefore, privateKeyNotAfter, provider, ldapOrder, additionalExtensions);
    }

    /**
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genSelfCertForPurpose(String dn, Date firstDate, Date lastDate, String policyId, PrivateKey privKey, PublicKey pubKey,
            String sigAlg, boolean isCA, int keyusage, Date privateKeyNotBefore, Date privateKeyNotAfter, String provider, boolean ldapOrder,
            List<Extension> additionalExtensions) throws CertificateParsingException, OperatorCreationException, CertIOException {
        return genCertForPurpose(dn, dn, firstDate, lastDate, policyId, privKey, pubKey, sigAlg, isCA, keyusage, privateKeyNotBefore, privateKeyNotAfter, provider, ldapOrder, additionalExtensions);
    }
    
    /**
     * Get the authority key identifier from a certificate extensions
     * 
     * @param certificate certificate containing the extension
     * @return byte[] containing the authority key identifier, or null if it does not exist
     */
    public static byte[] getAuthorityKeyId(final Certificate certificate) {
        if (certificate != null && certificate instanceof X509Certificate) {
            final ASN1Primitive asn1Sequence = getExtensionValue((X509Certificate) certificate, Extension.authorityKeyIdentifier.getId()); // "2.5.29.35"
            if (asn1Sequence != null) {
                return AuthorityKeyIdentifier.getInstance(asn1Sequence).getKeyIdentifier();
            }
        }
        return null;
    }

    /**
     * Get the subject key identifier from a certificate extensions
     * 
     * @param certificate certificate containing the extension
     * @return byte[] containing the subject key identifier, or null if it does not exist
     */
    public static byte[] getSubjectKeyId(final Certificate certificate) {
        if (certificate != null && certificate instanceof X509Certificate) {
            final ASN1Primitive asn1Sequence = getExtensionValue((X509Certificate) certificate, Extension.subjectKeyIdentifier.getId()); // "2.5.29.14"
            if (asn1Sequence != null) {
                return SubjectKeyIdentifier.getInstance(asn1Sequence).getKeyIdentifier();
            }
        }
        return null;
    }

    /**
     * Get the Authority Key Identifier from CRL extensions
     * 
     * @param crl CRL containing the extension
     * @return byte[] containing the Authority key identifier, or null if it does not exist
     */
    public static byte[] getAuthorityKeyId(final X509CRL crl) {
        final ASN1Primitive asn1Sequence = getDerObjectFromByteArray(crl.getExtensionValue(Extension.authorityKeyIdentifier.getId()));
        if (asn1Sequence != null) {
            return AuthorityKeyIdentifier.getInstance(asn1Sequence).getKeyIdentifier();
        }
        return null;
    }
    
    /**
     * Get a certificate policy ID from a certificate policies extension
     * 
     * @param certificate certificate containing the extension
     * @param pos position of the policy id, if several exist, the first is as pos 0
     * @return String with the certificate policy OID, or null if an id at the given position does not exist
     * @throws IOException if extension can not be parsed
     */
    public static String getCertificatePolicyId(Certificate certificate, int pos) throws IOException {
        if (certificate != null && certificate instanceof X509Certificate) {
            final ASN1Sequence asn1Sequence = ASN1Sequence.getInstance(
                    getExtensionValue((X509Certificate) certificate, Extension.certificatePolicies.getId()));
            if (asn1Sequence != null) {
                // Check the size so we don't ArrayIndexOutOfBounds
                if (asn1Sequence.size() >= pos + 1) {
                    return PolicyInformation.getInstance(asn1Sequence.getObjectAt(pos)).getPolicyIdentifier().getId();
                }
            }
        }
        return null;
    }

    /**
     * Get a list of certificate policy IDs from a certificate policies extension
     * 
     * @param certificate certificate containing the extension
     * @return List of ObjectIdentifiers, or empty list if no policies exist
     * @throws IOException if extension can not be parsed
     */
    public static List<ASN1ObjectIdentifier> getCertificatePolicyIds(Certificate certificate) throws IOException {
        List<ASN1ObjectIdentifier> ret = new ArrayList<>();
        if (certificate != null && certificate instanceof X509Certificate) {
            final ASN1Sequence asn1Sequence = ASN1Sequence.getInstance(
                    getExtensionValue((X509Certificate) certificate, Extension.certificatePolicies.getId()));
            if (asn1Sequence != null) {
                for (ASN1Encodable asn1Encodable : asn1Sequence) {
                    PolicyInformation pi = PolicyInformation.getInstance(asn1Encodable);
                    ret.add(pi.getPolicyIdentifier());
                }
            }
        }
        return ret;
    }

    /**
     * Get a list of certificate policy information from a certificate policies extension
     * 
     * @param certificate certificate containing the extension
     * @return List of PolicyInformation, or empty list if no policies exist
     * @throws IOException if extension can not be parsed
     */
    public static List<PolicyInformation> getCertificatePolicies(Certificate certificate) throws IOException {
        List<PolicyInformation> ret = new ArrayList<>();
        if (certificate != null && certificate instanceof X509Certificate) {
            final ASN1Sequence asn1Sequence = ASN1Sequence.getInstance(
                    getExtensionValue((X509Certificate) certificate, Extension.certificatePolicies.getId()));
            if (asn1Sequence != null) {
                for (ASN1Encodable asn1Encodable : asn1Sequence) {
                    PolicyInformation pi = PolicyInformation.getInstance(asn1Encodable);
                    ret.add(pi);
                }
            }
        }
        return ret;
    }

    /**
     * @deprecated Use {@link DnComponents}.getUPNAltName
     */
    @Deprecated
    public static String getUPNAltName(Certificate cert) throws CertificateParsingException {
        return DnComponents.getUPNAltName(cert);
    }
    

    /**
     * @deprecated Use {@link SimpleCertGenerator} instead.
     */
    @Deprecated
    public static X509Certificate genCertForPurpose(String subjectDn, String issuerDn, Date firstDate, Date lastDate, String policyId, PrivateKey issuerPrivKey, PublicKey entityPubKey,
            String sigAlg, boolean isCA, int keyusage, Date privateKeyNotBefore, Date privateKeyNotAfter, String provider, boolean ldapOrder,
            List<Extension> additionalExtensions) throws CertificateParsingException, OperatorCreationException, CertIOException {
        final SimpleCertGenerator certGen = new SimpleCertGenerator();
        certGen.setSubjectDn(subjectDn);
        certGen.setIssuerDn(issuerDn);
        certGen.setFirstDate(firstDate);
        certGen.setLastDate(lastDate);
        certGen.setPolicyId(policyId);
        certGen.setIssuerPrivKey(issuerPrivKey);
        certGen.setEntityPubKey(entityPubKey);
        certGen.setSignatureAlgorithm(sigAlg);
        certGen.setCa(isCA);
        certGen.setKeyUsage(keyusage);
        certGen.setPrivateKeyNotBefore(privateKeyNotBefore);
        certGen.setPrivateKeyNotAfter(privateKeyNotAfter);
        certGen.setProvider(provider);
        certGen.setLdapOrder(ldapOrder);
        certGen.setAdditionalExtensions(additionalExtensions);
        return certGen.generateCertificate();
    }

    /**
     * @deprecated Use {@link DnComponents}.getUTF8AltNameOtherName
     */
    @Deprecated
    public static String getUTF8AltNameOtherName(final Certificate cert, final String oid) throws CertificateParsingException {
       return DnComponents.getUTF8AltNameOtherName(cert, oid);
    }


    /**
     * @deprecated Use {@link DnComponents}.getPermanentIdentifierAltName
     */
    @Deprecated
    public static String getPermanentIdentifierAltName(Certificate cert) throws CertificateParsingException {
       return DnComponents.getPermanentIdentifierAltName(cert);
    } 


   

    /**
     * @deprecated Use {@link DnComponents}.getGuidAltName
     */
    @Deprecated
    public static String getGuidAltName(Certificate cert) throws CertificateParsingException {
        return DnComponents.getGuidAltName(cert);
    } 

    /**
     * @deprecated Use {@link DnComponents}.getAltNameStringFromExtension
     */
    @Deprecated
    public static String getAltNameStringFromExtension(Extension ext) {
        return DnComponents.getAltNameStringFromExtension(ext);
    }

    /**
     * @deprecated Use {@link DnComponents}.getGeneralNamesFromExtension
     */
    @Deprecated
    public static GeneralNames getGeneralNamesFromExtension(Extension ext) {
        return DnComponents.getGeneralNamesFromExtension(ext);
    }
    
    /**
     * @deprecated Use {@link DnComponents}.getSubjectAlternativeName
     */
    @Deprecated
    public static String getSubjectAlternativeName(Certificate certificate) {
        return DnComponents.getSubjectAlternativeName(certificate);
    }

    /**
     * @deprecated Use {@link DnComponents}.getGeneralNamesFromAltName
     */
    @Deprecated
    public static GeneralNames getGeneralNamesFromAltName(final String altName) {
        return DnComponents.getGeneralNamesFromAltName(altName);
    }

   

    /**
     * @deprecated Use {@link DnComponents}.getGeneralNameString
     */
    @Deprecated
    public static String getGeneralNameString(int tag, ASN1Encodable value) throws IOException {
        return DnComponents.getGeneralNameString(tag, value);
    }

    /**
     * Check the certificate with CA certificate.
     * 
     * @param certificate X.509 certificate to verify. May not be null.
     * @param caCertChain Collection of X509Certificates. May not be null, an empty list or a Collection with null entries.
     * @param date Date to verify at, or null to use current time.
     * @param pkixCertPathCheckers optional PKIXCertPathChecker implementations to use during cert path validation
     * @return true if verified OK
     * @throws CertPathValidatorException if certificate could not be validated
     */
    public static boolean verify(X509Certificate certificate, Collection<X509Certificate> caCertChain, Date date, PKIXCertPathChecker... pkixCertPathCheckers)
            throws CertPathValidatorException {
        if (caCertChain == null || caCertChain.isEmpty()) {
            throw new CertPathValidatorException("Chain is missing.");
        }
        try {
            ArrayList<X509Certificate> certlist = new ArrayList<>();
            // Create CertPath
            certlist.add(certificate);
            // Add other certs...
            CertPath cp = CertificateFactory.getInstance("X.509", BouncyCastleProvider.PROVIDER_NAME).generateCertPath(certlist);
            
            // Create TrustAnchor. Since EJBCA use BouncyCastle provider, we assume
            // certificate already in correct order
            X509Certificate[] cac = caCertChain.toArray(new X509Certificate[caCertChain.size()]);
            TrustAnchor anchor = new TrustAnchor(cac[0], null);
            // Set the PKIX parameters
            PKIXParameters params = new PKIXParameters(Collections.singleton(anchor));
            for (final PKIXCertPathChecker pkixCertPathChecker : pkixCertPathCheckers) {
                params.addCertPathChecker(pkixCertPathChecker);
            }
            params.setRevocationEnabled(false);
            params.setDate(date);
            CertPathValidator cpv = CertPathValidator.getInstance("PKIX", BouncyCastleProvider.PROVIDER_NAME);
            PKIXCertPathValidatorResult result = (PKIXCertPathValidatorResult) cpv.validate(cp, params);
            if (log.isDebugEnabled()) {
            	// TrustAnchor is never null
                log.debug("Certificate verify result by TrustAnchor: " + result.getTrustAnchor().toString());
            }
        } catch (CertPathValidatorException cpve) {
            throw new CertPathValidatorException("Invalid certificate or certificate not issued by specified CA: " + cpve.getMessage());
        } catch (CertificateException e) {
            throw new IllegalArgumentException("Something was wrong with the supplied certificate", e);
        } catch (NoSuchProviderException e) {
            throw new IllegalStateException("BouncyCastle provider not found.", e);
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("Algorithm PKIX was not found.", e);
        } catch (InvalidAlgorithmParameterException e) {
            throw new IllegalArgumentException("Either ca certificate chain was empty, or the certificate was on an inappropraite type for a PKIX path checker.", e);
        }
        return true;
    }
    
    /**
     * Check the certificate with CA certificate.
     * 
     * @param certificate X.509 certificate to verify. May not be null.
     * @param caCertChain Collection of X509Certificates. May not be null, an empty list or a Collection with null entries.
     * @return true if verified OK
     * @throws CertPathValidatorException if verification failed
     */
    public static boolean verify(X509Certificate certificate, Collection<X509Certificate> caCertChain) throws CertPathValidatorException {
        return verify(certificate, caCertChain, null);
    }
    
    /**
     * Check the certificate with a list of trusted certificates.
     * The trusted certificates list can either be end entity certificates, in this case, only this certificate by this issuer 
     * is trusted; or it could be CA certificates, in this case, all certificates issued by this CA are trusted.
     * 
     * @param certificate certificate to verify
     * @param trustedCertificates collection of trusted X509Certificates, empty list trust everything, null trusts nothing.
     * @param pkixCertPathCheckers optional PKIXCertPathChecker implementations to use during cert path validation
     * @return true if verified OK
     */
    public static boolean verifyWithTrustedCertificates(X509Certificate certificate, List< Collection<X509Certificate>> trustedCertificates, PKIXCertPathChecker...pkixCertPathCheckers) {
        
        if(trustedCertificates == null) {
            if(log.isDebugEnabled()) {
                log.debug("Input of trustedCertificates was null. Trusting nothing.");
            }
            return false;
        }
        
        if (trustedCertificates.isEmpty()) {
            if(log.isDebugEnabled()) {
                log.debug("Input of trustedCertificates was empty. Trusting everything.");
            }
            return true;
        }
        
        BigInteger certSN = getSerialNumber(certificate);
        for(Collection<X509Certificate> trustedCertChain : trustedCertificates) {
            X509Certificate trustedCert = trustedCertChain.iterator().next();
            BigInteger trustedCertSN = getSerialNumber(trustedCert);
            if(certSN.equals(trustedCertSN)) {
                // If the serial number of the certificate matches the serial number of a certificate in the list, make sure that it in 
                // fact is the same certificate by verifying that they were issued by the same issuer.
                // Removing this trusted certificate from the trustedCertChain will leave only the CA's certificate chain, which will be 
                // used to verify the issuer.
                if(trustedCertChain.size() > 1) {
                    trustedCertChain.remove(trustedCert);
                }
            }
            try {
                verify(certificate, trustedCertChain, null, pkixCertPathCheckers);
                if(log.isTraceEnabled()) {
                    log.trace("Trusting certificate with SubjectDN '" + getSubjectDN(certificate) + "' and issuerDN '" + getIssuerDN(certificate) + "'.");
                }
                return true;
            } catch (CertPathValidatorException e) {
                //Do nothing. Just try the next trusted certificate chain in the list
            }
            
        }
        return false;
    }

    /**
     * Checks that the given date is within the certificate's validity period. In other words, this determines whether the certificate would be valid
     * at the given date/time.
     * 
     * This utility class is only a helper to get the same behavior as the standard java.security.cert API regardless if using X.509 or CV
     * Certificate.
     * 
     * @param cert certificate to verify, if null the method returns immediately, null does not have a validity to check.
     * @param date the Date to check against to see if this certificate is valid at that date/time.
     * @throws NoSuchFieldException
     * @throws CertificateExpiredException - if the certificate has expired with respect to the date supplied.
     * @throws CertificateNotYetValidException - if the certificate is not yet valid with respect to the date supplied.
     * @see java.security.cert.X509Certificate#checkValidity(Date)
     */
    public static void checkValidity(final Certificate cert, final Date date) throws CertificateExpiredException, CertificateNotYetValidException {
        if (cert != null) {
            CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).checkValidity(cert, date);
        }
    }

    /**
     * Return the first CRL distribution points. The CRL distributions points are URL specified in the certificate extension 
     * CRLDistributionPoints with OID 2.5.29.31.
     * 
     * The CRLDistributionPoints extension contains a sequece of DistributionPoint, which has the following structure:
     * 
     *              DistributionPoint ::= SEQUENCE {
     *                   distributionPoint  [0] DistributionPointName OPTIONAL,
     *                   reasons            [1] ReasonFlags OPTIONAL,
     *                   cRLIssuer          [2] GeneralNames OPTIONAL
     *               }
     *               
     * This method extracts "distributionPoint" (tag 0) from the first DistributionPoint included in the extension. No other 
     * tags are read.
     * 
     * @param certificate
     * @return A URI, or null if no CRL distribution points were found. It is returned as a string, because it is used to
     *         identify a DP and must match exactly (no normalization allowed).
     */
    public static String getCrlDistributionPoint(final Certificate certificate) {
        if(certificate instanceof X509Certificate) {
            final X509Certificate x509cert = (X509Certificate) certificate;
            final Collection<String> cdps = getCrlDistributionPoints(x509cert, true);
            if(!cdps.isEmpty()) {
                return cdps.iterator().next();
            }
        }
        return null;
    }
    
    /**
     * Return a list of CRL distribution points. The CRL distributions points are URIs specified in the certificate extension 
     * CRLDistributionPoints with OID 2.5.29.31.
     * 
     * The CRLDistributionPoints extension contains a sequece of DistributionPoint, which has the following structure:
     * 
     *              DistributionPoint ::= SEQUENCE {
     *                   distributionPoint  [0] DistributionPointName OPTIONAL,
     *                   reasons            [1] ReasonFlags OPTIONAL,
     *                   cRLIssuer          [2] GeneralNames OPTIONAL
     *               }
     *               
     * This method extracts "distributionPoint" (tag 0) from every DistributionPoint included in the extension. No other 
     * tags are read.
     * 
     * @param x509cert
     * @return A list of URIs
     */
    public static List<String> getCrlDistributionPoints(final X509Certificate x509cert) {
        return getCrlDistributionPoints(x509cert, false);
    }

    /**
     * Extracts the URIs from a CRL Issuing Distribution Point extension of a CRL.
     * @param extensionValue Extension value of a CRL Issuing Distribution Point extension
     * @return List of URIs
     */
    public static List<String> getCrlDistributionPoints(final ASN1Primitive extensionValue) {
        return getCrlDistributionPoints(extensionValue, false);
    }

    private static List<String> getCrlDistributionPoints(final X509Certificate x509cert, final boolean onlyfirst) {
        final ASN1Primitive extensionValue = getExtensionValue(x509cert, Extension.cRLDistributionPoints.getId());
        if (extensionValue == null) {
            return Collections.emptyList();
        }
        return getCrlDistributionPoints(extensionValue, onlyfirst);
    }

    private static List<String> getCrlDistributionPoints(final ASN1Primitive extensionValue, final boolean onlyfirst) {
        final ArrayList<String> cdps = new ArrayList<>();
        final ASN1Sequence crlDistributionPoints = ASN1Sequence.getInstance(extensionValue);
        for (int i = 0; i < crlDistributionPoints.size(); i++) {
            final ASN1Sequence distributionPoint = ASN1Sequence.getInstance(crlDistributionPoints.getObjectAt(i));
            for (int j = 0; j < distributionPoint.size(); j++) {
                final ASN1TaggedObject tagged = ASN1TaggedObject.getInstance(distributionPoint.getObjectAt(j));
                if (tagged.getTagNo() == 0) {
                    String url = getStringFromGeneralNames(tagged.getBaseObject().toASN1Primitive());
                    if (url!=null) {
                        try {
                            new URI(url); // Syntax check
                            cdps.add(url);
                        } catch (URISyntaxException e) {
                            if(log.isDebugEnabled()) {
                                log.debug("Error parsing '" + url + "' as a URI. " + e.getLocalizedMessage());
                            }
                        }
                    }
                    if (onlyfirst) {
                        return cdps; // returning only the first URL
                    }
                }
            }
        }
        return cdps;
    }

    /**
     * Return a list of CRL Issuing Distribution Points URIs from a CRL.
     * @see #getCrlDistributionPoints(X509Certificate)
     * @param crl CRL
     * @return A list of URIs
     */
    public static List<String> getCrlDistributionPoints(final X509CRL crl) {
        try {
            final ASN1Primitive extensionValue = getExtensionValue(crl, Extension.issuingDistributionPoint.getId());
            if (extensionValue == null) {
                return Collections.emptyList();
            }
            final IssuingDistributionPoint idp = IssuingDistributionPoint.getInstance(extensionValue);
            final DistributionPointName dpName = idp.getDistributionPoint();
            if (dpName == null || dpName.getType() != DistributionPointName.FULL_NAME) { // Relative names are not implemented
                return Collections.emptyList();
            }
            final ArrayList<String> uris = new ArrayList<>();
            final GeneralNames generalNames = GeneralNames.getInstance(dpName.getName());
            for (final GeneralName generalName : generalNames.getNames()) {
                if (generalName.getTagNo() == GeneralName.uniformResourceIdentifier) {
                    final ASN1IA5String asn1Value = ASN1IA5String.getInstance(generalName.getName());
                    uris.add(asn1Value.getString());
                }
            }
            return uris;
        } catch (IllegalArgumentException e) {
            log.debug("Malformed CRL Issuance Distribution Point", e);
            return Collections.emptyList();
        }
    }

    

    /**
     * This utility method extracts the Authority Information Access Extention's URLs
     * 
     * @param crl a CRL to parse
     * @return the Authority Information Access Extention's URLs, or an empty Collection if none were found
     */
    public static Collection<String> getAuthorityInformationAccess(CRL crl) {
        Collection<String> result = new ArrayList<>();
        if (crl instanceof X509CRL) {
            X509CRL x509crl = (X509CRL) crl;
            ASN1Primitive derObject = getExtensionValue(x509crl, Extension.authorityInfoAccess.getId());
            if (derObject != null) {
                AuthorityInformationAccess authorityInformationAccess = AuthorityInformationAccess.getInstance(derObject);
                AccessDescription[] accessDescriptions = authorityInformationAccess.getAccessDescriptions();
                if (accessDescriptions != null) {
                    for (AccessDescription accessDescription : accessDescriptions) {
                        if (accessDescription.getAccessMethod().equals(X509ObjectIdentifiers.id_ad_caIssuers)) {
                            GeneralName generalName = accessDescription.getAccessLocation();
                            if (generalName.getTagNo() == GeneralName.uniformResourceIdentifier) {
                                // Due to bug in java getting some ASN.1 objects, it can be tagged an extra time...
                                ASN1Primitive obj = generalName.toASN1Primitive();
                                if (obj instanceof ASN1TaggedObject) {
                                    obj = ASN1TaggedObject.getInstance(obj).getBaseObject().toASN1Primitive();
                                }
                                final ASN1IA5String deria5String = ASN1IA5String.getInstance(obj);
                                result.add(deria5String.getString());
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    /**
     * @return all CA issuer URI that are inside AuthorityInformationAccess extension or an empty list
     */
    public static List<String> getAuthorityInformationAccessCAIssuerUris(Certificate cert) {
        return getAuthorityInformationAccessCaIssuerUris(cert, false);
    }
    
    
    /**
     * Returns the first OCSP URL that is inside AuthorityInformationAccess extension, or null.
     * 
     * @param cert is the certificate to parse
     */
    public static String getAuthorityInformationAccessOcspUrl(Certificate cert) {
        Collection<String> urls = getAuthorityInformationAccessOcspUrls(cert);
        if(!urls.isEmpty()) {
            return urls.iterator().next();
        }
        return null;
    }
    
    /**
     * @return all OCSP URL that is inside AuthorityInformationAccess extension or an empty list
     */
    public static List<String> getAuthorityInformationAccessOcspUrls(Certificate cert) {
        return getAuthorityInformationAccessOcspUrls(cert, false);
    }
    
    /**
     * @return all CA issuer URI that are inside AuthorityInformationAccess extension or an empty list.
     */
    private static List<String> getAuthorityInformationAccessCaIssuerUris(Certificate cert, final boolean onlyfirst) {
        final List<String> urls = new ArrayList<>();
        if(cert instanceof X509Certificate) {
            X509Certificate x509cert = (X509Certificate) cert;
            final ASN1Primitive obj = getExtensionValue(x509cert, Extension.authorityInfoAccess.getId());
            if (obj != null) {
                final AccessDescription[] accessDescriptions = AuthorityInformationAccess.getInstance(obj).getAccessDescriptions();
                if (accessDescriptions != null) {
                    for (final AccessDescription accessDescription : accessDescriptions) {
                        // OID 1.3.6.1.5.5.7.48.2: 2 times in Bouncy Castle X509ObjectIdentifiers class.
                        // X509ObjectIdentifiers.id_ad_caIssuers = X509ObjectIdentifiers.crlAccessMethod
                        if (accessDescription.getAccessMethod().equals(X509ObjectIdentifiers.id_ad_caIssuers)) {
                            final GeneralName generalName = accessDescription.getAccessLocation();
                            if (generalName.getTagNo() == GeneralName.uniformResourceIdentifier) {
                                // After encoding in a cert, it is tagged an extra time...
                                ASN1Primitive gnobj = generalName.toASN1Primitive();
                                if (gnobj instanceof ASN1TaggedObject) {
                                    gnobj = ASN1TaggedObject.getInstance(gnobj).getBaseObject().toASN1Primitive();
                                }
                                final ASN1IA5String str = ASN1IA5String.getInstance(gnobj);
                                if(str != null) {
                                    urls.add(str.getString());
                                }
                                if(onlyfirst) {
                                    return urls; // returning only the first URL
                                }
                            }
                        }
                    }
                }
            }
        }
        return urls;
    }
    
    /**
     * @return all OCSP URL that is inside AuthorityInformationAccess extension or an empty list
     */
    private static List<String> getAuthorityInformationAccessOcspUrls(Certificate cert, final boolean onlyfirst) {
        final List<String> urls = new ArrayList<>();
        if(cert instanceof X509Certificate) {
            X509Certificate x509cert = (X509Certificate) cert;
            final ASN1Primitive obj = getExtensionValue(x509cert, Extension.authorityInfoAccess.getId());
            if (obj != null) {
                final AccessDescription[] accessDescriptions = AuthorityInformationAccess.getInstance(obj).getAccessDescriptions();
                if (accessDescriptions != null) {
                    for (final AccessDescription accessDescription : accessDescriptions) {
                        // OID 1.3.6.1.5.5.7.48.1: 2 times in Bouncy Castle X509ObjectIdentifiers class.
                        // X509ObjectIdentifiers.id_ad_ocsp = X509ObjectIdentifiers.ocspAccessMethod
                        if (accessDescription.getAccessMethod().equals(X509ObjectIdentifiers.ocspAccessMethod)) {
                            final GeneralName generalName = accessDescription.getAccessLocation();
                            if (generalName.getTagNo() == GeneralName.uniformResourceIdentifier) {
                                // After encoding in a cert, it is tagged an extra time...
                                ASN1Primitive gnobj = generalName.toASN1Primitive();
                                if (gnobj instanceof ASN1TaggedObject) {
                                    gnobj = ASN1TaggedObject.getInstance(gnobj).getBaseObject().toASN1Primitive();
                                }
                                final ASN1IA5String str = ASN1IA5String.getInstance(gnobj);
                                if(str != null) {
                                    urls.add(str.getString());
                                }
                                if(onlyfirst) {
                                    return urls; // returning only the first URL
                                }
                            }
                        }
                    }
                }
            }
        }
        return urls;
    }
    
    
    /** @return PrivateKeyUsagePeriod extension from a certificate */
    public static PrivateKeyUsagePeriod getPrivateKeyUsagePeriod(final X509Certificate cert) {
        PrivateKeyUsagePeriod res = null;
        final byte[] extvalue = cert.getExtensionValue(Extension.privateKeyUsagePeriod.getId());
        if (extvalue != null && extvalue.length > 0) {
            if (log.isTraceEnabled()) {
                log.trace("Found a PrivateKeyUsagePeriod in the certificate with subject: " + CertTools.getSubjectDN(cert));
            }
            res = PrivateKeyUsagePeriod.getInstance(DEROctetString.getInstance(extvalue).getOctets());
        }
        return res;
    }

    /**
     * 
     * @param cert An X509Certificate
     * @param oid An OID for an extension 
     * @return an Extension ASN1Primitive from a certificate, or null
     */
    public static ASN1Primitive getExtensionValue(X509Certificate cert, String oid) {
        if (cert == null) {
            return null;
        }
        return getDerObjectFromByteArray(cert.getExtensionValue(oid));
    }

    /**
     * 
     * @param crl an X509CRL
     * @param oid An OID for an extension 
     * @return an Extension ASN1Primitive from a CRL
     */
    protected static ASN1Primitive getExtensionValue(X509CRL crl, String oid) {
        if (crl == null || oid == null) {
            return null;
        }
        return getDerObjectFromByteArray(crl.getExtensionValue(oid));
    }

    /** @return the PKCS#10's extension of the specified OID or null if no such extension exists */
    public static Extension getExtension(final PKCS10CertificationRequest pkcs10CertificateRequest, String oid) {
        if (pkcs10CertificateRequest != null && oid != null) {
            final Extensions extensions = getPKCS10Extensions(pkcs10CertificateRequest);
            if (extensions!=null) {
                return extensions.getExtension(new ASN1ObjectIdentifier(oid));
            }
        }
        return null;
    }

    /** @return the first found extensions or null if PKCSObjectIdentifiers.pkcs_9_at_extensionRequest was not present in the PKCS#10 */
    private static Extensions getPKCS10Extensions(final PKCS10CertificationRequest pkcs10CertificateRequest) {
        final Attribute[] attributes = pkcs10CertificateRequest.getAttributes(PKCSObjectIdentifiers.pkcs_9_at_extensionRequest);
        for (final Attribute attribute : attributes) {
            final ASN1Set attributeValues = attribute.getAttrValues();
            if (attributeValues.size()>0) {
                return Extensions.getInstance(attributeValues.getObjectAt(0));
            }
        }
        return null;
    }

    private static ASN1Primitive getDerObjectFromByteArray(byte[] bytes) {
        if (bytes == null) {
            return null;
        }
        try {
            return ASN1Primitive.fromByteArray(ASN1OctetString.getInstance(bytes).getOctets());
        } catch (IOException e) {
            throw new RuntimeException("Caught an unexected IOException", e);
        }
    }

    /**
     * Gets a URI string from a GeneralNames structure.
     * 
     * @param names DER GeneralNames object, that is a sequence of DERTaggedObject
     * @return String with URI if tagNo is 6 (uniformResourceIdentifier), null otherwise
     */
    private static String getStringFromGeneralNames(ASN1Primitive names) {
        final ASN1Sequence namesSequence = ASN1Sequence.getInstance(ASN1TaggedObject.getInstance(names), false);
        if (namesSequence.size() == 0) {
            return null;
        }
        final ASN1TaggedObject taggedObject = ASN1TaggedObject.getInstance(namesSequence.getObjectAt(0));
        if (taggedObject.getTagNo() != GeneralName.uniformResourceIdentifier) { // uniformResourceIdentifier [6] IA5String,
            return null;
        }
        return new String(ASN1OctetString.getInstance(taggedObject, false).getOctets());
    } // getStringFromGeneralNames

    /**
     * Generate SHA1 fingerprint of certificate in string representation.
     * 
     * @param cert Certificate.
     * 
     * @return String containing hex format of SHA1 fingerprint (lower case), or null if input is null.
     */
    public static String getFingerprintAsString(Certificate cert) {
        if (cert == null) {
            return null;
        }
        try {
            byte[] res = generateSHA1Fingerprint(cert.getEncoded());

            return new String(Hex.encode(res));
        } catch (CertificateEncodingException cee) {
            log.error("Error encoding certificate.", cee);
        }

        return null;
    }

    /**
     * Generate SHA1 fingerprint of CRL in string representation.
     * 
     * @param crl X509CRL.
     * 
     * @return String containing hex format of SHA1 fingerprint.
     */
    public static String getFingerprintAsString(X509CRL crl) {
        try {
            byte[] res = generateSHA1Fingerprint(crl.getEncoded());

            return new String(Hex.encode(res));
        } catch (CRLException ce) {
            log.error("Error encoding CRL.", ce);
        }

        return null;
    }

    /**
     * Generate SHA1 fingerprint of byte array in string representation.
     * 
     * @param in byte array to fingerprint.
     * 
     * @return String containing hex format of SHA1 fingerprint.
     */
    public static String getFingerprintAsString(byte[] in) {
        byte[] res = generateSHA1Fingerprint(in);
        return new String(Hex.encode(res));
    }

    /**
     * Generate SHA256 fingerprint of byte array in string representation.
     * 
     * @param in byte array to fingerprint.
     * 
     * @return String containing hex format of SHA256 fingerprint.
     */
    public static String getSHA256FingerprintAsString(byte[] in) {
        byte[] res = generateSHA256Fingerprint(in);
        return new String(Hex.encode(res));
    }

    /**
     * Generate a SHA1 fingerprint from a byte array containing a certificate
     * 
     * @param ba Byte array containing DER encoded Certificate or CRL.
     * 
     * @return Byte array containing SHA1 hash of DER encoded certificate.
     */
    public static byte[] generateSHA1Fingerprint(byte[] ba) {
        // log.trace(">generateSHA1Fingerprint");
        try {
            MessageDigest md = MessageDigest.getInstance("SHA1");
            return md.digest(ba);
        } catch (NoSuchAlgorithmException nsae) {
            log.error("SHA1 algorithm not supported", nsae);
        }
        // log.trace("<generateSHA1Fingerprint");
        return null;
    } // generateSHA1Fingerprint

    /**
     * Generate a SHA256 fingerprint from a byte array containing a certificate
     * 
     * @param ba Byte array containing DER encoded Certificate or CRL.
     * 
     * @return Byte array containing SHA256 hash of DER encoded certificate.
     */
    public static byte[] generateSHA256Fingerprint(byte[] ba) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return md.digest(ba);
        } catch (NoSuchAlgorithmException nsae) {
            log.error("SHA-256 algorithm not supported", nsae);
        }
        return null;
    } // generateSHA256Fingerprint

    /**
     * Generate a MD5 fingerprint from a byte array containing a certificate
     * 
     * @param ba Byte array containing DER encoded Certificate.
     * 
     * @return Byte array containing MD5 hash of DER encoded certificate (raw binary hash).
     */
    public static byte[] generateMD5Fingerprint(byte[] ba) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            return md.digest(ba);
        } catch (NoSuchAlgorithmException nsae) {
            log.error("MD5 algorithm not supported", nsae);
        }

        return null;
    } // generateMD5Fingerprint

    /**
     * Converts Sun Key usage bits to Bouncy castle key usage bits.
     * 
     * @param sku key usage bit fields according to java.security.cert.X509Certificate#getKeyUsage, must be a boolean array of size 9.
     * @return key usage int according to org.bouncycastle.jce.X509KeyUsage#X509KeyUsage, or -1 if input is null.
     * @see java.security.cert.X509Certificate#getKeyUsage
     * @see org.bouncycastle.jce.X509KeyUsage#X509KeyUsage
     */
    public static int sunKeyUsageToBC(boolean[] sku) {
        if (sku == null) {
            return -1;
        }
        int bcku = 0;
        if (sku[0]) {
            bcku = bcku | X509KeyUsage.digitalSignature;
        }
        if (sku[1]) {
            bcku = bcku | X509KeyUsage.nonRepudiation;
        }
        if (sku[2]) {
            bcku = bcku | X509KeyUsage.keyEncipherment;
        }
        if (sku[3]) {
            bcku = bcku | X509KeyUsage.dataEncipherment;
        }
        if (sku[4]) {
            bcku = bcku | X509KeyUsage.keyAgreement;
        }
        if (sku[5]) {
            bcku = bcku | X509KeyUsage.keyCertSign;
        }
        if (sku[6]) {
            bcku = bcku | X509KeyUsage.cRLSign;
        }
        if (sku[7]) {
            bcku = bcku | X509KeyUsage.encipherOnly;
        }
        if (sku[8]) {
            bcku = bcku | X509KeyUsage.decipherOnly;
        }
        return bcku;
    }

    /**
     * Method used to insert a CN postfix into DN by extracting the first found CN appending cnpostfix and then replacing the original CN with the new
     * one in DN.
     * 
     * If no CN could be found in DN then should the given DN be returned untouched
     * 
     * @param dn the DN to manipulate, cannot be null
     * @param cnpostfix the postfix to insert, cannot be null
     * @param nameStyle Controls how the name is encoded. Usually it should be a CeSecoreNameStyle.
     * @return the new DN
     */
    public static String insertCNPostfix(String dn, String cnpostfix, X500NameStyle nameStyle) {
        if (log.isTraceEnabled()) {
            log.trace(">insertCNPostfix: dn=" + dn + ", cnpostfix=" + cnpostfix);
        }
        if (dn == null) {
            return null;
        }
        final RDN[] rdns = IETFUtils.rDNsFromString(dn, nameStyle);
        final X500NameBuilder nameBuilder = new X500NameBuilder(nameStyle);
        boolean replaced = false;
        for (final RDN rdn : rdns) {
            final AttributeTypeAndValue[] attributeTypeAndValues = rdn.getTypesAndValues();
            for (final AttributeTypeAndValue atav : attributeTypeAndValues) {
                if (atav.getType() != null) {
                    final String currentSymbol = CeSecoreNameStyle.DefaultSymbols.get(atav.getType());
                    if (!replaced && "CN".equals(currentSymbol)) {
                        nameBuilder.addRDN(atav.getType(), IETFUtils.valueToString(atav.getValue()) + cnpostfix);
                        replaced = true;
                    } else {
                        nameBuilder.addRDN(atav);
                    }
                }
            }
        }
        final String ret = nameBuilder.build().toString();
        if (log.isTraceEnabled()) {
            log.trace("<reverseDN: " + ret);
        }
        return ret;
    }

    /**
     * @deprecated Use {@link DnComponents}.getX500NameComponents
     */
    @Deprecated
    public static List<String> getX500NameComponents(String dn) {
        return DnComponents.getX500NameComponents(dn);
    }

    /**
     * @deprecated Use {@link DnComponents}.getParentDN
     */
    @Deprecated
    public static String getParentDN(String dn) {
        return DnComponents.getParentDN(dn);
    }

   

   


    /**
     * @deprecated User {@link DnComponents}.getX509FieldOrder
     */
    @Deprecated
    public static List<ASN1ObjectIdentifier> getX509FieldOrder(boolean ldaporder) {
        return DnComponents.getX509FieldOrder(ldaporder);
    }

    /**
     * EJBCA accepts extension OIDs on different formats, e.g. "1.2.3.4" and "1.2.3.4.value".
     * Method returns the OID only given any OID string
     * @param oidString to parse
     * @return String containing OID only or null if no OID was found in the input string
     */
    public static String getOidFromString(final String oidString) {
        String retval = oidString;
        // Matches anything but numerical and dots
        final Pattern pattern = Pattern.compile("[^0-9.]");
        final Matcher matcher = pattern.matcher(oidString);
        if (matcher.find()) {
            int endIndex = matcher.start();
            if (endIndex == 0) {
                return null;
            }
            retval = oidString.substring(0, endIndex-1);
        }
        return retval;
    }
    
    /**
     * Returns the regex match pattern given an OID wildcard.
     * @param oidWildcard wildcard. E.g. 1.2.*.3
     * @return regex match pattern
     */
    public static String getOidWildcardPattern(final String oidWildcard) {
        // First escape all '.' which are interpreted as regex wildcards themselves.
        // Secondly, generate the pattern where '*' is the wildcard character
        final String wildcardMatchPattern = oidWildcard.replaceAll("\\.", "\\\\.").replaceAll("\\*", "([0-9.]*)");
        return wildcardMatchPattern;
    }


    /**
     * Method to create certificate path and to check it's validity from a list of certificates. The list of certificates should only contain one root
     * certificate. The created certificate chain is checked to be valid at the current date and time.
     * 
     * @param certlistin List of certificates to create certificate chain from.
     * @return the certificatepath with the root CA at the end
     * @throws CertPathValidatorException if the certificate chain can not be constructed or validated
     * @throws InvalidAlgorithmParameterException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws CertificateException
     */
    public static List<Certificate> createCertChain(Collection<?> certlistin) throws CertPathValidatorException, InvalidAlgorithmParameterException,
            NoSuchAlgorithmException, NoSuchProviderException, CertificateException {
        return createCertChain(certlistin, new Date());
    }

    /**
     * Method to create certificate path and to check it's validity from a list of certificates. The list of certificates should only contain one root
     * certificate.
     * 
     * @param certlistin List of certificates (X.509, CVC, or other supported) to create certificate chain from.
     * @param now Date to use when checking if the CAs chain is valid.
     * @return the certificate path with the root CA at the end
     * @throws CertPathValidatorException if the certificate chain can not be constructed
     * @throws InvalidAlgorithmParameterException
     * @throws NoSuchProviderException
     * @throws NoSuchAlgorithmException
     * @throws CertificateException
     */
    public static List<Certificate> createCertChain(Collection<?> certlistin, Date now) throws CertPathValidatorException, InvalidAlgorithmParameterException,
            NoSuchAlgorithmException, NoSuchProviderException, CertificateException {
        final List<Certificate> returnval = new ArrayList<>();

        Collection<Certificate> certlist = orderCertificateChain(certlistin);
        // Verify that the chain contains a Root CA certificate
        Certificate rootca = null;
        for(Certificate crt : certlist) {
            if (CertTools.isSelfSigned(crt)) {
                rootca = crt;
            }
        }
        if (rootca == null) {
            throw new CertPathValidatorException("No root CA certificate found in certificate list");
        }

        // set certificate chain
        Certificate rootcert = null;
        ArrayList<Certificate> calist = new ArrayList<>();
        for (Certificate next : certlist) {
            if (CertTools.isSelfSigned(next)) {
                rootcert = next;
            } else {
                calist.add(next);
            }
        }

        if (calist.isEmpty()) {
            // only one root cert, no certchain
            returnval.add(rootcert);
        } else {
            // We need a bit special handling for CV certificates because those can not be handled using a PKIX CertPathValidator
            Certificate test = calist.get(0);
            if (test.getType().equals("CVC")) {
                if (calist.size() == 1) {
                    returnval.add(test);
                    returnval.add(rootcert);
                } else {
                    throw new CertPathValidatorException("CVC certificate chain can not be of length longer than two.");
                }
            } else {
                // Normal X509 certificates
                HashSet<TrustAnchor> trustancors = new HashSet<>();
                TrustAnchor trustanchor = null;
                trustanchor = new TrustAnchor((X509Certificate) rootcert, null);
                trustancors.add(trustanchor);

                // Create the parameters for the validator
                PKIXParameters params = new PKIXParameters(trustancors);

                // Disable CRL checking since we are not supplying any CRLs
                params.setRevocationEnabled(false);
                params.setDate(now);

                // Create the validator and validate the path
                CertPathValidator certPathValidator = CertPathValidator.getInstance(CertPathValidator.getDefaultType(), "BC");
                CertificateFactory fact = CertTools.getCertificateFactory();
                CertPath certpath = fact.generateCertPath(calist);

                CertPathValidatorResult result = certPathValidator.validate(certpath, params);

                // Get the certificates validate in the path
                PKIXCertPathValidatorResult pkixResult = (PKIXCertPathValidatorResult) result;
                returnval.addAll(certpath.getCertificates());

                // Get the CA used to validate this path
                TrustAnchor ta = pkixResult.getTrustAnchor();
                X509Certificate cert = ta.getTrustedCert();
                returnval.add(cert);
            }
        }
        return returnval;
    } // createCertChain

    /**
     * Method ordering a list of certificate (X.509, CVC, or other supported type) into a certificate path with the root CA at the end. Does not check validity or verification of any kind,
     * just ordering by issuerdn.
     * 
     * @param certlist list of certificates to order can be collection of Certificate or byte[] (der encoded certs), must contain a full chain.
     * @return List with certificatechain, Root CA last.
     */
    private static List<Certificate> orderCertificateChain(Collection<?> certlist) throws CertPathValidatorException {
        ArrayList<Certificate> returnval = new ArrayList<>();
        Certificate rootca = null;
        HashMap<String, Certificate> cacertmap = new HashMap<>();
        for(Object possibleCertificate : certlist) {
            Certificate cert = null;
            try {
                cert = (Certificate) possibleCertificate;
            } catch (ClassCastException e) {
                // This was not a certificate, is it byte encoded?
                byte[] certBytes = (byte[]) possibleCertificate;
                try {
                    cert = CertTools.getCertfromByteArray(certBytes);
                } catch (CertificateParsingException e1) {
                    throw new CertPathValidatorException(e1);
                }
            }
            if (CertTools.isSelfSigned(cert)) {
                rootca = cert;
            } else {
                log.debug("Adding to cacertmap with index, issuerDn: '" + CertTools.getIssuerDN(cert) + "'");
                cacertmap.put(CertTools.getIssuerDN(cert), cert);
            }
        }

        if (rootca == null) {
            throw new CertPathValidatorException("No root CA certificate found in certificatelist");
        }
        returnval.add(0, rootca);
        Certificate currentcert = rootca;
        int i = 0;
        while (certlist.size() != returnval.size() && i <= certlist.size()) {
            if (log.isTraceEnabled()) {
                log.trace("Looking in cacertmap for '" + CertTools.getSubjectDN(currentcert) + "'");
            }
            Certificate nextcert = cacertmap.get(CertTools.getSubjectDN(currentcert));
            if (nextcert == null) {
                if(log.isDebugEnabled()) {
                    log.debug("Dumping keys of CA certificate map:");
                    for(String issuerDn : cacertmap.keySet()) {
                        log.debug(issuerDn);
                    }
                }
                throw new CertPathValidatorException("Error building certificate path. Could find certificate with SubjectDN " 
                        + CertTools.getSubjectDN(currentcert) + " in certificate map. See debug log for details.");
            }
            returnval.add(0, nextcert);
            currentcert = nextcert;
            i++;
        }

        if (i > certlist.size()) {
            throw new CertPathValidatorException("Error building certificate path");
        }

        return returnval;
    } // orderCertificateChain

  
    
    /**
     * @return true if the chains are nonempty, contain the same certificates in the same order
     */
    public static boolean compareCertificateChains(Certificate[] chainA, Certificate[] chainB) {
        if (chainA == null || chainB == null) {
            return false;
        }
        if (chainA.length != chainB.length) {
            return false;
        }
        for (int i = 0; i < chainA.length; i++) {
            if (chainA[i] == null || !chainA[i].equals(chainB[i])) {
                return false;
            }
        }
        return true;
    }

    /**
     * Dumps a certificate (cvc or x.509) to string format, suitable for manual inspection/debugging.
     * 
     * @param cert Certificate
     * 
     * @return String with cvc or asn.1 dump.
     */
    public static String dumpCertificateAsString(final Certificate cert) {
        return CertificateImplementationRegistry.INSTANCE.getCertificateImplementation(cert.getType()).dumpCertificateAsString(cert);
    }
    
    /**
     * Creates PKCS10CertificateRequest object from PEM encoded certificate request
     * @param pemEncodedCsr PEM encoded CSR
     * @return PKCS10CertificateRequest object
     */
    public static PKCS10CertificationRequest getCertificateRequestFromPem(final String pemEncodedCsr){
        if(pemEncodedCsr == null){
            return null;
        }
        PKCS10CertificationRequest csr = null;
        final ByteArrayInputStream pemStream = new ByteArrayInputStream(pemEncodedCsr.getBytes(StandardCharsets.UTF_8));
        try (PEMParser pemParser = new PEMParser(new BufferedReader(new InputStreamReader(pemStream)));) {
            final Object parsedObj = pemParser.readObject();
            if (parsedObj instanceof PKCS10CertificationRequest) {
                csr = (PKCS10CertificationRequest) parsedObj;
            }
        } catch (IOException | DecoderException e) {//IOException that will be wrapped as (runtime) DecoderException
            log.info("IOException while decoding certificate request from PEM: " + e.getMessage());
            log.debug("IOException while decoding certificate request from PEM.", e);
        }
        return csr;
    }

    /**
     * Generates a PKCS10CertificationRequest
     * 
     * Code Example:
     * -------------
     * An example of putting AltName and a password challenge in an 'attributes' set (taken from RequestMessageTest.test01Pkcs10RequestMessage() ):
     *       
     *      {@code
     *      // Create a P10 with extensions, in this case altNames with a DNS name
     *      ASN1EncodableVector altnameattr = new ASN1EncodableVector();
     *      altnameattr.add(PKCSObjectIdentifiers.pkcs_9_at_extensionRequest);
     *      // AltNames
     *      GeneralNames san = CertTools.getGeneralNamesFromAltName("dNSName=foo1.bar.com");
     *      ExtensionsGenerator extgen = new ExtensionsGenerator();
     *      extgen.addExtension(Extension.subjectAlternativeName, false, san );
     *      Extensions exts = extgen.generate();
     *      altnameattr.add(new DERSet(exts));
     *    
     *      // Add a challenge password as well
     *      ASN1EncodableVector pwdattr = new ASN1EncodableVector();
     *      pwdattr.add(PKCSObjectIdentifiers.pkcs_9_at_challengePassword); 
     *      ASN1EncodableVector pwdvalues = new ASN1EncodableVector();
     *      pwdvalues.add(new DERUTF8String("foo123"));
     *      pwdattr.add(new DERSet(pwdvalues));
     *    
     *      // Complete the Attribute section of the request, the set (Attributes)
     *      // contains one sequence (Attribute)
     *      ASN1EncodableVector v = new ASN1EncodableVector();
     *      v.add(new DERSequence(altnameattr));
     *      v.add(new DERSequence(pwdattr));
     *      DERSet attributes = new DERSet(v);
     *      }
     * 
     * @param signatureAlgorithm the signature algorithm to sign the CSR.
     * @param subject the request's subject DN.
     * @param publickey the public key of the CSR.
     * @param attributes a set of attributes, for example, extensions, challenge password, etc.
     * @param privateKey the private key used to sign the CSR.
     * @param provider the JCA/JCE provider to use.
     * @return a PKCS10CertificateRequest based on the input parameters.
     * 
     * @throws OperatorCreationException if an error occurred while creating the signing key
     */
    // Should sign with. other private as well!
    public static PKCS10CertificationRequest genPKCS10CertificationRequest(String signatureAlgorithm, X500Name subject, PublicKey publickey,
            ASN1Set attributes, PrivateKey privateKey, String provider) throws OperatorCreationException {

        ContentSigner signer;
        CertificationRequestInfo reqInfo;
        try {
            SubjectPublicKeyInfo pkinfo = SubjectPublicKeyInfo.getInstance(publickey.getEncoded());
            reqInfo = new CertificationRequestInfo(subject, pkinfo, attributes);

            if (provider == null || BouncyCastleProvider.PROVIDER_NAME.equals(provider)) {
                provider = CryptoProviderTools.getProviderNameFromAlg(signatureAlgorithm);
            }
            signer = new BufferingContentSigner(new JcaContentSignerBuilder(signatureAlgorithm).setProvider(provider).build(privateKey), 20480);
            signer.getOutputStream().write(reqInfo.getEncoded(ASN1Encoding.DER));
            signer.getOutputStream().flush();
        } catch (IOException e) {
            throw new IllegalStateException("Unexpected IOException was caught.", e);
        }
        byte[] sig = signer.getSignature();
        DERBitString sigBits = new DERBitString(sig);

        CertificationRequest req = new CertificationRequest(reqInfo, signer.getAlgorithmIdentifier(), sigBits);
        return new PKCS10CertificationRequest(req);
    }

    /**
     * Create a "certs-only" PKCS#7 / CMS from the provided chain.
     * 
     * @param x509CertificateChain chain of certificates with the leaf in the first position and root in the last or just a leaf certificate.
     * @return a byte array containing the CMS
     * @throws CertificateEncodingException if the provided list of certificates could not be parsed correctly
     * @throws CMSException if there was a problem creating the certs-only CMS message
     */
    public static byte[] createCertsOnlyCMS(final List<X509Certificate> x509CertificateChain) throws CertificateEncodingException, CMSException {
        if (log.isTraceEnabled()) {
            final String subjectdn = ( (x509CertificateChain != null && !x509CertificateChain.isEmpty()) ? CertTools.getSubjectDN(x509CertificateChain.get(0)) : "null");  
            log.trace("Creating a certs-only CMS for " + subjectdn);
        }
        final List<JcaX509CertificateHolder> certList = CertTools.convertToX509CertificateHolder(x509CertificateChain);
        final CMSSignedDataGenerator cmsSignedDataGenerator = new CMSSignedDataGenerator();
        cmsSignedDataGenerator.addCertificates(new CollectionStore<>(certList));
        final CMSSignedData cmsSignedData = cmsSignedDataGenerator.generate(new CMSAbsentContent(), true);
        try {
            return cmsSignedData.getEncoded();
        } catch (IOException e) {
            throw new CMSException(e.getMessage());
        }
    }

    /**
     * Generated Generates a ContentVerifierProvider.
     * 
     * @param pubkey
     * @return a JcaContentVerifierProvider. Useful for verifying the signiture in a PKCS10CertificationRequest
     * @throws OperatorCreationException
     */
    public static ContentVerifierProvider genContentVerifierProvider(PublicKey pubkey) throws OperatorCreationException {
        return new JcaContentVerifierProviderBuilder().setProvider(CryptoProviderTools.getProviderNameFromAlg(pubkey.getAlgorithm())).build(pubkey);
    }

    /**
     * @return a Certificate Collection as a X509Certificate list
     * @throws ClassCastException if one of the Certificates in the collection is not an X509Certificate
     */
    public static final List<X509Certificate> convertCertificateChainToX509Chain(final Collection<Certificate> chain) throws ClassCastException {
        final List<X509Certificate> ret = new ArrayList<>();
        for (final Certificate certificate : chain) {
            ret.add((X509Certificate) certificate);
        }
        return ret;
    }
    
    /** @return a X509Certificate Collection as a Certificate list */
    public static final List<Certificate> convertCertificateChainToGenericChain(final Collection<X509Certificate> chain) {
        final List<Certificate> ret = new ArrayList<>();
        for (final Certificate certificate : chain) {
            ret.add(certificate);
        }
        return ret;
    }
    
    /**
     * Converts a X509Certificate chain into a JcaX509CertificateHolder chain.
     * 
     * @param certificateChain input chain to be converted
     * @return the result
     * @throws CertificateEncodingException if there is a problem extracting the certificate information.
     */
    public static final JcaX509CertificateHolder[] convertToX509CertificateHolder(X509Certificate[] certificateChain)
            throws CertificateEncodingException {
        final JcaX509CertificateHolder[] certificateHolderChain = new JcaX509CertificateHolder[certificateChain.length];
        for (int i = 0; i < certificateChain.length; ++i) {
            certificateHolderChain[i] = new JcaX509CertificateHolder(certificateChain[i]);
        }
        return certificateHolderChain;
    }
    
    /**
     * Converts a X509Certificate chain into a JcaX509CertificateHolder chain.
     * 
     * @param certificateChain input chain to be converted
     * @return the result
     * @throws CertificateEncodingException if there is a problem extracting the certificate information.
     */
    public static final List<JcaX509CertificateHolder> convertToX509CertificateHolder(List<X509Certificate> certificateChain)
            throws CertificateEncodingException {
        final List<JcaX509CertificateHolder> certificateHolderChain = new ArrayList<>();
        for (X509Certificate certificate : certificateChain) {
            certificateHolderChain.add( new JcaX509CertificateHolder(certificate));
        }
        return certificateHolderChain;
    }

    /**
     * Converts a X509CertificateHolder chain into a X509Certificate chain.
     * 
     * @param certificateHolderChain input chain to be converted
     * @return the result
     * @throws CertificateException if there is a problem extracting the certificate information.
     */
    public static final List<X509Certificate> convertToX509CertificateList(Collection<X509CertificateHolder> certificateHolderChain) throws CertificateException {
        final List<X509Certificate> ret = new ArrayList<>();
        final JcaX509CertificateConverter jcaX509CertificateConverter = new JcaX509CertificateConverter();
        for (final X509CertificateHolder certificateHolder : certificateHolderChain) {
            ret.add(jcaX509CertificateConverter.getCertificate(certificateHolder));
        }
        return ret;
    }

    /**
     * Converts a X509CertificateHolder chain into a X509Certificate chain.
     * 
     * @param certificateHolderChain input chain to be converted
     * @return the result
     * @throws CertificateException if there is a problem extracting the certificate information.
     */
    public static final X509Certificate[] convertToX509CertificateArray(Collection<X509CertificateHolder> certificateHolderChain) throws CertificateException {
        return convertToX509CertificateList(certificateHolderChain).toArray(new X509Certificate[0]);
    }

    /**
     * Converts a X509CertificateHolder chain into a X509Certificate chain.
     * 
     * @param crlHolders input chain to be converted
     * @return the result
     * @throws CRLException if there is a problem extracting the CRL information.
     */
    public static final List<X509CRL> convertToX509CRLList(Collection<X509CRLHolder> crlHolders) throws CRLException {
        final List<X509CRL> ret = new ArrayList<>();
        final JcaX509CRLConverter jcaX509CRLConverter = new JcaX509CRLConverter();
        for (final X509CRLHolder crlHolder : crlHolders) {
            ret.add(jcaX509CRLConverter.getCRL(crlHolder));
        }
        return ret;
    }

    /**
     * Creates a public key fingerprint with the given digest algorithm and returns it hex encoded. 
     * 
     * @param publicKey the public key.
     * @param algorithm the digest algorithm (i.e. MD-5, SHA-1, SHA-256, etc.)
     * @return the public key fingerprint, hex encoded, or null.
     */
    public static final String createPublicKeyFingerprint(final PublicKey publicKey, final String algorithm) {
        try {
            final MessageDigest digest = MessageDigest.getInstance(algorithm);
            digest.reset();
            digest.update(publicKey.getEncoded());
            final String result = Hex.toHexString(digest.digest());
            if (log.isDebugEnabled()) {
                log.debug("Fingerprint " + result + " created for public key: " + new String(Base64.encode(publicKey.getEncoded())));
            }
            return result;
        } catch (NoSuchAlgorithmException e) {
            log.warn("Could not create fingerprint for public key ", e);
            return null;
        }
    }

    /**
     * Extracted all the certificates from the key store.
     *
     * @param keyStoreBytes key store as byte array.
     * @param keyStoreType the keystore type.
     * @param keyStorePassword keystore password.
     * @return an underlying certificate chain present within the keystore.
     * @throws KeyStoreException if unable to read the key store.
     * @throws CertificateException if unable to get information from the certificate.
     * @throws IOException if unable read the byte array.
     * @throws NoSuchAlgorithmException if an incorrect algorithms is being passed
     */
    public static List<X509Certificate> extractEndEntityCertificateFromKeyStore(byte[] keyStoreBytes, String keyStoreType, String keyStorePassword)
            throws KeyStoreException, CertificateException, IOException, NoSuchAlgorithmException {
        KeyStore keyStore = KeyStore.getInstance(keyStoreType);
        keyStore.load(new ByteArrayInputStream(keyStoreBytes), keyStorePassword.toCharArray());

        String alias = null;
        Iterator<String> aliases = keyStore.aliases().asIterator();
        while (aliases.hasNext()) {
        	String currentAlias = aliases.next();
        	if (!currentAlias.equals(KeyTools.CA_CERT_CHAIN_ALIAS)) {
        		alias = currentAlias;
        		break;
        	}
        }
        
        if (alias == null) {
            throw new IllegalStateException("Keystore does not have end entity certificate");
        }
        
        Certificate[] chain = KeyTools.getCertChain(keyStore, alias);
        if (chain == null) {
            throw new IllegalStateException("Certificate chain appears to be absent");
        }
        return Stream.of(chain)
                .filter(X509Certificate.class::isInstance)
                .map(X509Certificate.class::cast)
                .collect(Collectors.toList());
    }

	/**
	 * @deprecated Use {@link DnComponents}.getCommonNameFromSubjectDn
	 */
    @Deprecated
    public static String getCommonNameFromSubjectDn(String subjectDn) {
        return DnComponents.getCommonNameFromSubjectDn(subjectDn);
    }

    public static Collection<X509CertificateHolder> parseP7B(InputStream is) throws CMSException, IOException {

        final InputStreamReader isr = new InputStreamReader(is);
        final PEMParser parser = new PEMParser(isr);

        final ContentInfo info = (ContentInfo) parser.readObject();
        final CMSSignedData csd = new CMSSignedData(info);
        final Store<X509CertificateHolder> certstore = csd.getCertificates();
        final Collection<X509CertificateHolder> collection = certstore.getMatches(null);

        parser.close();
        return collection;
    }

    private static byte[] getFirstCertificate(Collection<X509CertificateHolder> collection) throws CertificateException {

        if (null != collection) {
            final X509CertificateHolder certholder = collection.iterator().next();
            final X509Certificate x509cert = new JcaX509CertificateConverter().getCertificate(certholder);
            return Base64.encode(x509cert.getEncoded());
        }

        return null;
    }

    public static byte[] getPKCS7Certificate(InputStream is) throws CertificateException, IOException, CMSException {
        final InputStreamReader isr = new InputStreamReader(is);
        try (final PEMParser parser = new PEMParser(isr)) {
            final ContentInfo info = (ContentInfo) parser.readObject();
            final CMSSignedData csd = new CMSSignedData(info);
            return csd.getEncoded();
        }
    }

    public static String getPEMCertificate(Collection<X509CertificateHolder> collection) throws CertificateException {
        final byte[] b64 = CertTools.getFirstCertificate(collection);
        return BEGIN_CERTIFICATE + "\n" + new String(b64) + "\n" + END_CERTIFICATE;
    }

    public static String getPEMCertificate(byte[] bytes) {
        final byte[] b64 = Base64.encode(bytes);
        return BEGIN_CERTIFICATE + "\n" + new String(b64) + "\n" + END_CERTIFICATE;
    }

    public static String getPKCS7PEMCertificate(byte[] bytes) {
        final byte[] b64 = Base64.encode(bytes);
        return BEGIN_PKCS7 + "\n" + new String(b64) + "\n" + END_PKCS7;
    }

    public static byte[] getFirstCertificateFromPKCS7(byte[] pkcs7) throws CMSException, IOException {
        byte[] firstCertificate = null;

        final CMSSignedData csd = new CMSSignedData(pkcs7);
        final Store<X509CertificateHolder> certstore = csd.getCertificates();
        final Collection<X509CertificateHolder> collection = certstore.getMatches(null);

        final Iterator<X509CertificateHolder> ci = collection.iterator();
        if (ci.hasNext()) {
            firstCertificate = ci.next().getEncoded();
        }

        return firstCertificate;
    }

    /**
     * Encapsulates a Base64 string with a CSR header and footer.
     *
     * @param csrBody Base64 CSR
     *
     * @return "-----BEGIN CERTIFICATE REQUEST-----\nBse64\n-----END CERTIFICATE REQUEST-----"
     */
    public static String encapsulateCsr(String csrBody) {
        if (csrBody == null) {
            return null;
        }
        csrBody = csrBody.replace(BEGIN_KEYTOOL_CERTIFICATE_REQUEST, BEGIN_CERTIFICATE_REQUEST)
                .replace(END_KEYTOOL_CERTIFICATE_REQUEST, END_CERTIFICATE_REQUEST);
        if (!csrBody.startsWith(BEGIN_CERTIFICATE_REQUEST) && isBase64(csrBody)) {
            return BEGIN_CERTIFICATE_REQUEST + "\n" + csrBody + "\n" + END_CERTIFICATE_REQUEST;
        }
        return csrBody;
    }
}