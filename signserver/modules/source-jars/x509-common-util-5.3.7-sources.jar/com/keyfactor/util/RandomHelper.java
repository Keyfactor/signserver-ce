package com.keyfactor.util;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.bouncycastle.crypto.digests.SHA512Digest;
import org.bouncycastle.crypto.prng.SP800SecureRandomBuilder;
import org.bouncycastle.util.Strings;

public final class RandomHelper {
	
    private static final Logger log = Logger.getLogger(RandomHelper.class);
    
    /** A registry of instances, to handle multiple algorithms simultaneously. */
    private static Map<String, SecureRandom> randomInstances = new HashMap<>();

    private RandomHelper() {};
    
    /**
     * Creates (if not already existing) a SecureRandom object and returns the object after adding it to the map.
     *
     * @return An instance of the SecureRandom prng.
     */
    public static SecureRandom getInstance(String algorithm) {
    	SecureRandom randomInstance = randomInstances.get(algorithm);
    	// Check if we have this instance...
    	if (randomInstance == null) {
    		// We need to update with a new instance
    		synchronized (RandomHelper.class) {
    			randomInstance = randomInstances.get(algorithm);
    			if (randomInstance == null) {
    				randomInstance = getSecureRandomFromAlgorithm(algorithm);
    				randomInstances.put(algorithm, randomInstance);
    			}
    		}
    	}
    	return randomInstance;
    }
	
    /** 
     * Return CSPRNG based on provided algorithm
     * @param algorithm is the algorithm used to create the PRNG
     * @return a SecureRandom CSPRNG
     */
    private static SecureRandom getSecureRandomFromAlgorithm(String algorithm){
    	// SecureRandom provides a cryptographically strong random number generator (CSPRNG).
    	SecureRandom random = null;
    	try {
    		if (StringUtils.equalsIgnoreCase(algorithm, "BCSP800HYBRID")) {
    			// Use a BC hybrid (FIPS/SP800 compliant) DRBG chain.
    			random = createBCSP800Hybrid();
    			log.info("Using FIPS/SP800 compliant Bouncy Castle Hybrid serialNumber RNG algorithm.");
    		} else if (StringUtils.equalsIgnoreCase(algorithm, "defaultstrong")) {
    			// We do not support defaultstrong anymore. If configured, previously a NativePRNGBlocking algorithm would have been used.
    			throw new IllegalStateException("The algorithm option " + algorithm + " is not supported by this software. Please use a non-blocking algorithm instead.");
    		} else if (StringUtils.equalsIgnoreCase(algorithm, "default")) {
    			// We entered "default" so let's use a good default SecureRandom this should be good enough for just about everyone (on Linux at least)
    			// On Linux the default Java implementation uses the (secure) /dev/(u)random, but on windows something else
    			// This gives you a NativePRNG.
    			random = new SecureRandom();
    			log.info("Using default " + random.getAlgorithm() + " serialNumber RNG algorithm.");
    		} else if (!StringUtils.isEmpty(algorithm)) {
       			//Use a specified algorithm other than BCSP800Hybrid or default, note that this must be something that is available in java.security
    			random = SecureRandom.getInstance(algorithm);
    			log.info("Using "+algorithm+" serialNumber RNG algorithm.");
    		} else if (random == null) {
        		//If no algorithm is set in configuration and random is still null, we will default to BCSP800Hybrid
    			random = createBCSP800Hybrid();
    			log.info("Using FIPS/SP800 compliant Bouncy Castle Hybrid serialNumber RNG algorithm.");    		
        	}
    	} catch (NoSuchAlgorithmException e) {
    		//This state is unrecoverable, caller must use an existing algorithm.
    		throw new IllegalStateException("Algorithm " + algorithm + " was not a valid algorithm.", e);
    	}
    	// Call nextBytes directly after in order to force seeding if not already done. SecureRandom typically seeds on first call.
    	random.nextBytes(new byte[0]);
    	return random;
    }
    
    /**
     * Creating BCSP800Hybrid CSPRNG
     * @return a SecureRandom
     * @throws NoSuchAlgorithmException
     */
    private static SecureRandom createBCSP800Hybrid() throws NoSuchAlgorithmException {
		// create the seed material source
		final SecureRandom sourceRandom = SecureRandom.getInstanceStrong();
		// create and return an actual random we can use
		return new SP800SecureRandomBuilder(sourceRandom, true)
				.setPersonalizationString(Strings.toByteArray("Bouncy Castle Hybrid Random"))
				.buildHash(new SHA512Digest(), null, false);    	
    }
}
