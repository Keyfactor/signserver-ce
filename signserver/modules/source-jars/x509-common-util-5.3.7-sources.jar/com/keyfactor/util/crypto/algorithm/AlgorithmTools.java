/*************************************************************************
 *                                                                       *
 *  Keyfactor Commons                                                    *
 *                                                                       *
 *  This software is free software; you can redistribute it and/or       *
 *  modify it under the terms of the GNU Lesser General Public           *
 *  License as published by the Free Software Foundation; either         *
 *  version 2.1 of the License, or any later version.                    *
 *                                                                       *
 *  See terms of license at gnu.org.                                     *
 *                                                                       *
 *************************************************************************/
package com.keyfactor.util.crypto.algorithm;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.interfaces.ECPublicKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.EllipticCurve;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.keyfactor.util.CertTools;
import com.keyfactor.util.StringTools;
import com.keyfactor.util.keys.KeyTools;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.bouncycastle.asn1.ASN1ObjectIdentifier;
import org.bouncycastle.asn1.anssi.ANSSINamedCurves;
import org.bouncycastle.asn1.bc.BCObjectIdentifiers;
import org.bouncycastle.asn1.cryptopro.ECGOST3410NamedCurves;
import org.bouncycastle.asn1.edec.EdECObjectIdentifiers;
import org.bouncycastle.asn1.gm.GMNamedCurves;
import org.bouncycastle.asn1.nist.NISTNamedCurves;
import org.bouncycastle.asn1.nist.NISTObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.PKCSObjectIdentifiers;
import org.bouncycastle.asn1.pkcs.RSASSAPSSparams;
import org.bouncycastle.asn1.sec.SECNamedCurves;
import org.bouncycastle.asn1.teletrust.TeleTrusTNamedCurves;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.asn1.x9.X962NamedCurves;
import org.bouncycastle.asn1.x9.X9ECParameters;
import org.bouncycastle.asn1.x9.X9ObjectIdentifiers;
import org.bouncycastle.cms.CMSSignedGenerator;
import org.bouncycastle.jcajce.interfaces.MLDSAKey;
import org.bouncycastle.jcajce.interfaces.MLDSAPublicKey;
import org.bouncycastle.jcajce.interfaces.MLKEMKey;
import org.bouncycastle.jcajce.interfaces.MLKEMPublicKey;
import org.bouncycastle.jcajce.interfaces.SLHDSAKey;
import org.bouncycastle.jcajce.interfaces.SLHDSAPublicKey;
import org.bouncycastle.jcajce.provider.asymmetric.edec.BCEdDSAPublicKey;
import org.bouncycastle.jcajce.spec.MLDSAParameterSpec;
import org.bouncycastle.jcajce.spec.MLKEMParameterSpec;
import org.bouncycastle.jcajce.spec.SLHDSAParameterSpec;
import org.bouncycastle.jce.ECGOST3410NamedCurveTable;
import org.bouncycastle.jce.ECNamedCurveTable;
import org.bouncycastle.jce.spec.ECNamedCurveParameterSpec;
import org.bouncycastle.jce.spec.ECNamedCurveSpec;
import org.bouncycastle.math.ec.ECCurve;
import org.bouncycastle.operator.DefaultAlgorithmNameFinder;
import org.bouncycastle.operator.DefaultSignatureAlgorithmIdentifierFinder;
import org.bouncycastle.pqc.jcajce.interfaces.FalconKey;
import org.bouncycastle.pqc.jcajce.interfaces.FalconPublicKey;
import org.bouncycastle.pqc.jcajce.interfaces.LMSKey;
import org.bouncycastle.pqc.jcajce.provider.lms.BCLMSPublicKey;
import org.bouncycastle.pqc.jcajce.spec.FalconParameterSpec;


/**
 * Various helper methods for handling the mappings between different key and
 * signature algorithms.
 *
 * This class has to be updated when new key or signature algorithms are
 * added to EJBCA.
 *
 * @see AlgorithmConstants
 * @see KeyTools#getKeyLength
 *
 */
public abstract class AlgorithmTools {

    /** Log4j instance */
    public static final Logger log = Logger.getLogger(AlgorithmTools.class);

    /** String used for an unknown keyspec in CA token properties */
    public static final String KEYSPEC_UNKNOWN = "unknown";

    /** Signature algorithms supported by RSA keys */
    private static final List<String> SIG_ALGS_RSA_NOSHA1_INTERNAL = Arrays.asList(
            AlgorithmConstants.SIGALG_SHA256_WITH_RSA,
            AlgorithmConstants.SIGALG_SHA256_WITH_RSA_AND_MGF1,
            AlgorithmConstants.SIGALG_SHA384_WITH_RSA_AND_MGF1,
            AlgorithmConstants.SIGALG_SHA512_WITH_RSA_AND_MGF1,
            AlgorithmConstants.SIGALG_SHA384_WITH_RSA,
            AlgorithmConstants.SIGALG_SHA512_WITH_RSA,
            AlgorithmConstants.SIGALG_SHA3_256_WITH_RSA,
            AlgorithmConstants.SIGALG_SHA3_384_WITH_RSA,
            AlgorithmConstants.SIGALG_SHA3_512_WITH_RSA
    );
    public static final List<String> SIG_ALGS_RSA_NOSHA1 = Collections.unmodifiableList(SIG_ALGS_RSA_NOSHA1_INTERNAL);

    private static final List<String> SIG_ALGS_RSA_SHA1_INTERNAL = Arrays.asList(
            AlgorithmConstants.SIGALG_SHA1_WITH_RSA,
            AlgorithmConstants.SIGALG_SHA1_WITH_RSA_AND_MGF1
    );

    public static final List<String> SIG_ALGS_RSA = Collections.unmodifiableList(union(SIG_ALGS_RSA_SHA1_INTERNAL, SIG_ALGS_RSA_NOSHA1_INTERNAL));

    private static <T> List<T> union(List<T> list1, List<T> list2) {
		Set<T> result = new HashSet<>();
		result.addAll(list1);
		result.addAll(list2);
		return new ArrayList<>(result);
    }

    /** Signature algorithms supported by ECDSA keys */
    public static final List<String> SIG_ALGS_ECDSA = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SHA1_WITH_ECDSA,
            AlgorithmConstants.SIGALG_SHA224_WITH_ECDSA,
            AlgorithmConstants.SIGALG_SHA256_WITH_ECDSA,
            AlgorithmConstants.SIGALG_SHA384_WITH_ECDSA,
            AlgorithmConstants.SIGALG_SHA512_WITH_ECDSA,
            AlgorithmConstants.SIGALG_SHA3_256_WITH_ECDSA,
            AlgorithmConstants.SIGALG_SHA3_384_WITH_ECDSA,
            AlgorithmConstants.SIGALG_SHA3_512_WITH_ECDSA
    ));

    /** Constants holding the default available bit lengths for various algorithms */
    public static final List<Integer> DEFAULTBITLENGTHS_RSA = Arrays.asList( 1024, 1536, 2048, 3072, 4096, 6144, 8192 );
    public static final List<Integer> DEFAULTBITLENGTHS_EC = getAllNamedEcCurveBitLengths();

    public static List<Integer> getAllBitLengths() {
        Set<Integer> allBitLengths = new TreeSet<>();
        allBitLengths.addAll(DEFAULTBITLENGTHS_RSA);
        allBitLengths.addAll(DEFAULTBITLENGTHS_EC);
        return new ArrayList<>(allBitLengths);
    }

    /** Signature algorithms supported by EDDSA keys */
    public static final List<String> SIG_ALGS_ED25519 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_ED25519
    ));
    /** Signature algorithms supported by EDDSA keys */
    public static final List<String> SIG_ALGS_ED448 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_ED448
    ));

    /** Post-quantum signature algorithms */
    public static final List<String> SIG_ALGS_FALCON512 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_FALCON512
    ));
    public static final List<String> SIG_ALGS_FALCON1024 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_FALCON1024
    ));
    public static final List<String> SIG_ALGS_MLKEM512 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_MLKEM512
    ));
    public static final List<String> SIG_ALGS_MLKEM768 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_MLKEM768
    ));
    public static final List<String> SIG_ALGS_MLKEM1024 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_MLKEM1024
    ));
    public static final List<String> SIG_ALGS_MLDSA44 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_MLDSA44
    ));
    public static final List<String> SIG_ALGS_MLDSA65 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_MLDSA65
    ));
    public static final List<String> SIG_ALGS_MLDSA87 = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_MLDSA87
    ));
    public static final List<String> SIG_ALGS_LMS = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_LMS
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHA2_128S = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHA2_128S
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHAKE_128S = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128S
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHA2_128F = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHA2_128F
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHAKE_128F = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128F
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHA2_192S = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHA2_192S
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHAKE_192S = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192S
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHA2_192F = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHA2_192F
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHAKE_192F = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192F
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHA2_256S = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHA2_256S
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHAKE_256S = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256S
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHA2_256F = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHA2_256F
    ));
    public static final List<String> SIG_ALGS_SLHDSA_SHAKE_256F = Collections.unmodifiableList(Arrays.asList(
            AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256F
    ));

    private static Map<String, List<String>> allEcCurveNames = preProcessCurveNames();
    private static Map<String, List<String>> allGostCurveNames = preProcessGostCurveNames();
    private static Map<String, List<String>> ecKeySpecAliases;

    /**
     * Gets the name of matching key algorithm from a public key as defined by
     * <i>AlgorithmConstants</i>.
     * @param publickey Public key to find matching key algorithm for.
     * @return Name of the matching key algorithm or null if no match.
     * @see AlgorithmConstants#KEYALGORITHM_RSA
     * @see AlgorithmConstants#KEYALGORITHM_ECDSA
     * @see AlgorithmConstants#KEYALGORITHM_ED25519
     * @see AlgorithmConstants#KEYALGORITHM_ED448
     */
    public static String getKeyAlgorithm(final PublicKey publickey) {
        if (publickey == null) {
            return null; // Fail fast
        }
        final String keyAlg;
        if (publickey instanceof RSAPublicKey) {
            keyAlg = AlgorithmConstants.KEYALGORITHM_RSA;
		} else if (publickey instanceof ECPublicKey) {
			keyAlg = AlgorithmConstants.KEYALGORITHM_ECDSA;
		} else if (publickey instanceof BCEdDSAPublicKey) {
		    keyAlg = publickey.getAlgorithm();
            // Work around for making testMakeP12ForSingleUserEdDSA* pass, for some reason on jdk > 15 public key
            // comes from SUN and not BC, most probably due to the multi release jdk used by BC
        } else if (publickey.getClass().getCanonicalName().equals("sun.security.ec.ed.EdDSAPublicKeyImpl")) {
            keyAlg = AlgorithmConstants.KEYALGORITHM_ED25519;
        } else if (publickey instanceof FalconKey) {
            keyAlg = publickey.getAlgorithm();
        } else if (publickey instanceof MLDSAKey) {
            keyAlg = publickey.getAlgorithm();
        } else if (publickey instanceof MLKEMKey) {
            keyAlg = publickey.getAlgorithm();
        } else if (publickey instanceof LMSKey) {
            keyAlg = publickey.getAlgorithm();
        } else if (publickey instanceof SLHDSAKey) {
            keyAlg = publickey.getAlgorithm();
        } else {
            if (log.isDebugEnabled()) {
                log.debug("Unknown key algorithm: " + publickey.getClass().getName() + ", " + publickey.getAlgorithm());
            }
            keyAlg = null;
        }
        return keyAlg;
    }

    /** @return a list of all available key algorithms */
    public static List<String> getAvailableKeyAlgorithms() {
        final List<String> ret = new ArrayList<>(Arrays.asList(AlgorithmConstants.KEYALGORITHM_ECDSA,
                AlgorithmConstants.KEYALGORITHM_RSA, AlgorithmConstants.KEYALGORITHM_ED25519, AlgorithmConstants.KEYALGORITHM_ED448,
                AlgorithmConstants.KEYALGORITHM_FALCON512, AlgorithmConstants.KEYALGORITHM_FALCON1024,
                AlgorithmConstants.KEYALGORITHM_MLKEM512, AlgorithmConstants.KEYALGORITHM_MLKEM768, AlgorithmConstants.KEYALGORITHM_MLKEM1024,
                AlgorithmConstants.KEYALGORITHM_MLDSA44, AlgorithmConstants.KEYALGORITHM_MLDSA65, AlgorithmConstants.KEYALGORITHM_MLDSA87,
                AlgorithmConstants.KEYALGORITHM_LMS,
                AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128S, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128S,
                AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128F, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128F,
                AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192S, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192S,
                AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192F, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192F,
                AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256S, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256S,
                AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256F, AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256F));
        return ret;
    }

    /**
     * Get unique available named elliptic curves and their aliases.
     *
     * @return a Map with elliptic curve names as key and the key+any alias as the value.
     */
    public static Map<String,List<String>> getNamedEcCurvesMap() {
        return allEcCurveNames;
    }

    public static Map<String,List<String>> getNamedGostCurvesMap() {
        return allGostCurveNames;
    }

    /**
     * @return a Map with elliptic curve names as key and the key+any alias as the value, restricted to pure EC curves
     */
    public static Map<String,List<String>> getOnlyNamedEcCurvesMap() {
        final Map<String,List<String>> processedCurveNames = getNamedEcCurvesMap();
        //Clean out GOST curves
        final Enumeration<?> gostAlgorithms =  ECGOST3410NamedCurves.getNames();
        while (gostAlgorithms.hasMoreElements()) {
            processedCurveNames.remove(gostAlgorithms.nextElement());
        }
        return processedCurveNames;
    }

    /**
     * Get unique available named elliptic curves and their aliases.
     *
     * @return a Map with elliptic curve names as key and the list of alias separated by '/' as the value.
     */
    public static TreeMap<String,String> getFlatNamedEcCurvesMap() {
        final TreeMap<String,String> result = new TreeMap<>();
        final Map<String, List<String>> map = getOnlyNamedEcCurvesMap();
        final String[] keys = map.keySet().toArray(new String[map.size()]);
        Arrays.sort(keys);
        for (final String name : keys) {
            result.put(name, StringTools.getAsStringWithSeparator(" / ", map.get(name)));
        }
        return result;
    }

    /**
     * Gets a list of allowed curves (see <a href="http://csrc.nist.gov/groups/ST/toolkit/documents/dss/NISTReCur.pdf">http://csrc.nist.gov/groups/ST/toolkit/documents/dss/NISTReCur.pdf</a>).
     *
     * @return the list of allowed curves.
     */
    public static List<String> getNistCurves() {
        // Only apply most important conditions (sequence is Root-CA, Sub-CA, User-Certificate)!
        // But this is not required at the time, because certificate validity conditions are before
        // 2014 (now 2017). Allowed curves by NIST are NIST P 256, P 384, P 521
        // See http://csrc.nist.gov/groups/ST/toolkit/documents/dss/NISTReCur.pdf chapter 1.2
        final List<String> list = new ArrayList<>();
        list.addAll(AlgorithmTools.getEcKeySpecAliases("P-256"));
        list.addAll(AlgorithmTools.getEcKeySpecAliases("P-384"));
        list.addAll(AlgorithmTools.getEcKeySpecAliases("P-521"));
        return list;
    }

    /**
     * @param hasToBeKnownByDefaultProvider  Ignored
     * @deprecated Use the method without the boolean parameter instead. The parameter is ignored now
     */
    @Deprecated
    public static Map<String,List<String>> getNamedEcCurvesMap(final boolean hasToBeKnownByDefaultProvider) {
        return getNamedEcCurvesMap();
    }

    /**
     * @param hasToBeKnownByDefaultProvider  Ignored
     * @deprecated Use the method without the boolean parameter instead. The parameter is ignored now
     */
    @Deprecated
    public static Map<String,List<String>> getNamedGostCurvesMap(final boolean hasToBeKnownByDefaultProvider) {
        return getNamedGostCurvesMap();
    }

    /**
     * @param hasToBeKnownByDefaultProvider  Ignored
     * @deprecated Use the method without the boolean parameter instead. The parameter is ignored now
     */
    @Deprecated
    public static Map<String,List<String>> getOnlyNamedEcCurvesMap(final boolean hasToBeKnownByDefaultProvider) {
        return getOnlyNamedEcCurvesMap();
    }

    /**
     * @param hasToBeKnownByDefaultProvider  Ignored
     * @deprecated Use the method without the boolean parameter instead. The parameter is ignored now
     */
    @Deprecated
    public static TreeMap<String,String> getFlatNamedEcCurvesMap(final boolean hasToBeKnownByDefaultProvider) {
        return getFlatNamedEcCurvesMap();
    }

    private static Map<String, List<String>> preProcessCurveNames() {
        final Map<String,List<String>> processedCurveNames = new HashMap<>();
        Set<ECNamedCurveParameterSpec> addedCurves = new HashSet<>();
        final Enumeration<?> ecNamedCurvesStandard = ECNamedCurveTable.getNames();
        // Process standard curves, removing blacklisted ones and those not supported by the provider
        while (ecNamedCurvesStandard.hasMoreElements()) {
            final String ecNamedCurve = (String) ecNamedCurvesStandard.nextElement();
            final ECNamedCurveParameterSpec parameterSpec = ECNamedCurveTable.getParameterSpec(ecNamedCurve);
            if (AlgorithmConstants.BLACKLISTED_EC_CURVES.contains(ecNamedCurve)) {
                continue;
            }
            if (addedCurves.contains(parameterSpec)) {
                // Check if this param spec exists under another alias
                continue;
            }
            processedCurveNames.put(ecNamedCurve, getEcKeySpecAliases(ecNamedCurve));
        }

        // Process additional curves that we specify
        for (String ecNamedCurve : AlgorithmConstants.EXTRA_EC_CURVES) {
            final ECNamedCurveParameterSpec parameterSpec = ECNamedCurveTable.getParameterSpec(ecNamedCurve);
            if (AlgorithmConstants.BLACKLISTED_EC_CURVES.contains(ecNamedCurve)) {
                continue;
            }
            if (addedCurves.contains(parameterSpec)) {
                // Check if this param spec exists under another alias
                continue;
            }
            processedCurveNames.put(ecNamedCurve, getEcKeySpecAliases(ecNamedCurve));
        }

        return processedCurveNames;

    }

    private static Map<String, List<String>> preProcessGostCurveNames() {
        final Map<String,List<String>> processedCurveNames = new HashMap<>();
        Set<ECNamedCurveParameterSpec> addedCurves = new HashSet<>();
        final Enumeration<?> gostNamedCurvesStandard = ECGOST3410NamedCurves.getNames();
        // Process standard curves, removing blacklisted ones and those not supported by the provider
        while (gostNamedCurvesStandard.hasMoreElements()) {
            final String gostNamedCurve = (String) gostNamedCurvesStandard.nextElement();
            final ECNamedCurveParameterSpec parameterSpec = ECNamedCurveTable.getParameterSpec(gostNamedCurve);

            if (addedCurves.contains(parameterSpec)) {
                // Check if this param spec exists under another alias
                continue;
            }
            processedCurveNames.put(gostNamedCurve, getEcKeySpecAliases(gostNamedCurve));
        }

        return processedCurveNames;

    }

    /** @return the number of bits a named elliptic curve has or 0 if the curve name is unknown. */
    public static int getNamedEcCurveBitLength(final String ecNamedCurve) {
        ECNamedCurveParameterSpec ecNamedCurveParameterSpec = ECGOST3410NamedCurveTable.getParameterSpec(ecNamedCurve);
        if (ecNamedCurveParameterSpec!=null) {
            // This always returns 0, so try to use the field size as an estimate of the bit strength
            return ecNamedCurveParameterSpec.getCurve().getFieldSize();
        }
        ecNamedCurveParameterSpec = ECNamedCurveTable.getParameterSpec(ecNamedCurve);
        if (ecNamedCurveParameterSpec==null) {
            return 0;
        }
        return ecNamedCurveParameterSpec.getN().bitLength();
    }

    /**
     *
     * @return a list of all possible EC bit lengths known to the current provider
     */
    public static List<Integer> getAllNamedEcCurveBitLengths() {
        Set<Integer> result = new TreeSet<>();
        Enumeration<?> ecCurveNames = ECNamedCurveTable.getNames();
        result.add(0);
        while (ecCurveNames.hasMoreElements()) {
            final String ecNamedCurve = (String) ecCurveNames.nextElement();
            result.add(getNamedEcCurveBitLength(ecNamedCurve));
        }
        return new ArrayList<>(result);
    }

    /**
     * Gets a collection of signature algorithm names supported by the given
     * key.
     * @param publickey key to find supported algorithms for.
     * @return Collection of zero or more signature algorithm names
     * @see AlgorithmConstants
     */
    public static List<String> getSignatureAlgorithms(final PublicKey publickey) {
        if ( publickey instanceof RSAPublicKey ) {
            return SIG_ALGS_RSA;
        }
        if ( publickey instanceof ECPublicKey ) {
            // Make things work faster by making the "best suitable" signature algorithm be first in the list
            // This is a must for example for Azure Key Vault where a P-384 key can not be used together with SHA256WithECDSA.
            List<String> ecSigAlgs = new ArrayList<>(SIG_ALGS_ECDSA);
            switch (AlgorithmTools.getNamedEcCurveBitLength(getKeySpecification(publickey))) {
            case 256:
                ecSigAlgs.remove(AlgorithmConstants.SIGALG_SHA256_WITH_ECDSA);
                ecSigAlgs.add(0, AlgorithmConstants.SIGALG_SHA256_WITH_ECDSA);
                break;
            case 384:
                ecSigAlgs.remove(AlgorithmConstants.SIGALG_SHA384_WITH_ECDSA);
                ecSigAlgs.add(0, AlgorithmConstants.SIGALG_SHA384_WITH_ECDSA);
                break;
            case 521:
                // This is really 521 and not 512, the corresponding EC curve is for example secp521r1
                ecSigAlgs.remove(AlgorithmConstants.SIGALG_SHA512_WITH_ECDSA);
                ecSigAlgs.add(0, AlgorithmConstants.SIGALG_SHA512_WITH_ECDSA);
                break;
            default:
                break;
            }
            if (log.isDebugEnabled()) {
                log.debug("Returning ecAlgs: " + ecSigAlgs);
            }
            return ecSigAlgs;
        }
        if ( publickey instanceof BCEdDSAPublicKey ) {
            final String algo = publickey.getAlgorithm();
            switch (algo) {
            case AlgorithmConstants.KEYALGORITHM_ED25519:
                return SIG_ALGS_ED25519;
            case AlgorithmConstants.KEYALGORITHM_ED448:
                return SIG_ALGS_ED448;
            }
        }
        if ( publickey instanceof FalconKey ) {
            FalconParameterSpec spec = ((FalconKey)publickey).getParameterSpec();
            if (FalconParameterSpec.falcon_512.equals(spec)) {
                return SIG_ALGS_FALCON512;
            } else if (FalconParameterSpec.falcon_1024.equals(spec)) {
                return SIG_ALGS_FALCON1024;
            }
        }
        if ( publickey instanceof MLKEMKey ) {
        	MLKEMParameterSpec spec = ((MLKEMKey)publickey).getParameterSpec();
            if (MLKEMParameterSpec.ml_kem_512.equals(spec)) {
                return SIG_ALGS_MLKEM512;
            } else if (MLKEMParameterSpec.ml_kem_768.equals(spec)) {
                return SIG_ALGS_MLKEM768;
            } else if (MLKEMParameterSpec.ml_kem_1024.equals(spec)) {
                return SIG_ALGS_MLKEM1024;
            }
        }
        if ( publickey instanceof MLDSAKey ) {
            MLDSAParameterSpec spec = ((MLDSAKey)publickey).getParameterSpec();
            if (MLDSAParameterSpec.ml_dsa_44.equals(spec)) {
                return SIG_ALGS_MLDSA44;
            } else if (MLDSAParameterSpec.ml_dsa_65.equals(spec)) {
                return SIG_ALGS_MLDSA65;
            } else if (MLDSAParameterSpec.ml_dsa_87.equals(spec)) {
                return SIG_ALGS_MLDSA87;
            }
        }

        if ( publickey instanceof LMSKey ) {
            return SIG_ALGS_LMS;
        }

        if ( publickey instanceof SLHDSAKey ) {
            SLHDSAParameterSpec spec = ((SLHDSAKey) publickey).getParameterSpec();
            if (SLHDSAParameterSpec.slh_dsa_sha2_128s.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHA2_128S;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_128s.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHAKE_128S;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_128f.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHA2_128F;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_128f.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHAKE_128F;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_192s.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHA2_192S;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_192s.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHAKE_192S;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_192f.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHA2_192F;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_192f.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHAKE_192F;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_256s.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHA2_256S;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_256s.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHAKE_256S;
            } else if (SLHDSAParameterSpec.slh_dsa_sha2_256f.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHA2_256F;
            } else if (SLHDSAParameterSpec.slh_dsa_shake_256f.equals(spec)) {
                return SIG_ALGS_SLHDSA_SHAKE_256F;
            }
        }

        return Collections.emptyList();
    }

    /**
     * Gets the key algorithm matching a specific signature algorithm.
     * @param signatureAlgorithm to get matching key algorithm for
     * @return The key algorithm matching the signature or algorithm or
     * the default if no matching was found.
     * @see AlgorithmConstants
     */
    public static String getKeyAlgorithmFromSigAlg(final String signatureAlgorithm) {
        final String ret;
        if ( signatureAlgorithm.contains("ECDSA") ) {
            ret = AlgorithmConstants.KEYALGORITHM_ECDSA;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_ED25519) ) {
            ret = AlgorithmConstants.KEYALGORITHM_ED25519;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_ED448) ) {
            ret = AlgorithmConstants.KEYALGORITHM_ED448;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_FALCON512) ) {
            ret = AlgorithmConstants.KEYALGORITHM_FALCON512;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_FALCON1024) ) {
            ret = AlgorithmConstants.KEYALGORITHM_FALCON1024;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_MLKEM512) ) {
            ret = AlgorithmConstants.KEYALGORITHM_MLKEM512;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_MLKEM768) ) {
            ret = AlgorithmConstants.KEYALGORITHM_MLKEM768;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_MLKEM1024) ) {
            ret = AlgorithmConstants.KEYALGORITHM_MLKEM1024;
        }else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_MLDSA44) ) {
            ret = AlgorithmConstants.KEYALGORITHM_MLDSA44;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_MLDSA65) ) {
            ret = AlgorithmConstants.KEYALGORITHM_MLDSA65;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_MLDSA87) ) {
            ret = AlgorithmConstants.KEYALGORITHM_MLDSA87;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_LMS) ) {
            ret = AlgorithmConstants.KEYALGORITHM_LMS;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_128S) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128S;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128S) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128S;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_128F) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_128F;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128F) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_128F;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_192S) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192S;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192S) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192S;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_192F) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_192F;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192F) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_192F;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_256S) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256S;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256S) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256S;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_256F) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHA2_256F;
        } else if ( signatureAlgorithm.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256F) ) {
            ret = AlgorithmConstants.KEYALGORITHM_SLHDSA_SHAKE_256F;
        } else {
            ret = AlgorithmConstants.KEYALGORITHM_RSA;
        }
        return ret;
    }

    /**
     * Gets the key specification from a public key. Example: "2048" for a RSA
     * key or "secp256r1" for EC key. The EC curve is only detected
     * if <i>publickey</i> is an object known by the bouncy castle provider.
     * @param publicKey The public key to get the key specification from
     * @return The key specification, "unknown" if it could not be determined and
     * null if the key algorithm is not supported
     */
    public static String getKeySpecification(final PublicKey publicKey) {
        if (log.isTraceEnabled()) {
            log.trace(">getKeySpecification");
        }
        String keyspec = null;
        if ( publicKey instanceof RSAPublicKey ) {
            keyspec = Integer.toString( ((RSAPublicKey) publicKey).getModulus().bitLength() );
        } else if ( publicKey instanceof ECPublicKey) {
            final ECPublicKey ecPublicKey = (ECPublicKey) publicKey;
            if ( ecPublicKey.getParams() instanceof ECNamedCurveSpec ) {
                keyspec = ((ECNamedCurveSpec) ecPublicKey.getParams()).getName();
                // Convert OID to name
                if (Character.isDigit(keyspec.charAt(0))) {
                    final String curveName = org.bouncycastle.asn1.x9.ECNamedCurveTable.getName(new ASN1ObjectIdentifier(keyspec));
                    if (curveName == null) {
                        log.warn("Failed to look up curve name for OID " + keyspec);
                    } else {
                        keyspec = curveName;
                    }
                }
                // Prefer to return a curve name alias that also works with the default and BC provider
                for (String keySpecAlias : getEcKeySpecAliases(keyspec)) {
                    keyspec = keySpecAlias;
                    break;
                }
            } else {
                keyspec = KEYSPEC_UNKNOWN;
                // Try to detect if it is a curve name known by BC even though the public key isn't a BC key
                final ECParameterSpec namedCurve = ecPublicKey.getParams();
                if (namedCurve!=null) {
                    final int c1 = namedCurve.getCofactor();
                    final EllipticCurve ec1 = namedCurve.getCurve();
                    final BigInteger a1 = ec1.getA();
                    final BigInteger b1 = ec1.getB();
                    final int fs1 = ec1.getField().getFieldSize();
                    //final byte[] s1 = ec1.getSeed();
                    final ECPoint g1 = namedCurve.getGenerator();
                    final BigInteger ax1 = g1.getAffineX();
                    final BigInteger ay1 = g1.getAffineY();
                    final BigInteger o1 = namedCurve.getOrder();
                    if (log.isDebugEnabled()) {
                        log.debug("a1=" + a1 + " b1=" + b1 + " fs1=" + fs1 + " ax1=" + ax1 + " ay1=" + ay1 + " o1=" + o1 + " c1="+c1);
                    }
                    final Enumeration<?> ecNamedCurves = ECNamedCurveTable.getNames();
                    while (ecNamedCurves.hasMoreElements()) {
                        final String ecNamedCurveBc = (String) ecNamedCurves.nextElement();
                        final ECNamedCurveParameterSpec parameterSpec2 = ECNamedCurveTable.getParameterSpec(ecNamedCurveBc);
                        final ECCurve ec2 = parameterSpec2.getCurve();
                        final BigInteger a2 = ec2.getA().toBigInteger();
                        final BigInteger b2 = ec2.getB().toBigInteger();
                        final int fs2 = ec2.getFieldSize();
                        final org.bouncycastle.math.ec.ECPoint g2 = parameterSpec2.getG();
                        final BigInteger ax2 = g2.getAffineXCoord().toBigInteger();
                        final BigInteger ay2 = g2.getAffineYCoord().toBigInteger();
                        final BigInteger h2 = parameterSpec2.getH();
                        final BigInteger n2 = parameterSpec2.getN();
                        if (a1.equals(a2) && ax1.equals(ax2) && b1.equals(b2) && ay1.equals(ay2) && fs1==fs2 && o1.equals(n2) && c1==h2.intValue()) {
                            // We have a matching curve here!
                            if (log.isDebugEnabled()) {
                                log.debug("a2=" + a2 + " b2=" + b2 + " fs2=" + fs2 + " ax2=" + ax2 + " ay2=" + ay2 + " h2=" + h2 + " n2=" + n2 + " " + ecNamedCurveBc);
                            }
                            keyspec = ecNamedCurveBc;
                        }
                    }
                }
            }
        } else if ( publicKey instanceof BCEdDSAPublicKey ) {
            return publicKey.getAlgorithm();
        } else if ( publicKey instanceof FalconPublicKey ) {
            return ((FalconPublicKey) publicKey).getParameterSpec().getName().toUpperCase();
        } else if ( publicKey instanceof MLKEMPublicKey ) {
            return ((MLKEMPublicKey) publicKey).getParameterSpec().getName().toUpperCase();
        } else if ( publicKey instanceof MLDSAPublicKey ) {
            return ((MLDSAPublicKey) publicKey).getParameterSpec().getName().toUpperCase();
        } else if ( publicKey instanceof SLHDSAPublicKey) {
            return ((SLHDSAPublicKey) publicKey).getParameterSpec().getName().toUpperCase();
        } else if ( publicKey instanceof BCLMSPublicKey ) {
            // For LMS it would be something complicated like  SHA256, L=1, H=5, N=32, W=8
            // but we will not try to dig that out, but just show LMS back
            return ((BCLMSPublicKey) publicKey).getAlgorithm();
        }
        if (log.isTraceEnabled()) {
            log.trace("<getKeySpecification: "+keyspec);
        }
        return keyspec;
    }

    /**
     * @param ecNamedCurveBc Ignored
     * @return Always true
     * @deprecated Did not work reliably. Now always returns true
     */
    @Deprecated
    public static boolean isNamedECKnownInDefaultProvider(String ecNamedCurveBc) {
        return true;
    }

    /**
     * Convert from BC ECC curve names to the OID.
     *
     * @param ecNamedCurveBc the name as BC reports it
     * @return the OID of the curve or the input curve name if it is unknown by BC
     */
    public static String getEcKeySpecOidFromBcName(final String ecNamedCurveBc) {
        // Although the below class is in x9 package, it handles all different curves, including TeleTrust (brainpool)
        final ASN1ObjectIdentifier oid = org.bouncycastle.asn1.x9.ECNamedCurveTable.getOID(ecNamedCurveBc);
        if (oid==null) {
            return ecNamedCurveBc;
        }
        return oid.getId();
    }

    /** @return a list of aliases for the provided curve name (including the provided name) */
    public static List<String> getEcKeySpecAliases(final String namedEllipticCurve) {
        // Turns out this method slows down issuance significantly, cache results. See ECA-XXXX
        if (ecKeySpecAliases != null) {
            if (ecKeySpecAliases.containsKey(namedEllipticCurve)) {
                return ecKeySpecAliases.get(namedEllipticCurve);
            }
        } else {
            ecKeySpecAliases = new HashMap<>();
        }
        final ECNamedCurveParameterSpec parameterSpec = ECNamedCurveTable.getParameterSpec(namedEllipticCurve);
        final List<String> ret = new ArrayList<>();
        ret.add(namedEllipticCurve);

        if (parameterSpec != null) {
            final Enumeration<?> ecNamedCurves = ECNamedCurveTable.getNames();
            while (ecNamedCurves.hasMoreElements()) {
                final String currentCurve = (String) ecNamedCurves.nextElement();
                if (!namedEllipticCurve.equals(currentCurve)) {
                    final ECNamedCurveParameterSpec parameterSpec2 = ECNamedCurveTable.getParameterSpec(currentCurve);
                    if (parameterSpec.equals(parameterSpec2)) {
                        ret.add(currentCurve);
                    }
                }
            }
        }
        ecKeySpecAliases.put(namedEllipticCurve, ret);
        return ret;
    }


    /**
     * Assumes input in the state of the signature algorithms declared in {@link AlgorithmConstants}, and extracts the basic hash algorithms from there within.
     *
     * @param signatureAlgorithm a signature algorithm
     * @return a basic hash algorithm
     */
    public static String getHashAlgorithm(final String signatureAlgorithm) {
        final String result;
        if(signatureAlgorithm.contains(AlgorithmConstants.HASHALGORITHM_SHA1)) {
            result = AlgorithmConstants.HASHALGORITHM_SHA1;
        }  else if(signatureAlgorithm.contains(AlgorithmConstants.HASHALGORITHM_SHA224)) {
            result = AlgorithmConstants.HASHALGORITHM_SHA224;
        } else if(signatureAlgorithm.contains(AlgorithmConstants.HASHALGORITHM_SHA256)) {
            result = AlgorithmConstants.HASHALGORITHM_SHA256;
        } else if(signatureAlgorithm.contains(AlgorithmConstants.HASHALGORITHM_SHA384)) {
            result = AlgorithmConstants.HASHALGORITHM_SHA384;
        } else if(signatureAlgorithm.contains(AlgorithmConstants.HASHALGORITHM_SHA512)) {
            result = AlgorithmConstants.HASHALGORITHM_SHA512;
        } else if(signatureAlgorithm.contains(AlgorithmConstants.HASHALGORITHM_SHA3_256)) {
            result = AlgorithmConstants.HASHALGORITHM_SHA3_256;
        } else if(signatureAlgorithm.contains(AlgorithmConstants.HASHALGORITHM_SHA3_384)) {
            result = AlgorithmConstants.HASHALGORITHM_SHA3_384;
        } else if(signatureAlgorithm.contains(AlgorithmConstants.HASHALGORITHM_SHA3_512)) {
            result = AlgorithmConstants.HASHALGORITHM_SHA3_512;
        }
        else {
            result = signatureAlgorithm;
        }

        return result;
    }


    /**
     * Gets the algorithm to use for encryption given a specific signature algorithm, adapted to the cipher type used by the encryption keys.
     * Some cipher algorithms (i.e. ML-DSA) can not be used for encryption so they are instead substituted with RSA with equivalent hash algorithm.
     *
     *
     * @param signatureAlgorithm to extract the encryption algorithm for
     * @param publicKey a public key to derive the cipher from
     * @return an other encryption algorithm or same as signature algorithm if it can be used for encryption
     */
    public static String getEncSigAlgFromSigAlg(final String signatureAlgorithm, final PublicKey publicKey ) {

        String encSigAlg = signatureAlgorithm;


        //The below rather sad construction is needed on the legacy assumption that only RSA keys would ever be used for encryption.
        switch (signatureAlgorithm) {
        case AlgorithmConstants.SIGALG_ED25519:
        case AlgorithmConstants.SIGALG_ED448:
        case AlgorithmConstants.SIGALG_FALCON512:
        case AlgorithmConstants.SIGALG_FALCON1024:
        case AlgorithmConstants.SIGALG_MLKEM512:
        case AlgorithmConstants.SIGALG_MLKEM768:
        case AlgorithmConstants.SIGALG_MLKEM1024:
        case AlgorithmConstants.SIGALG_MLDSA44:
        case AlgorithmConstants.SIGALG_MLDSA65:
        case AlgorithmConstants.SIGALG_MLDSA87:
        case AlgorithmConstants.SIGALG_LMS:
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_128S:
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128S:
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_128F:
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128F:
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_192S:
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192S:
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_192F:
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192F:
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_256S:
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256S:
        case AlgorithmConstants.SIGALG_SLHDSA_SHA2_256F:
        case AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256F:
            encSigAlg = AlgorithmConstants.SIGALG_SHA256_WITH_RSA;
            break;
        default:
            //Find the hash algorithm
            final String hashAlgo = getHashAlgorithm(signatureAlgorithm);
            if(publicKey instanceof RSAPublicKey) {
                if(signatureAlgorithm.contains("MGF1")) {
                    encSigAlg = signatureAlgorithm;
                } else {
                    switch (hashAlgo) {
                    case AlgorithmConstants.HASHALGORITHM_SHA1:
                        encSigAlg = AlgorithmConstants.SIGALG_SHA1_WITH_RSA;
                        break;
                    case AlgorithmConstants.HASHALGORITHM_SHA224:
                        encSigAlg = AlgorithmConstants.SIGALG_SHA256_WITH_RSA;
                        break;
                    case AlgorithmConstants.HASHALGORITHM_SHA256:
                        encSigAlg = AlgorithmConstants.SIGALG_SHA256_WITH_RSA;
                        break;
                    case AlgorithmConstants.HASHALGORITHM_SHA384:
                        encSigAlg = AlgorithmConstants.SIGALG_SHA384_WITH_RSA;
                        break;
                    case AlgorithmConstants.HASHALGORITHM_SHA512:
                        encSigAlg = AlgorithmConstants.SIGALG_SHA512_WITH_RSA;
                        break;
                    case AlgorithmConstants.HASHALGORITHM_SHA3_256:
                        encSigAlg = AlgorithmConstants.SIGALG_SHA3_256_WITH_RSA;
                        break;
                    case AlgorithmConstants.HASHALGORITHM_SHA3_384:
                        encSigAlg = AlgorithmConstants.SIGALG_SHA3_384_WITH_RSA;
                        break;
                    case AlgorithmConstants.HASHALGORITHM_SHA3_512:
                        encSigAlg = AlgorithmConstants.SIGALG_SHA3_512_WITH_RSA;
                        break;
                    default:
                        encSigAlg = signatureAlgorithm;
                        break;
                    }
                }
            } else if(publicKey instanceof ECPublicKey) {
                switch(hashAlgo) {
                case AlgorithmConstants.HASHALGORITHM_SHA1:
                    encSigAlg = AlgorithmConstants.SIGALG_SHA1_WITH_ECDSA;
                    break;
                case AlgorithmConstants.HASHALGORITHM_SHA224:
                    encSigAlg = AlgorithmConstants.SIGALG_SHA224_WITH_ECDSA;
                    break;
                case AlgorithmConstants.HASHALGORITHM_SHA256:
                    encSigAlg = AlgorithmConstants.SIGALG_SHA256_WITH_ECDSA;
                    break;
                case AlgorithmConstants.HASHALGORITHM_SHA384:
                    encSigAlg = AlgorithmConstants.SIGALG_SHA384_WITH_ECDSA;
                    break;
                case AlgorithmConstants.HASHALGORITHM_SHA512:
                    encSigAlg = AlgorithmConstants.SIGALG_SHA512_WITH_ECDSA;
                    break;
                case AlgorithmConstants.HASHALGORITHM_SHA3_256:
                    encSigAlg = AlgorithmConstants.SIGALG_SHA3_256_WITH_ECDSA;
                    break;
                case AlgorithmConstants.HASHALGORITHM_SHA3_384:
                    encSigAlg = AlgorithmConstants.SIGALG_SHA3_384_WITH_ECDSA;
                    break;
                case AlgorithmConstants.HASHALGORITHM_SHA3_512:
                    encSigAlg = AlgorithmConstants.SIGALG_SHA3_512_WITH_ECDSA;
                    break;
                default:
                    encSigAlg = signatureAlgorithm;
                    break;
                }
            } else {
                encSigAlg = signatureAlgorithm;
            }
        }

        return encSigAlg;
    }

    /**
     * Answers if the key can be used together with the given signature algorithm.
     * @param publicKey public key to use
     * @param signatureAlgorithm algorithm to test
     * @return true if signature algorithm can be used with the public key algorithm
     */
    public static boolean isCompatibleSigAlg(final PublicKey publicKey, final String signatureAlgorithm) {
        String algname = publicKey.getAlgorithm();
        if (algname == null) {
            algname = "";
        }

        boolean ret = false;
        if (StringUtils.contains(signatureAlgorithm, AlgorithmConstants.KEYALGORITHM_RSA)) {
            if (publicKey instanceof RSAPublicKey) {
                ret = true;
            }
        } else if (StringUtils.contains(signatureAlgorithm, AlgorithmConstants.KEYALGORITHM_ECDSA)) {
            if (publicKey instanceof ECPublicKey) {
                ret = true;
            }
         } else if (StringUtils.equals(signatureAlgorithm, AlgorithmConstants.SIGALG_ED25519)) {
             if (StringUtils.equals(AlgorithmConstants.KEYALGORITHM_ED25519, publicKey.getAlgorithm())) {
                 ret = true;
             }
         } else if (StringUtils.equals(signatureAlgorithm, AlgorithmConstants.SIGALG_ED448)) {
             if (StringUtils.equals(AlgorithmConstants.KEYALGORITHM_ED448, publicKey.getAlgorithm())) {
                 ret = true;
             }
         } else if (StringUtils.containsIgnoreCase(signatureAlgorithm, "FALCON")) {
             if (publicKey instanceof FalconKey) {
                 ret = true;
             }
         } else if (StringUtils.containsIgnoreCase(signatureAlgorithm, "ML-KEM")) {
             if (publicKey instanceof MLKEMKey) {
                 ret = true;
             }
         } else if (StringUtils.containsIgnoreCase(signatureAlgorithm, "ML-DSA")) {
             if (publicKey instanceof MLDSAKey) {
                 ret = true;
             }
         } else if (StringUtils.containsIgnoreCase(signatureAlgorithm, "SLH-DSA")) {
             if (publicKey instanceof SLHDSAKey) {
                 ret = true;
             }
         } else if (StringUtils.containsIgnoreCase(signatureAlgorithm, AlgorithmConstants.SIGALG_LMS)) {
             if (publicKey instanceof LMSKey) {
                 ret = true;
             }
         }
        return ret;
    }

    /**
     * Simple method that looks at the certificate and determines, from EJBCA's standpoint, which signature algorithm it is
     *
     * @param cert the cert to examine, MUST be self signed as the returned result depends on the public key
     * @return Signature algorithm name from AlgorithmConstants.SIGALG_SHA256_WITH_RSA etc.
     */
    public static String getSignatureAlgorithm(Certificate cert) {
        String signatureAlgorithm = null;
        String certSignatureAlgorithm = CertTools.getCertSignatureAlgorithmNameAsString(cert);

        // The signature string returned from the certificate is often not usable as the signature algorithm we must
        // specify for a CA in EJBCA, for example SHA1WithECDSA is returned as only ECDSA, so we need some magic to fix it up.
        PublicKey publickey = cert.getPublicKey();
        if (publickey instanceof RSAPublicKey) {
            if (certSignatureAlgorithm.contains("SHA3-")) {
                if (certSignatureAlgorithm.contains("256")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA3_256_WITH_RSA;
                } else if (certSignatureAlgorithm.contains("384")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA3_384_WITH_RSA;
                } else if (certSignatureAlgorithm.contains("512")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA3_512_WITH_RSA;
                }
            } else if (!certSignatureAlgorithm.contains("MGF1")) {
                if (certSignatureAlgorithm.contains("MD5")) {
                    signatureAlgorithm = "MD5WithRSA";
                } else if (certSignatureAlgorithm.contains("SHA1")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA1_WITH_RSA;
                } else if (certSignatureAlgorithm.contains("256")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA256_WITH_RSA;
                } else if (certSignatureAlgorithm.contains("384")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA384_WITH_RSA;
                } else if (certSignatureAlgorithm.contains("512")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA512_WITH_RSA;
                }
            } else {
                if (certSignatureAlgorithm.contains("SHA1")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA1_WITH_RSA_AND_MGF1;
                } else if (certSignatureAlgorithm.contains("256")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA256_WITH_RSA_AND_MGF1;
                } else if (certSignatureAlgorithm.contains("384")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA384_WITH_RSA_AND_MGF1;
                } else if (certSignatureAlgorithm.contains("512")) {
                    signatureAlgorithm = AlgorithmConstants.SIGALG_SHA512_WITH_RSA_AND_MGF1;
                }
            }
        } else if ( publickey instanceof BCEdDSAPublicKey ) {
            // EdDSA algorithms are named the same as the key algo, i.e. Ed25519 or Ed488
            signatureAlgorithm = publickey.getAlgorithm();
        } else if ( publickey instanceof FalconKey ) {
            // FALCON algorithms are named the same as the key algo, i.e. FALCON-512 or FALCON-1024
            signatureAlgorithm = certSignatureAlgorithm;
        } else if ( publickey instanceof MLKEMKey ) {
            // ML-KEM algorithms are named the same as the key algo, i.e. ML-KEM-512 or ML-KEM-768 or ML-KEM-1024
            signatureAlgorithm = certSignatureAlgorithm;
        } else if ( publickey instanceof MLDSAKey ) {
            // ML-DSA algorithms are named the same as the key algo, i.e. ML-DSA-44 or ML-DSA-87
            signatureAlgorithm = certSignatureAlgorithm;
        } else if ( publickey instanceof SLHDSAKey ) {
            // SLH-DSA algorithms are named the same as the key algo,
            signatureAlgorithm = certSignatureAlgorithm;
        } else {
            if (certSignatureAlgorithm.contains("SHA3-")) {
                if (certSignatureAlgorithm.contains("256")) {
                    return AlgorithmConstants.SIGALG_SHA3_256_WITH_ECDSA;
                } else if (certSignatureAlgorithm.contains("384")) {
                    return AlgorithmConstants.SIGALG_SHA3_384_WITH_ECDSA;
                } else if (certSignatureAlgorithm.contains("512")) {
                    return AlgorithmConstants.SIGALG_SHA3_512_WITH_ECDSA;
                }
            } else if (certSignatureAlgorithm.contains("256")) {
                signatureAlgorithm = AlgorithmConstants.SIGALG_SHA256_WITH_ECDSA;
            } else if (certSignatureAlgorithm.contains("224")) {
                signatureAlgorithm = AlgorithmConstants.SIGALG_SHA224_WITH_ECDSA;
            } else if (certSignatureAlgorithm.contains("384")) {
                signatureAlgorithm = AlgorithmConstants.SIGALG_SHA384_WITH_ECDSA;
            } else if (certSignatureAlgorithm.contains("512")) {
                signatureAlgorithm = AlgorithmConstants.SIGALG_SHA512_WITH_ECDSA;
            } else if (certSignatureAlgorithm.contains("ECDSA")) {
                // From x509cert.getSigAlgName(), SHA1withECDSA only returns name ECDSA
                signatureAlgorithm = AlgorithmConstants.SIGALG_SHA1_WITH_ECDSA;
            }
        }
        if (log.isDebugEnabled()) {
            log.debug("getSignatureAlgorithm: " + signatureAlgorithm);
        }
        return signatureAlgorithm;
    } // getSignatureAlgorithm

    /**
     * Returns the signature parameter (NONE or PSS) based on the OID.
     *
     * @param oid the OID as a String
     * @return SignatureParameters.PSS if the OID is for RSASSA-PSS, otherwise SignatureParameters.NONE
     */
    public static SignatureParameter getSignatureParameterFromOid(final String oid) {
        if (oid != null && oid.equals(PKCSObjectIdentifiers.id_RSASSA_PSS.getId())) {
            return SignatureParameter.PSS;
        }
        return SignatureParameter.NONE;
    }

    /**
     * Returns the OID of the digest algorithm corresponding to the signature algorithm. This takes an AlgorithmIdentifier as input
     * and as such can handle parameters which the getDigestFromSigAlg cannot. Because of that the method is able to handle PSS.
     *
     * @param sigAlg The signature algorithm of the type AlgorithmIdentifier
     * @param defaultDigest DigestOID to use if nothing matches for example CMSSignedGenerator.DIGEST_SHA256, or null
     * @return Digest OID, CMSSignedGenerator.DIGEST_SHA256, etc, or null if nothing fits and defaultDigest is null
     */
    public static String getDigestFromSigAlgAndHandleParameters(final AlgorithmIdentifier sigAlg, final String defaultDigest) {
        ASN1ObjectIdentifier oid = sigAlg.getAlgorithm();
        if (oid.equals(PKCSObjectIdentifiers.id_RSASSA_PSS)) {
            RSASSAPSSparams pss = RSASSAPSSparams.getInstance(sigAlg.getParameters());
            if (pss.getHashAlgorithm() == null || pss.getHashAlgorithm().getAlgorithm() == null) {
                return defaultDigest;
            }
            ASN1ObjectIdentifier hashOid = pss.getHashAlgorithm().getAlgorithm();
            return hashOid.getId();
        }
        String sigAlgOid = oid.getId();
        return getDigestFromSigAlg(sigAlgOid, defaultDigest);
    }

    /**
     * Returns the OID of the digest algorithm corresponding to the signature algorithm. Does not handle RSA-SSA (MGF1) since the Hash algo in MGF1
     * is hidden in the parameters, which is not visible in the sigAlg. Use getDigestFromSigAlgAndHandleParameters instead to also handle RSA-SSA (MGF1).
     * Also algorithms such as Ed25519 or ML-DSA do not correspond to a specific digest algorithm, set the default value to something you can use,
     * or accept the null return.
     *
     * @param sigAlgOid OID of a signatureAlgorithm, for example PKCSObjectIdentifiers.sha256WithRSAEncryption.getId() (1.2.840.113549.1.1.11)
     * @param defaultDigest DigestOID to use if nothing matches for example CMSSignedGenerator.DIGEST_SHA256, or null
     * @return Digest OID, CMSSignedGenerator.DIGEST_SHA256, etc, or null if nothing fits and defaultDigest is null
     */
    public static String getDigestFromSigAlg(String sigAlgOid, String defaultDigest) {

        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA1.getId()) || sigAlgOid.equals(PKCSObjectIdentifiers.sha1WithRSAEncryption.getId())) {
            return CMSSignedGenerator.DIGEST_SHA1;
        }
        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA224.getId()) || sigAlgOid.equals(PKCSObjectIdentifiers.sha224WithRSAEncryption.getId())) {
            return CMSSignedGenerator.DIGEST_SHA224;
        }
        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA256.getId()) || sigAlgOid.equals(PKCSObjectIdentifiers.sha256WithRSAEncryption.getId())) {
            return CMSSignedGenerator.DIGEST_SHA256;
        }
        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA384.getId()) || sigAlgOid.equals(PKCSObjectIdentifiers.sha384WithRSAEncryption.getId())) {
            return CMSSignedGenerator.DIGEST_SHA384;
        }
        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA512.getId()) || sigAlgOid.equals(PKCSObjectIdentifiers.sha512WithRSAEncryption.getId())) {
            return CMSSignedGenerator.DIGEST_SHA512;
        }

        if (sigAlgOid.equals(NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_256.getId())) {
            return NISTObjectIdentifiers.id_sha3_256.getId();
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_384.getId())) {
            return NISTObjectIdentifiers.id_sha3_384.getId();
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_512.getId())) {
            return NISTObjectIdentifiers.id_sha3_512.getId();
        }

        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_256.getId())) {
            return NISTObjectIdentifiers.id_sha3_256.getId();
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_384.getId())) {
            return NISTObjectIdentifiers.id_sha3_384.getId();
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_512.getId())) {
            return NISTObjectIdentifiers.id_sha3_512.getId();
        }

        if(sigAlgOid.equals(PKCSObjectIdentifiers.md5WithRSAEncryption.getId())) {
            return CMSSignedGenerator.DIGEST_MD5;
        }

        return defaultDigest;
    }

    /**
     * Calculates which signature algorithm to use given a key type and a digest algorithm, digest can be null in which case
     * it defaults to SHA256 for RSA and EC. On the other hand the digest value is not applicable and used when key algorithm is
     * Ed25519, Ed448, any of the ML-DSA variants etc, where the signature algorithm itself specifies everything.
     *
     * @param digestAlg objectId of a digest algorithm, CMSSignedGenerator.DIGEST_SHA256 etc, or null if not applicable or default SHA256 should be used
     * @param keyAlg RSA, EC, Ed25519, Ed448, ML-DSA-44/65/87
     * @return ASN1ObjectIdentifier with the id of PKCSObjectIdentifiers.sha256WithRSAEncryption, X9ObjectIdentifiers.ecdsa_with_SHA256, etc
     */
    public static ASN1ObjectIdentifier getSignAlgOidFromDigestAndKey(final String digestAlg, final String keyAlg) {
        if (log.isTraceEnabled()) {
            log.trace(">getSignAlg("+digestAlg+","+keyAlg+")");
        }
        // Default to SHA256WithRSA if everything else fails
        ASN1ObjectIdentifier oid = PKCSObjectIdentifiers.sha256WithRSAEncryption;
        if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA)) {
            oid = X9ObjectIdentifiers.ecdsa_with_SHA256;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ED25519)) {
            oid = EdECObjectIdentifiers.id_Ed25519;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ED448)) {
            oid = EdECObjectIdentifiers.id_Ed448;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_FALCON512)) {
            oid = BCObjectIdentifiers.falcon_512;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_FALCON1024)) {
            oid = BCObjectIdentifiers.falcon_1024;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLKEM512)) {
            oid = NISTObjectIdentifiers.id_alg_ml_kem_512;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLKEM768)) {
            oid = NISTObjectIdentifiers.id_alg_ml_kem_768;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLKEM1024)) {
            oid = NISTObjectIdentifiers.id_alg_ml_kem_1024;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA44)) {
            oid = NISTObjectIdentifiers.id_ml_dsa_44;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA65)) {
            oid = NISTObjectIdentifiers.id_ml_dsa_65;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_MLDSA87)) {
            oid = NISTObjectIdentifiers.id_ml_dsa_87;
        } else if (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_LMS)) {
            oid = PKCSObjectIdentifiers.id_alg_hss_lms_hashsig;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_128S)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_sha2_128s;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128S)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_shake_128s;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_128F)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_sha2_128f;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128F)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_shake_128f;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_192S)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_sha2_192s;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192S)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_shake_192s;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_192F)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_sha2_192f;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192F)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_shake_192f;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_256S)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_sha2_256s;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256S)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_shake_256s;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHA2_256F)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_sha2_256f;
        } else if (keyAlg.equals(AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256F)) {
            oid = NISTObjectIdentifiers.id_slh_dsa_shake_256f;
        }
        if (digestAlg != null) {
            if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA1) && keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
                oid = PKCSObjectIdentifiers.sha1WithRSAEncryption;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA256) && keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
                oid = PKCSObjectIdentifiers.sha256WithRSAEncryption;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA384) && keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
                    oid = PKCSObjectIdentifiers.sha384WithRSAEncryption;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA512) && keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
                oid = PKCSObjectIdentifiers.sha512WithRSAEncryption;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_MD5) && keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
                oid = PKCSObjectIdentifiers.md5WithRSAEncryption;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA1) && (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC)) ) {
                oid = X9ObjectIdentifiers.ecdsa_with_SHA1;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA256) && (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC)) ) {
                oid = X9ObjectIdentifiers.ecdsa_with_SHA256;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA224) && (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC)) ) {
                oid = X9ObjectIdentifiers.ecdsa_with_SHA224;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA384) && (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC)) ) {
                oid = X9ObjectIdentifiers.ecdsa_with_SHA384;
            } else if (digestAlg.equals(CMSSignedGenerator.DIGEST_SHA512) && (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC)) ) {
                oid = X9ObjectIdentifiers.ecdsa_with_SHA512;
            } else if (digestAlg.equals(NISTObjectIdentifiers.id_sha3_256.toString()) && keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
                oid = NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_256;
            } else if (digestAlg.equals(NISTObjectIdentifiers.id_sha3_384.toString()) && keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
                oid = NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_384;
            } else if (digestAlg.equals(NISTObjectIdentifiers.id_sha3_512.toString()) && keyAlg.equals(AlgorithmConstants.KEYALGORITHM_RSA)) {
                oid = NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_512;
            } else if (digestAlg.equals(NISTObjectIdentifiers.id_sha3_256.toString())
                    && (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC))) {
                oid = NISTObjectIdentifiers.id_ecdsa_with_sha3_256;
            } else if (digestAlg.equals(NISTObjectIdentifiers.id_sha3_384.toString())
                    && (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC))) {
                oid = NISTObjectIdentifiers.id_ecdsa_with_sha3_384;
            } else if (digestAlg.equals(NISTObjectIdentifiers.id_sha3_512.toString())
                    && (keyAlg.equals(AlgorithmConstants.KEYALGORITHM_ECDSA) || keyAlg.equals(AlgorithmConstants.KEYALGORITHM_EC))) {
                oid = NISTObjectIdentifiers.id_ecdsa_with_sha3_512;
            }
        }
        if (log.isDebugEnabled()) {
            log.debug("getSignAlgOidFromDigestAndKey: " + oid.getId());
        }
        return oid;
    }

    public static String getAlgorithmNameFromDigestAndKey(final String digestAlg, final String keyAlg, final SignatureParameter parameter) {
        if (SignatureParameter.PSS == parameter && "RSA".equalsIgnoreCase(keyAlg)) {
            DefaultAlgorithmNameFinder nameFinder = new DefaultAlgorithmNameFinder();
            ASN1ObjectIdentifier digestOid = new ASN1ObjectIdentifier(digestAlg);
            String digestName = nameFinder.getAlgorithmName(digestOid);

            if (digestName != null) {
                return digestName.replace("SHA-", "SHA") + "withRSAandMGF1";
            }
        }
        return getAlgorithmNameFromDigestAndKey(digestAlg, keyAlg);
    }

    public static String getAlgorithmNameFromDigestAndKey(final String digestAlg, final String keyAlg) {
        return getAlgorithmNameFromOID(getSignAlgOidFromDigestAndKey(digestAlg, keyAlg));
    }

    /**
     *
     * @deprecated Removed, do not use.
     */
	@Deprecated
	public static boolean isSigAlgEnabled(String sigAlg) {
		return true;
	}

    /**
     * Determine whether the curve alias given as argument is a known elliptic curve.
     * @param alias an alias of the elliptic curve to look for
     * @return true if the elliptic curve is known by this alias, false otherwise
     */
    public static boolean isKnownAlias(final String alias) {
        return !getAllCurveAliasesFromAlias(alias).isEmpty();
    }

    /**
     * <p>Perform a case-insensitive lookup of all known aliases for an elliptic curve given one known alias.</p>
     * @return a sorted list of aliases for the elliptic curve specified, never null
     */
    public static List<String> getAllCurveAliasesFromAlias(final String alias) {
        final String lowerCaseAlias = alias.toLowerCase(Locale.ROOT);
        for (final Entry<String, List<String>> name : getNamedEcCurvesMap(false).entrySet()) {
            final String lowerCaseCanonicalName = name.getKey().toLowerCase(Locale.ROOT);
            final List<String> lowerCaseAliases = StringTools.toLowerCase(name.getValue());
            if (StringUtils.equals(lowerCaseAlias, lowerCaseCanonicalName) || lowerCaseAliases.contains(lowerCaseAlias)) {
                final List<String> aliases = new ArrayList<>(name.getValue());
                aliases.add(name.getKey());
                Collections.sort(aliases);
                return aliases;
            }
        }
        return new ArrayList<>();
    }

    /**
     * Returns the name of the algorithm corresponding to the specified OID
     * @param sigAlgOid
     * @return The name of the algorithm corresponding sigAlgOid or null if the algorithm is not recognized.
     */
    public static String getAlgorithmNameFromOID(ASN1ObjectIdentifier sigAlgOid) {

        if(sigAlgOid.equals(PKCSObjectIdentifiers.md5WithRSAEncryption)) {
            return AlgorithmConstants.SIGALG_MD5_WITH_RSA;
        }

        if(sigAlgOid.equals(PKCSObjectIdentifiers.sha1WithRSAEncryption)) {
            return AlgorithmConstants.SIGALG_SHA1_WITH_RSA;
        }

        if(sigAlgOid.equals(PKCSObjectIdentifiers.sha256WithRSAEncryption)) {
            return AlgorithmConstants.SIGALG_SHA256_WITH_RSA;
        }

        if(sigAlgOid.equals(PKCSObjectIdentifiers.sha384WithRSAEncryption)) {
            return AlgorithmConstants.SIGALG_SHA384_WITH_RSA;
        }

        if(sigAlgOid.equals(PKCSObjectIdentifiers.sha512WithRSAEncryption)) {
            return AlgorithmConstants.SIGALG_SHA512_WITH_RSA;
        }

        if (sigAlgOid.equals(NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_256)) {
            return AlgorithmConstants.SIGALG_SHA3_256_WITH_RSA;
        }

        if (sigAlgOid.equals(NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_384)) {
            return AlgorithmConstants.SIGALG_SHA3_384_WITH_RSA;
        }

        if (sigAlgOid.equals(NISTObjectIdentifiers.id_rsassa_pkcs1_v1_5_with_sha3_512)) {
            return AlgorithmConstants.SIGALG_SHA3_512_WITH_RSA;
        }

        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA1)) {
            return AlgorithmConstants.SIGALG_SHA1_WITH_ECDSA;
        }

        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA224)) {
            return AlgorithmConstants.SIGALG_SHA224_WITH_ECDSA;
        }

        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA256)) {
            return AlgorithmConstants.SIGALG_SHA256_WITH_ECDSA;
        }

        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA384)) {
            return AlgorithmConstants.SIGALG_SHA384_WITH_ECDSA;
        }

        if(sigAlgOid.equals(X9ObjectIdentifiers.ecdsa_with_SHA512)) {
            return AlgorithmConstants.SIGALG_SHA512_WITH_ECDSA;
        }

        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_256)) {
            return AlgorithmConstants.SIGALG_SHA3_256_WITH_ECDSA;
        }

        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_384)) {
            return AlgorithmConstants.SIGALG_SHA3_384_WITH_ECDSA;
        }

        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_512)) {
            return AlgorithmConstants.SIGALG_SHA3_512_WITH_ECDSA;
        }
        if (sigAlgOid.equals(EdECObjectIdentifiers.id_Ed25519)) {
            return AlgorithmConstants.SIGALG_ED25519;
        }
        if (sigAlgOid.equals(EdECObjectIdentifiers.id_Ed448)) {
            return AlgorithmConstants.SIGALG_ED448;
        }
        if (sigAlgOid.equals(BCObjectIdentifiers.falcon_512)) {
            return AlgorithmConstants.SIGALG_FALCON512;
        }
        if (sigAlgOid.equals(BCObjectIdentifiers.falcon_1024)) {
            return AlgorithmConstants.SIGALG_FALCON1024;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_alg_ml_kem_512)) {
            return AlgorithmConstants.SIGALG_MLKEM512;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_alg_ml_kem_768)) {
            return AlgorithmConstants.SIGALG_MLKEM768;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_alg_ml_kem_1024)) {
            return AlgorithmConstants.SIGALG_MLKEM1024;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ml_dsa_44)) {
            return AlgorithmConstants.SIGALG_MLDSA44;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ml_dsa_65)) {
            return AlgorithmConstants.SIGALG_MLDSA65;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_ml_dsa_87)) {
            return AlgorithmConstants.SIGALG_MLDSA87;
        }
        if (sigAlgOid.equals(PKCSObjectIdentifiers.id_alg_hss_lms_hashsig)) {
            return AlgorithmConstants.SIGALG_LMS;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_sha2_128s)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHA2_128S;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_shake_128s)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128S;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_sha2_128f)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHA2_128F;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_shake_128f)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHAKE_128F;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_sha2_192s)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHA2_192S;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_shake_192s)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192S;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_sha2_192f)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHA2_192F;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_shake_192f)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHAKE_192F;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_sha2_256s)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHA2_256S;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_shake_256s)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256S;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_sha2_256f)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHA2_256F;
        }
        if (sigAlgOid.equals(NISTObjectIdentifiers.id_slh_dsa_shake_256f)) {
            return AlgorithmConstants.SIGALG_SLHDSA_SHAKE_256F;
        }
        return null;
    }

    private static final DefaultSignatureAlgorithmIdentifierFinder finder = new DefaultSignatureAlgorithmIdentifierFinder();
    /**
     * Returns the OID name of the algorithm corresponding to the specified name
     * @param sigAlgName the name of a signature algorithm for example SHA256WithECDSA or ML-DSA-44
     * @return The OID of the algorithm corresponding sigAlgName or null if the algorithm is not recognized.
     */
    public static ASN1ObjectIdentifier getAlgorithmOIDFromName(String sigAlgName) {
        try {
            final AlgorithmIdentifier aid = finder.find(sigAlgName);
            if (aid != null) {
                return aid.getAlgorithm();
            }
        } catch (IllegalArgumentException e) {
            log.info("Can not find an OID for algorithm name " + sigAlgName + ", returning null");
        }
        return null;
    }

    /**
     * Get a Bouncy Castle elliptic curve parameter specification by OID.
     *
     * <p>If you only have the name of the curve, use {@link #getEcKeySpecOidFromBcName}
     * to lookup the OID first.
     *
     * @param oid the OID of the curve.
     * @return the elliptic curve parameter specification for the curve, or null if the OID is unknown.
     */
    public static org.bouncycastle.jce.spec.ECParameterSpec getEcParameterSpecFromOid(final ASN1ObjectIdentifier oid) {
        if (NISTNamedCurves.getByOID(oid) != null) {
            final X9ECParameters x9ecParameters = NISTNamedCurves.getByOID(oid);
            return new org.bouncycastle.jce.spec.ECParameterSpec(x9ecParameters.getCurve(), x9ecParameters.getG(), x9ecParameters.getN());
        }
        if (SECNamedCurves.getByOID(oid) != null) {
            final X9ECParameters x9ecParameters = SECNamedCurves.getByOID(oid);
            return new org.bouncycastle.jce.spec.ECParameterSpec(x9ecParameters.getCurve(), x9ecParameters.getG(), x9ecParameters.getN());
        }
        if (X962NamedCurves.getByOID(oid) != null) {
            final X9ECParameters x9ecParameters = X962NamedCurves.getByOID(oid);
            return new org.bouncycastle.jce.spec.ECParameterSpec(x9ecParameters.getCurve(), x9ecParameters.getG(), x9ecParameters.getN());
        }
        if (TeleTrusTNamedCurves.getByOID(oid) != null) {
            final X9ECParameters x9ecParameters = TeleTrusTNamedCurves.getByOID(oid);
            return new org.bouncycastle.jce.spec.ECParameterSpec(x9ecParameters.getCurve(), x9ecParameters.getG(), x9ecParameters.getN());
        }
        if (ANSSINamedCurves.getByOID(oid) != null) {
            final X9ECParameters x9ecParameters = ANSSINamedCurves.getByOID(oid);
            return new org.bouncycastle.jce.spec.ECParameterSpec(x9ecParameters.getCurve(), x9ecParameters.getG(), x9ecParameters.getN());
        }
        if (GMNamedCurves.getByOID(oid) != null) {
            final X9ECParameters x9ecParameters = GMNamedCurves.getByOID(oid);
            return new org.bouncycastle.jce.spec.ECParameterSpec(x9ecParameters.getCurve(), x9ecParameters.getG(), x9ecParameters.getN());
        }
        return null;
    }

    /**
     * Returns a {@link java.security.MessageDigest} object given the name of a signature algorithm, e.g. "SHA256withECDSA".
     *
     * <p>Signature algorithm names are defined in {@link AlgorithmConstants}.
     *
     * @param signatureAlgorithm the name of the signature algorithm, e.g. "SHA256withECDSA".
     * @return a message digest object able to compute digests with the hash algorithm specified.
     * @throws NoSuchAlgorithmException if the signature algorithm uses an unsupported digest algorithm.
     * @throws NoSuchProviderException if the Bouncy Castle provider is not installed.
     */
    public static MessageDigest getDigestFromAlgoName(final String signatureAlgorithm) throws NoSuchAlgorithmException, NoSuchProviderException {
        if (signatureAlgorithm.startsWith("SHA1")) {
            return MessageDigest.getInstance("SHA1", "BC");
        } else if (signatureAlgorithm.startsWith("SHA224")) {
            return MessageDigest.getInstance("SHA-224", "BC");
        } else if (signatureAlgorithm.startsWith("SHA256")) {
            return MessageDigest.getInstance("SHA-256", "BC");
        } else if (signatureAlgorithm.startsWith("SHA384")) {
            return MessageDigest.getInstance("SHA-384", "BC");
        } else if (signatureAlgorithm.startsWith("SHA512")) {
            return MessageDigest.getInstance("SHA-512", "BC");
        } else if (signatureAlgorithm.startsWith("SHA3-256")) {
            return MessageDigest.getInstance("SHA3-256", "BC");
        } else if (signatureAlgorithm.startsWith("SHA3-384")) {
            return MessageDigest.getInstance("SHA3-384", "BC");
        } else if (signatureAlgorithm.startsWith("SHA3-512")) {
            return MessageDigest.getInstance("SHA3-512", "BC");
        } else if (signatureAlgorithm.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_256.getId())) {
            return MessageDigest.getInstance("SHA3-256", "BC");
        } else if (signatureAlgorithm.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_384.getId())) {
            return MessageDigest.getInstance("SHA3-384", "BC");
        } else if (signatureAlgorithm.equals(NISTObjectIdentifiers.id_ecdsa_with_sha3_512.getId())) {
            return MessageDigest.getInstance("SHA3-512", "BC");
        }
        throw new NoSuchAlgorithmException("The signature algorithm " + signatureAlgorithm + " uses an unsupported digest algorithm.");
    }

    /**
     * The method identifies an algorithm as being a post quantum algorithm or not.
     * @see #isNonStandardPQC(String)
     *
     * @param name the algorithm name
     * @return true if the algorithm is a post quantum algorithm, standard or non-standard otherwise false
     */
    public static final boolean isPQC(String name) {
        if (name == null) {
            return false;
        }
        return StringUtils.startsWithIgnoreCase(name, "SLH-DSA")
                || StringUtils.startsWithIgnoreCase(name, "ML-DSA")
                || StringUtils.startsWithIgnoreCase(name, "LMS")
                || pqcSigAlgs.contains(name)
                || StringUtils.startsWithIgnoreCase(name, "ML-KEM") || name.startsWith(NISTObjectIdentifiers.kems.getId()) // KEMs are new in PQC and have their own OID tree
                || StringUtils.startsWithIgnoreCase(name, "FALCON") || name.startsWith(BCObjectIdentifiers.falcon.getId()) || name.startsWith("1.3.9999.3"); // Falcon is non standard and have it's own tree for now
    }
    // List of standard PQC signature algorithm OIDs from BC. The PQC sig algs are just continuously
    // incremented from old sign algs, so it can't be checked by a simple tree like ML-KEM
    private static final List<String> pqcSigAlgs = Arrays.asList(
            NISTObjectIdentifiers.id_slh_dsa_sha2_128f.getId(),
            NISTObjectIdentifiers.id_slh_dsa_sha2_128s.getId(),
            NISTObjectIdentifiers.id_slh_dsa_sha2_192f.getId(),
            NISTObjectIdentifiers.id_slh_dsa_sha2_192s.getId(),
            NISTObjectIdentifiers.id_slh_dsa_sha2_256f.getId(),
            NISTObjectIdentifiers.id_slh_dsa_sha2_256s.getId(),
            NISTObjectIdentifiers.id_slh_dsa_shake_128f.getId(),
            NISTObjectIdentifiers.id_slh_dsa_shake_128s.getId(),
            NISTObjectIdentifiers.id_slh_dsa_shake_192f.getId(),
            NISTObjectIdentifiers.id_slh_dsa_shake_192s.getId(),
            NISTObjectIdentifiers.id_slh_dsa_shake_256f.getId(),
            NISTObjectIdentifiers.id_slh_dsa_shake_256s.getId(),
            NISTObjectIdentifiers.id_ml_dsa_44.getId(),
            NISTObjectIdentifiers.id_ml_dsa_65.getId(),
            NISTObjectIdentifiers.id_ml_dsa_87.getId(),
            PKCSObjectIdentifiers.id_alg_hss_lms_hashsig.getId()
            );
    /**
     * The method identifies an algorithm as being a post quantum KEM algorithm or not.
     * @see #isPQC(String)
     * @see #isNonStandardPQC(String)
     *
     * @param name the algorithm name
     * @return true if the algorithm is a post quantum algorithm, standard or non-standard otherwise false
     */
    public static final boolean isKEM(String name) {
        if (name == null) {
            return false;
        }
        return StringUtils.startsWithIgnoreCase(name, "ML-KEM") || name.startsWith(NISTObjectIdentifiers.kems.getId());
    }
    /**
     * The method identifies an algorithm as being a non-standard post quantum algorithm or not. Standardized algorithms
     * i.e. ML-DSA, ML-KEM, SLH-DSA are in the standard BC provider.
     * @see #isPQC(String)
     * @see #isKEM(String)
     *
     * @param name the algorithm name
     * @return true if the algorithm is a non-standardized post quantum algorithm, otherwise false
     */
    public static final boolean isNonStandardPQC(String name) {
        if (name == null) {
            return false;
        }
        return StringUtils.startsWithIgnoreCase(name, "FALCON") || name.startsWith(BCObjectIdentifiers.falcon.getId()) || name.startsWith("1.3.9999.3");
    }

}
